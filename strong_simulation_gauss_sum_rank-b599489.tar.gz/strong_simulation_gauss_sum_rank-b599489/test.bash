#!/bin/bash
# simple Bash script to check if Gauss sum code works

# choose the gauss sum multiple decomposition you want to test
gausssumcode=./gausssums_multipleof6

# choose the number of qubits and T gates on those qubits
# NOTE: numqubits must be a multiple of your gauss sum tensor multiple!
# e.g. if you test gausssums_multipleof6 then numqubits=6*n for some integer n
numqubits=6
numTgates=4

numPaulis=1 # we want numPaulis to be 1 for the loop below

numruns=20

echo "Starting test of $numruns random Pauli expectation values..."
for i in $(seq 1 $numruns)
do
  sleep 1;a=$(stdbuf -oL ./randommultipleinputPaulis $numqubits $numTgates $numPaulis > inputPaulis.txt && $gausssumcode < inputPaulis.txt | tail -1)
  b=$(stdbuf -oL ./hilbertspace_vector < inputPaulis.txt | tail -n1)
  echo $i $a $b
  if [ "$a" == "$b" ]
  then
    continue
  else
    echo "NOT EQUAL!"
    exit
  fi
done
echo "Test passed!"
