#include <stdio.h>
#include <stdlib.h>
#include <complex.h>
#include <math.h>

int readPaulicoeffs(int* alpha, int* beta, int* gamma, int* delta, int numqubits);
complex double Gausssum1d(int quadraticcoeff, int linearcoeff);
complex double Kroneck(int arg);
  
// order of matrix elements is [row][column]!!!

int main()
{

  int i, j;
  int x, y, xp, yp, xpp, ypp, xppp, yppp;
  
  int N;              // number of qubits
  scanf("%d", &N);
  if(N%12!=0) {
    printf("Error: N must be a multiple of 12!\n");
    return 1;
  }

  int alpha[N], beta[N], gamma[N], delta[N];

  double complex summand, sum;

  while(readPaulicoeffs(alpha, beta, gamma, delta, N)) {

    /* for(i=0; i<N; i++) */
    /*   printf("%d %d %d %d\n", alpha[i], beta[i], gamma[i], delta[i]); */

    sum = 1.0+0.0*I;
    for(i=0; i<N; i+=12) {
      summand = 0.0*I;

      j = i + 6; // index of second tensored primitive t=6
      
      
      // first term
      for(y=0; y<=1; y++) {
      	//**for(x=0;x<=(y*(gamma[i]+gamma[i+1])+(y+1)*(gamma[i]+delta[i+1]))%2; x++) {
      	for(x=y*(beta[i]+alpha[i+1]+beta[i+1])%2;x<=(y*(beta[i]+alpha[i+1]+beta[i+1])+y*(gamma[i]+gamma[i+1])+(y+1)*(gamma[i]+delta[i+1]))%2; x++) {
	  for(yp=((gamma[i+3]+delta[i+4])*x)%2; yp<=(1+(gamma[i+3]+gamma[i+4])*x)%2; yp++) {
	  //****for(yp=((gamma[i+3]+delta[i+4])*x*(1+alpha[i]+beta[i]))%2; yp<=(1+(gamma[i+3]+gamma[i+4])*x*(1+alpha[i]+beta[i]))%2; yp++) {
	    //**for(xp=0;xp<=(yp*(gamma[i+3]+gamma[i+4])+(yp+1)*(gamma[i+3]+delta[i+4]))%2; xp++) {
	    for(xp=yp*(beta[i+3]+alpha[i+4]+beta[i+4])%2;xp<=(yp*(beta[i+3]+alpha[i+4]+beta[i+4])+yp*(gamma[i+3]+gamma[i+4])+(yp+1)*(gamma[i+3]+delta[i+4]))%2; xp++) {

	      
	      //for(ypp=0; ypp<=1; ypp++) {
	      for(ypp=((gamma[j]+delta[j+1])*(x+xp))%2;ypp<=(1+(gamma[j]+gamma[j+1])*(x+xp))%2;ypp++) {
	      //****for(ypp=((gamma[j]+delta[j+1])*(x*(1+alpha[i]+beta[i])+xp*(1+alpha[i+3]+beta[i+3])))%2;ypp<=(1+(gamma[j]+gamma[j+1])*(x*(1+alpha[i]+beta[i])+xp*(1+alpha[i+3]+beta[i+3])))%2;ypp++) {
		//**for(xpp=0;xpp<=(ypp*(gamma[j]+gamma[j+1])+(ypp+1)*(gamma[j]+delta[j+1]))%2; xpp++) {
		for(xpp=ypp*(beta[j]+alpha[j+1]+beta[j+1])%2;xpp<=(ypp*(beta[j]+alpha[j+1]+beta[j+1])+ypp*(gamma[j]+gamma[j+1])+(ypp+1)*(gamma[j]+delta[j+1]))%2; xpp++) {
		  //for(yppp=((gamma[j+3]+delta[j+4])*xpp)%2; yppp<=(1+(gamma[j+3]+gamma[j+4])*xpp)%2; yppp++) {
		  for(yppp=((gamma[j+3]+delta[j+4])*(x+xp+xpp))%2; yppp<=(1+(gamma[j+3]+gamma[j+4])*(x+xp+xpp))%2; yppp++) {
		    //****for(yppp=((gamma[j+3]+delta[j+4])*(x*(1+alpha[i]+beta[i])+xp*(1+alpha[i+3]+beta[i+3])+xpp*(1+alpha[j]+beta[j])))%2; yppp<=(1+(gamma[j+3]+gamma[j+4])*(x*(1+alpha[i]+beta[i])+xp*(1+alpha[i+3]+beta[i+3])+xpp*(1+alpha[j]+beta[j])))%2; yppp++) {
		    //**for(xppp=0;xppp<=(yppp*(gamma[j+3]+gamma[j+4])+(yppp+1)*(gamma[j+3]+delta[j+4]))%2; xppp++) {
		    for(xppp=yppp*(beta[j+3]+alpha[j+4]+beta[j+4])%2;xppp<=(yppp*(beta[j+3]+alpha[j+4]+beta[j+4])+yppp*(gamma[j+3]+gamma[j+4])+(yppp+1)*(gamma[j+3]+delta[j+4]))%2; xppp++) {
		      //summand += (2.0*(0.125*pow(2.0,(1-y*pow(gamma[i]-gamma[i+1],2)-pow(y-1,2)*pow(gamma[i]-delta[i+1],2))*(1-yp*pow(gamma[i+3]-gamma[i+4],2)-pow(yp-1,2)*pow(gamma[i+3]-delta[i+4],2)))*cexp(M_PI*I/2.0*((delta[i+1]-gamma[i])*pow(y+1,2)+2.0*(beta[i]+beta[i+1]+gamma[i]+delta[i+1])*x*pow(y+1,2)+2.0*(delta[i]+delta[i+1]+beta[i]+beta[i+1])*x*y+(2.0*beta[i]+3.0*delta[i]+delta[i+1])*y))*Gausssum1d(0.0,beta[i+2])*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1])*Kroneck(gamma[i+2]+delta[i+2]) 
		      summand += 2.0*(2.0*(0.125*pow(2.0,(1-y*pow(gamma[i]-gamma[i+1],2)-pow(y-1,2)*pow(gamma[i]-delta[i+1],2))*(1-yp*pow(gamma[i+3]-gamma[i+4],2)-pow(yp-1,2)*pow(gamma[i+3]-delta[i+4],2))*(1-ypp*pow(gamma[j]-gamma[j+1],2)-pow(ypp-1,2)*pow(gamma[j]-delta[j+1],2))*(1-yppp*pow(gamma[j+3]-gamma[j+4],2)-pow(yppp-1,2)*pow(gamma[j+3]-delta[j+4],2)))*cexp(M_PI*I/2.0*((delta[i+1]-gamma[i])*pow(y+1,2)+2.0*(beta[i]+beta[i+1]+gamma[i]+delta[i+1])*x*pow(y+1,2)+2.0*(delta[i]+delta[i+1]+beta[i]+beta[i+1])*x*y+(2.0*beta[i]+3.0*delta[i]+delta[i+1])*y))*Gausssum1d(0.0,beta[i+2])*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1])*Kroneck(gamma[i+2]+delta[i+2]) 
					   //+ 0.125*pow(2.0,(1-y*pow(gamma[i]-gamma[i+1],2)-pow(y-1,2)*pow(gamma[i]-delta[i+1],2))*(1-yp*pow(gamma[i+3]-gamma[i+4],2)-pow(yp-1,2)*pow(gamma[i+3]-delta[i+4],2)))*cexp(M_PI*I/2.0*((delta[i+1]-gamma[i])*pow(y+1,2)+2.0*(beta[i]+beta[i+1]+gamma[i]+delta[i+1])*x*pow(y+1,2)+2.0*(delta[i]+delta[i+1]+beta[i]+beta[i+1])*x*y+(2.0*beta[i]+3.0*delta[i]+delta[i+1])*y))*csqrt(-I)*Gausssum1d(gamma[i+2]+delta[i+2],0)*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1])*Kroneck(alpha[i+2]+beta[i+2]))
					   + 0.125*pow(2.0,(1-y*pow(gamma[i]-gamma[i+1],2)-pow(y-1,2)*pow(gamma[i]-delta[i+1],2))*(1-yp*pow(gamma[i+3]-gamma[i+4],2)-pow(yp-1,2)*pow(gamma[i+3]-delta[i+4],2))*(1-ypp*pow(gamma[j]-gamma[j+1],2)-pow(ypp-1,2)*pow(gamma[j]-delta[j+1],2))*(1-yppp*pow(gamma[j+3]-gamma[j+4],2)-pow(yppp-1,2)*pow(gamma[j+3]-delta[j+4],2)))*cexp(M_PI*I/2.0*((delta[i+1]-gamma[i])*pow(y+1,2)+2.0*(beta[i]+beta[i+1]+gamma[i]+delta[i+1])*x*pow(y+1,2)+2.0*(delta[i]+delta[i+1]+beta[i]+beta[i+1])*x*y+(2.0*beta[i]+3.0*delta[i]+delta[i+1])*y))*csqrt(-I)*Gausssum1d(gamma[i+2]+delta[i+2],0)*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1])*Kroneck(alpha[i+2]+beta[i+2]))
				  *(0.125*cexp(M_PI*I/2.0*((delta[i+4]-gamma[i+3])*pow(yp+1,2)+2.0*(beta[i+3]+beta[i+4]+gamma[i+3]+delta[i+4])*xp*pow(yp+1,2)+2.0*(delta[i+3]+delta[i+4]+beta[i+3]+beta[i+4])*xp*yp+(2.0*beta[i+3]+3.0*delta[i+3]+delta[i+4])*yp))*Gausssum1d(0.0,beta[i+5])*Kroneck(gamma[i+3]+delta[i+3]-gamma[i+4]-delta[i+4])*Kroneck(gamma[i+5]+delta[i+5]) 
				    + 0.125*cexp(M_PI*I/2.0*((delta[i+4]-gamma[i+3])*pow(yp+1,2)+2.0*(beta[i+3]+beta[i+4]+gamma[i+3]+delta[i+4])*xp*pow(yp+1,2)+2.0*(delta[i+3]+delta[i+4]+beta[i+3]+beta[i+4])*xp*yp+(2.0*beta[i+3]+3.0*delta[i+3]+delta[i+4])*yp))*csqrt(-I)*Gausssum1d(gamma[i+5]+delta[i+5],0)*Kroneck(gamma[i+3]+delta[i+3]-gamma[i+4]-delta[i+4])*Kroneck(alpha[i+5]+beta[i+5])))
			//*(2.0*(0.125*pow(2.0,(1-ypp*pow(gamma[j]-gamma[j+1],2)-pow(ypp-1,2)*pow(gamma[j]-delta[j+1],2))*(1-yppp*pow(gamma[j+3]-gamma[j+4],2)-pow(yppp-1,2)*pow(gamma[j+3]-delta[j+4],2)))*cexp(M_PI*I/2.0*((delta[j+1]-gamma[j])*pow(ypp+1,2)+2.0*(beta[j]+beta[j+1]+gamma[j]+delta[j+1])*xpp*pow(ypp+1,2)+2.0*(delta[j]+delta[j+1]+beta[j]+beta[j+1])*xpp*ypp+(2.0*beta[j]+3.0*delta[j]+delta[j+1])*ypp))*Gausssum1d(0.0,beta[j+2])*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1])*Kroneck(gamma[j+2]+delta[j+2]) 
			*(2.0*(0.125*cexp(M_PI*I/2.0*((delta[j+1]-gamma[j])*pow(ypp+1,2)+2.0*(beta[j]+beta[j+1]+gamma[j]+delta[j+1])*xpp*pow(ypp+1,2)+2.0*(delta[j]+delta[j+1]+beta[j]+beta[j+1])*xpp*ypp+(2.0*beta[j]+3.0*delta[j]+delta[j+1])*ypp))*Gausssum1d(0.0,beta[j+2])*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1])*Kroneck(gamma[j+2]+delta[j+2]) 
			       //+ 0.125*pow(2.0,(1-ypp*pow(gamma[j]-gamma[j+1],2)-pow(ypp-1,2)*pow(gamma[j]-delta[j+1],2))*(1-yppp*pow(gamma[j+3]-gamma[j+4],2)-pow(yppp-1,2)*pow(gamma[j+3]-delta[j+4],2)))*cexp(M_PI*I/2.0*((delta[j+1]-gamma[j])*pow(ypp+1,2)+2.0*(beta[j]+beta[j+1]+gamma[j]+delta[j+1])*xpp*pow(ypp+1,2)+2.0*(delta[j]+delta[j+1]+beta[j]+beta[j+1])*xpp*ypp+(2.0*beta[j]+3.0*delta[j]+delta[j+1])*ypp))*csqrt(-I)*Gausssum1d(gamma[j+2]+delta[j+2],0)*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1])*Kroneck(alpha[j+2]+beta[j+2]))
			       + 0.125*cexp(M_PI*I/2.0*((delta[j+1]-gamma[j])*pow(ypp+1,2)+2.0*(beta[j]+beta[j+1]+gamma[j]+delta[j+1])*xpp*pow(ypp+1,2)+2.0*(delta[j]+delta[j+1]+beta[j]+beta[j+1])*xpp*ypp+(2.0*beta[j]+3.0*delta[j]+delta[j+1])*ypp))*csqrt(-I)*Gausssum1d(gamma[j+2]+delta[j+2],0)*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1])*Kroneck(alpha[j+2]+beta[j+2]))
			*(0.125*cexp(M_PI*I/2.0*((delta[j+4]-gamma[j+3])*pow(yppp+1,2)+2.0*(beta[j+3]+beta[j+4]+gamma[j+3]+delta[j+4])*xppp*pow(yppp+1,2)+2.0*(delta[j+3]+delta[j+4]+beta[j+3]+beta[j+4])*xppp*yppp+(2.0*beta[j+3]+3.0*delta[j+3]+delta[j+4])*yppp))*Gausssum1d(0.0,beta[j+5])*Kroneck(gamma[j+3]+delta[j+3]-gamma[j+4]-delta[j+4])*Kroneck(gamma[j+5]+delta[j+5]) 
			  + 0.125*cexp(M_PI*I/2.0*((delta[j+4]-gamma[j+3])*pow(yppp+1,2)+2.0*(beta[j+3]+beta[j+4]+gamma[j+3]+delta[j+4])*xppp*pow(yppp+1,2)+2.0*(delta[j+3]+delta[j+4]+beta[j+3]+beta[j+4])*xppp*yppp+(2.0*beta[j+3]+3.0*delta[j+3]+delta[j+4])*yppp))*csqrt(-I)*Gausssum1d(gamma[j+5]+delta[j+5],0)*Kroneck(gamma[j+3]+delta[j+3]-gamma[j+4]-delta[j+4])*Kroneck(alpha[j+5]+beta[j+5])));
		    }
		  }
		}
	      }
	      for(ypp=0; ypp<=1; ypp++) {
		//**for(xpp=0;xpp<=(ypp*(gamma[j]+gamma[j+1])+(ypp+1)*(gamma[j]+delta[j+1]))%2; xpp++) {
		for(xpp=ypp*(beta[j]+alpha[j+1]+beta[j+1])%2;xpp<=(ypp*(beta[j]+alpha[j+1]+beta[j+1])+ypp*(gamma[j]+gamma[j+1])+(ypp+1)*(gamma[j]+delta[j+1]))%2; xpp++) {
		  for(yppp=0; yppp<=(1+alpha[j+5])%2; yppp++) {
		    for(xppp=0;xppp<=(1+beta[j+5])%2; xppp++) {
		      summand += (2.0*(0.125*pow(2.0,(1-y*pow(gamma[i]-gamma[i+1],2)-pow(y-1,2)*pow(gamma[i]-delta[i+1],2))*(1-yp*pow(gamma[i+3]-gamma[i+4],2)-pow(yp-1,2)*pow(gamma[i+3]-delta[i+4],2)))*cexp(M_PI*I/2.0*((delta[i+1]-gamma[i])*pow(y+1,2)+2.0*(beta[i]+beta[i+1]+gamma[i]+delta[i+1])*x*pow(y+1,2)+2.0*(delta[i]+delta[i+1]+beta[i]+beta[i+1])*x*y+(2.0*beta[i]+3.0*delta[i]+delta[i+1])*y))*Gausssum1d(0.0,beta[i+2])*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1])*Kroneck(gamma[i+2]+delta[i+2]) 
			  + 0.125*pow(2.0,(1-y*pow(gamma[i]-gamma[i+1],2)-pow(y-1,2)*pow(gamma[i]-delta[i+1],2))*(1-yp*pow(gamma[i+3]-gamma[i+4],2)-pow(yp-1,2)*pow(gamma[i+3]-delta[i+4],2)))*cexp(M_PI*I/2.0*((delta[i+1]-gamma[i])*pow(y+1,2)+2.0*(beta[i]+beta[i+1]+gamma[i]+delta[i+1])*x*pow(y+1,2)+2.0*(delta[i]+delta[i+1]+beta[i]+beta[i+1])*x*y+(2.0*beta[i]+3.0*delta[i]+delta[i+1])*y))*csqrt(-I)*Gausssum1d(gamma[i+2]+delta[i+2],0)*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1])*Kroneck(alpha[i+2]+beta[i+2]))
		*(0.125*cexp(M_PI*I/2.0*((delta[i+4]-gamma[i+3])*pow(yp+1,2)+2.0*(beta[i+3]+beta[i+4]+gamma[i+3]+delta[i+4])*xp*pow(yp+1,2)+2.0*(delta[i+3]+delta[i+4]+beta[i+3]+beta[i+4])*xp*yp+(2.0*beta[i+3]+3.0*delta[i+3]+delta[i+4])*yp))*Gausssum1d(0.0,beta[i+5])*Kroneck(gamma[i+3]+delta[i+3]-gamma[i+4]-delta[i+4])*Kroneck(gamma[i+5]+delta[i+5]) 
		  + 0.125*cexp(M_PI*I/2.0*((delta[i+4]-gamma[i+3])*pow(yp+1,2)+2.0*(beta[i+3]+beta[i+4]+gamma[i+3]+delta[i+4])*xp*pow(yp+1,2)+2.0*(delta[i+3]+delta[i+4]+beta[i+3]+beta[i+4])*xp*yp+(2.0*beta[i+3]+3.0*delta[i+3]+delta[i+4])*yp))*csqrt(-I)*Gausssum1d(gamma[i+5]+delta[i+5],0)*Kroneck(gamma[i+3]+delta[i+3]-gamma[i+4]-delta[i+4])*Kroneck(alpha[i+5]+beta[i+5])))
			*((0.125*pow(2.0,1-ypp*pow(gamma[j]-gamma[j+1],2)-pow(ypp-1,2)*pow(gamma[j]-delta[j+1],2))*cexp(M_PI*I/2.0*((delta[j+1]-gamma[j])*pow(ypp+1,2)+2.0*(beta[j]+beta[j+1]+gamma[j]+delta[j+1])*xpp*pow(ypp+1,2)+2.0*(delta[j]+delta[j+1]+beta[j]+beta[j+1])*xpp*ypp+(2.0*beta[j]+3.0*delta[j]+delta[j+1])*ypp))*Gausssum1d(0.0,beta[j+2])*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1])*Kroneck(gamma[j+2]+delta[j+2]) 
				  + 0.125*pow(2.0,1-ypp*pow(gamma[j]-gamma[j+1],2)-pow(ypp-1,2)*pow(gamma[j]-delta[j+1],2))*cexp(M_PI*I/2.0*((delta[j+1]-gamma[j])*pow(ypp+1,2)+2.0*(beta[j]+beta[j+1]+gamma[j]+delta[j+1])*xpp*pow(ypp+1,2)+2.0*(delta[j]+delta[j+1]+beta[j]+beta[j+1])*xpp*ypp+(2.0*beta[j]+3.0*delta[j]+delta[j+1])*ypp))*csqrt(-I)*Gausssum1d(gamma[j+2]+delta[j+2],0)*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1])*Kroneck(alpha[j+2]+beta[j+2]))
			  *(0.125*2.0*csqrt(-I)*cexp(M_PI*I/2.0*(2.0*beta[j+5]*yppp+pow(xppp+1,2)*(delta[j+3]+gamma[j+4]+2.0*beta[j+4])+xppp*(delta[j+3]+delta[j+4])))*Gausssum1d(1,beta[j+3]+beta[j+4]+delta[j+3]+(xppp+1)*gamma[j+4]+xppp*delta[j+4])*Kroneck(gamma[j+3]+delta[j+3]-gamma[j+4]-delta[j+4]+1)*Kroneck(gamma[j+5]+delta[j+5])));
		    }
		  }
		}
	      }
	      //for(ypp=0; ypp<=1; ypp++) {
	      for(ypp=((gamma[j]+delta[j+1])*(x+xp))%2;ypp<=(1+(gamma[j]+gamma[j+1])*(x+xp))%2;ypp++) {
	      //****for(ypp=((gamma[j]+delta[j+1])*(x*(1+alpha[i]+beta[i])+xp*(1+alpha[i+3]+beta[i+3])))%2;ypp<=(1+(gamma[j]+gamma[j+1])*(x*(1+alpha[i]+beta[i])+xp*(1+alpha[i+3]+beta[i+3])))%2;ypp++) {
		//**for(xpp=0;xpp<=(ypp*(gamma[j]+gamma[j+1])+(ypp+1)*(gamma[j]+delta[j+1]))%2; xpp++) {
		for(xpp=ypp*(beta[j]+alpha[j+1]+beta[j+1])%2;xpp<=(ypp*(beta[j]+alpha[j+1]+beta[j+1])+ypp*(gamma[j]+gamma[j+1])+(ypp+1)*(gamma[j]+delta[j+1]))%2; xpp++) {
		  //for(yppp=xpp; yppp<=1; yppp++) {
		  //**for(yppp=(x+xp+xpp)%2; yppp<=1; yppp++) {
		  for(yppp=(x*(1+alpha[i]+beta[i])+xp*(1+alpha[i+3]+beta[i+3])+xpp*(1+alpha[j]+beta[j]))%2; yppp<=1; yppp++) {
		    //for(xppp=(yppp*(delta[j+3]+delta[j+4])+xpp)%2;xppp<=(1+yppp*(gamma[j+3]+gamma[j+4])+xpp)%2; xppp++) {
		    //**for(xppp=(yppp*(delta[j+3]+delta[j+4])+(x+xp+xpp))%2;xppp<=(1+yppp*(gamma[j+3]+gamma[j+4])+(x+xp+xpp))%2; xppp++) {
		    for(xppp=(yppp*(delta[j+3]+delta[j+4])+(x*(1+alpha[i]+beta[i])+xp*(1+alpha[i+3]+beta[i+3])+xpp*(1+alpha[j]+beta[j])))%2;xppp<=(1+yppp*(gamma[j+3]+gamma[j+4])+(x*(1+alpha[i]+beta[i])+xp*(1+alpha[i+3]+beta[i+3])+xpp*(1+alpha[j]+beta[j])))%2; xppp++) {
		      //summand += 2.0*(2.0*(0.125*pow(2.0,(1-y*pow(gamma[i]-gamma[i+1],2)-pow(y-1,2)*pow(gamma[i]-delta[i+1],2))*(1-yp*pow(gamma[i+3]-gamma[i+4],2)-pow(yp-1,2)*pow(gamma[i+3]-delta[i+4],2)))*cexp(M_PI*I/2.0*((delta[i+1]-gamma[i])*pow(y+1,2)+2.0*(beta[i]+beta[i+1]+gamma[i]+delta[i+1])*x*pow(y+1,2)+2.0*(delta[i]+delta[i+1]+beta[i]+beta[i+1])*x*y+(2.0*beta[i]+3.0*delta[i]+delta[i+1])*y))*Gausssum1d(0.0,beta[i+2])*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1])*Kroneck(gamma[i+2]+delta[i+2]) 
		      summand += 2.0*(2.0*(0.125*pow(2.0,(1-y*pow(gamma[i]-gamma[i+1],2)-pow(y-1,2)*pow(gamma[i]-delta[i+1],2))*(1-yp*pow(gamma[i+3]-gamma[i+4],2)-pow(yp-1,2)*pow(gamma[i+3]-delta[i+4],2))*(1-ypp*pow(gamma[j]-gamma[j+1],2)-pow(ypp-1,2)*pow(gamma[j]-delta[j+1],2))*(pow(yppp-1,2)*(pow(xppp,2)*(gamma[j+3]+delta[j+4])+pow(xppp-1,2)*(gamma[j+4]+delta[j+3]))))*cexp(M_PI*I/2.0*((delta[i+1]-gamma[i])*pow(y+1,2)+2.0*(beta[i]+beta[i+1]+gamma[i]+delta[i+1])*x*pow(y+1,2)+2.0*(delta[i]+delta[i+1]+beta[i]+beta[i+1])*x*y+(2.0*beta[i]+3.0*delta[i]+delta[i+1])*y))*Gausssum1d(0.0,beta[i+2])*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1])*Kroneck(gamma[i+2]+delta[i+2]) 
					   //+ 0.125*pow(2.0,(1-y*pow(gamma[i]-gamma[i+1],2)-pow(y-1,2)*pow(gamma[i]-delta[i+1],2))*(1-yp*pow(gamma[i+3]-gamma[i+4],2)-pow(yp-1,2)*pow(gamma[i+3]-delta[i+4],2)))*cexp(M_PI*I/2.0*((delta[i+1]-gamma[i])*pow(y+1,2)+2.0*(beta[i]+beta[i+1]+gamma[i]+delta[i+1])*x*pow(y+1,2)+2.0*(delta[i]+delta[i+1]+beta[i]+beta[i+1])*x*y+(2.0*beta[i]+3.0*delta[i]+delta[i+1])*y))*csqrt(-I)*Gausssum1d(gamma[i+2]+delta[i+2],0)*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1])*Kroneck(alpha[i+2]+beta[i+2]))
					   + 0.125*pow(2.0,(1-y*pow(gamma[i]-gamma[i+1],2)-pow(y-1,2)*pow(gamma[i]-delta[i+1],2))*(1-yp*pow(gamma[i+3]-gamma[i+4],2)-pow(yp-1,2)*pow(gamma[i+3]-delta[i+4],2))*(1-ypp*pow(gamma[j]-gamma[j+1],2)-pow(ypp-1,2)*pow(gamma[j]-delta[j+1],2))*(pow(yppp-1,2)*(pow(xppp,2)*(gamma[j+3]+delta[j+4])+pow(xppp-1,2)*(gamma[j+4]+delta[j+3]))))*cexp(M_PI*I/2.0*((delta[i+1]-gamma[i])*pow(y+1,2)+2.0*(beta[i]+beta[i+1]+gamma[i]+delta[i+1])*x*pow(y+1,2)+2.0*(delta[i]+delta[i+1]+beta[i]+beta[i+1])*x*y+(2.0*beta[i]+3.0*delta[i]+delta[i+1])*y))*csqrt(-I)*Gausssum1d(gamma[i+2]+delta[i+2],0)*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1])*Kroneck(alpha[i+2]+beta[i+2]))
				  *(0.125*cexp(M_PI*I/2.0*((delta[i+4]-gamma[i+3])*pow(yp+1,2)+2.0*(beta[i+3]+beta[i+4]+gamma[i+3]+delta[i+4])*xp*pow(yp+1,2)+2.0*(delta[i+3]+delta[i+4]+beta[i+3]+beta[i+4])*xp*yp+(2.0*beta[i+3]+3.0*delta[i+3]+delta[i+4])*yp))*Gausssum1d(0.0,beta[i+5])*Kroneck(gamma[i+3]+delta[i+3]-gamma[i+4]-delta[i+4])*Kroneck(gamma[i+5]+delta[i+5]) 
		  + 0.125*cexp(M_PI*I/2.0*((delta[i+4]-gamma[i+3])*pow(yp+1,2)+2.0*(beta[i+3]+beta[i+4]+gamma[i+3]+delta[i+4])*xp*pow(yp+1,2)+2.0*(delta[i+3]+delta[i+4]+beta[i+3]+beta[i+4])*xp*yp+(2.0*beta[i+3]+3.0*delta[i+3]+delta[i+4])*yp))*csqrt(-I)*Gausssum1d(gamma[i+5]+delta[i+5],0)*Kroneck(gamma[i+3]+delta[i+3]-gamma[i+4]-delta[i+4])*Kroneck(alpha[i+5]+beta[i+5])))
			//*(2.0*(0.125*pow(2.0,(1-ypp*pow(gamma[j]-gamma[j+1],2)-pow(ypp-1,2)*pow(gamma[j]-delta[j+1],2))*(pow(yppp-1,2)*(pow(xppp,2)*(gamma[j+3]+delta[j+4])+pow(xppp-1,2)*(gamma[j+4]+delta[j+3]))))*cexp(M_PI*I/2.0*((delta[j+1]-gamma[j])*pow(ypp+1,2)+2.0*(beta[j]+beta[j+1]+gamma[j]+delta[j+1])*xpp*pow(ypp+1,2)+2.0*(delta[j]+delta[j+1]+beta[j]+beta[j+1])*xpp*ypp+(2.0*beta[j]+3.0*delta[j]+delta[j+1])*ypp))*Gausssum1d(0.0,beta[j+2])*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1])*Kroneck(gamma[j+2]+delta[j+2]) 
			*(2.0*(0.125*cexp(M_PI*I/2.0*((delta[j+1]-gamma[j])*pow(ypp+1,2)+2.0*(beta[j]+beta[j+1]+gamma[j]+delta[j+1])*xpp*pow(ypp+1,2)+2.0*(delta[j]+delta[j+1]+beta[j]+beta[j+1])*xpp*ypp+(2.0*beta[j]+3.0*delta[j]+delta[j+1])*ypp))*Gausssum1d(0.0,beta[j+2])*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1])*Kroneck(gamma[j+2]+delta[j+2]) 
			       //+ 0.125*pow(2.0,(1-ypp*pow(gamma[j]-gamma[j+1],2)-pow(ypp-1,2)*pow(gamma[j]-delta[j+1],2))*(pow(yppp-1,2)*(pow(xppp,2)*(gamma[j+3]+delta[j+4])+pow(xppp-1,2)*(gamma[j+4]+delta[j+3]))))*cexp(M_PI*I/2.0*((delta[j+1]-gamma[j])*pow(ypp+1,2)+2.0*(beta[j]+beta[j+1]+gamma[j]+delta[j+1])*xpp*pow(ypp+1,2)+2.0*(delta[j]+delta[j+1]+beta[j]+beta[j+1])*xpp*ypp+(2.0*beta[j]+3.0*delta[j]+delta[j+1])*ypp))*csqrt(-I)*Gausssum1d(gamma[j+2]+delta[j+2],0)*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1])*Kroneck(alpha[j+2]+beta[j+2]))
			       + 0.125*cexp(M_PI*I/2.0*((delta[j+1]-gamma[j])*pow(ypp+1,2)+2.0*(beta[j]+beta[j+1]+gamma[j]+delta[j+1])*xpp*pow(ypp+1,2)+2.0*(delta[j]+delta[j+1]+beta[j]+beta[j+1])*xpp*ypp+(2.0*beta[j]+3.0*delta[j]+delta[j+1])*ypp))*csqrt(-I)*Gausssum1d(gamma[j+2]+delta[j+2],0)*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1])*Kroneck(alpha[j+2]+beta[j+2]))
			  *(0.125*(-I)*cexp(M_PI*I/2.0*(yppp*(delta[j+3]+delta[j+4])+pow(yppp+1,2)*(delta[j+3]+gamma[j+4]+2*beta[j+4])+pow(xppp,2)+2*(beta[j+3]+beta[j+4]+delta[j+3]+gamma[j+4]*(yppp+1)+delta[j+4]*yppp)*xppp))*Gausssum1d(0,xppp+beta[j+3]+beta[j+4]+delta[j+3]+gamma[j+4]*(yppp+1)+delta[j+4]*yppp+gamma[j+5]+delta[j+5])*Kroneck(gamma[j+3]+delta[j+3]-gamma[j+4]-delta[j+4]+1)*Kroneck(alpha[j+5]+beta[j+5])));
		    }
		  }
		}
	      }
	      
	      for(ypp=0; ypp<=(1+alpha[j+2])%2; ypp++) {
		for(xpp=0; xpp<=(1+beta[j+2])%2; xpp++) {
		  for(yppp=0; yppp<=1; yppp++) {
		    //**for(xppp=0;xppp<=(yppp*(gamma[j+3]+gamma[j+4])+(yppp+1)*(gamma[j+3]+delta[j+4]))%2; xppp++) {
		    for(xppp=yppp*(beta[j+3]+alpha[j+4]+beta[j+4])%2;xppp<=(yppp*(beta[j+3]+alpha[j+4]+beta[j+4])+yppp*(gamma[j+3]+gamma[j+4])+(yppp+1)*(gamma[j+3]+delta[j+4]))%2; xppp++) {
		      summand += (2.0*(0.125*pow(2.0,(1-y*pow(gamma[i]-gamma[i+1],2)-pow(y-1,2)*pow(gamma[i]-delta[i+1],2))*(1-yp*pow(gamma[i+3]-gamma[i+4],2)-pow(yp-1,2)*pow(gamma[i+3]-delta[i+4],2)))*cexp(M_PI*I/2.0*((delta[i+1]-gamma[i])*pow(y+1,2)+2.0*(beta[i]+beta[i+1]+gamma[i]+delta[i+1])*x*pow(y+1,2)+2.0*(delta[i]+delta[i+1]+beta[i]+beta[i+1])*x*y+(2.0*beta[i]+3.0*delta[i]+delta[i+1])*y))*Gausssum1d(0.0,beta[i+2])*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1])*Kroneck(gamma[i+2]+delta[i+2]) 
			  + 0.125*pow(2.0,(1-y*pow(gamma[i]-gamma[i+1],2)-pow(y-1,2)*pow(gamma[i]-delta[i+1],2))*(1-yp*pow(gamma[i+3]-gamma[i+4],2)-pow(yp-1,2)*pow(gamma[i+3]-delta[i+4],2)))*cexp(M_PI*I/2.0*((delta[i+1]-gamma[i])*pow(y+1,2)+2.0*(beta[i]+beta[i+1]+gamma[i]+delta[i+1])*x*pow(y+1,2)+2.0*(delta[i]+delta[i+1]+beta[i]+beta[i+1])*x*y+(2.0*beta[i]+3.0*delta[i]+delta[i+1])*y))*csqrt(-I)*Gausssum1d(gamma[i+2]+delta[i+2],0)*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1])*Kroneck(alpha[i+2]+beta[i+2]))
		*(0.125*cexp(M_PI*I/2.0*((delta[i+4]-gamma[i+3])*pow(yp+1,2)+2.0*(beta[i+3]+beta[i+4]+gamma[i+3]+delta[i+4])*xp*pow(yp+1,2)+2.0*(delta[i+3]+delta[i+4]+beta[i+3]+beta[i+4])*xp*yp+(2.0*beta[i+3]+3.0*delta[i+3]+delta[i+4])*yp))*Gausssum1d(0.0,beta[i+5])*Kroneck(gamma[i+3]+delta[i+3]-gamma[i+4]-delta[i+4])*Kroneck(gamma[i+5]+delta[i+5]) 
		  + 0.125*cexp(M_PI*I/2.0*((delta[i+4]-gamma[i+3])*pow(yp+1,2)+2.0*(beta[i+3]+beta[i+4]+gamma[i+3]+delta[i+4])*xp*pow(yp+1,2)+2.0*(delta[i+3]+delta[i+4]+beta[i+3]+beta[i+4])*xp*yp+(2.0*beta[i+3]+3.0*delta[i+3]+delta[i+4])*yp))*csqrt(-I)*Gausssum1d(gamma[i+5]+delta[i+5],0)*Kroneck(gamma[i+3]+delta[i+3]-gamma[i+4]-delta[i+4])*Kroneck(alpha[i+5]+beta[i+5])))
			*((0.125*2.0*csqrt(-I)*cexp(M_PI*I/2.0*(2.0*beta[j+2]*ypp+pow(xpp+1,2)*(delta[j]+gamma[j+1]+2.0*beta[j+1])+xpp*(delta[j]+delta[j+1])))*Gausssum1d(1,beta[j]+beta[j+1]+delta[j]+(xpp+1)*gamma[j+1]+xpp*delta[j+1])*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1]+1)*Kroneck(gamma[j+2]+delta[j+2]))
			  *(0.125*pow(2.0,1-yppp*pow(gamma[j+3]-gamma[j+4],2)-pow(yppp-1,2)*pow(gamma[j+3]-delta[j+4],2))*cexp(M_PI*I/2.0*((delta[j+4]-gamma[j+3])*pow(yppp+1,2)+2.0*(beta[j+3]+beta[j+4]+gamma[j+3]+delta[j+4])*xppp*pow(yppp+1,2)+2.0*(delta[j+3]+delta[j+4]+beta[j+3]+beta[j+4])*xppp*yppp+(2.0*beta[j+3]+3.0*delta[j+3]+delta[j+4])*yppp))*Gausssum1d(0.0,beta[j+5])*Kroneck(gamma[j+3]+delta[j+3]-gamma[j+4]-delta[j+4])*Kroneck(gamma[j+5]+delta[j+5]) 
			    + 0.125*pow(2.0,1-yppp*pow(gamma[j+3]-gamma[j+4],2)-pow(yppp-1,2)*pow(gamma[j+3]-delta[j+4],2))*cexp(M_PI*I/2.0*((delta[j+4]-gamma[j+3])*pow(yppp+1,2)+2.0*(beta[j+3]+beta[j+4]+gamma[j+3]+delta[j+4])*xppp*pow(yppp+1,2)+2.0*(delta[j+3]+delta[j+4]+beta[j+3]+beta[j+4])*xppp*yppp+(2.0*beta[j+3]+3.0*delta[j+3]+delta[j+4])*yppp))*csqrt(-I)*Gausssum1d(gamma[j+5]+delta[j+5],0)*Kroneck(gamma[j+3]+delta[j+3]-gamma[j+4]-delta[j+4])*Kroneck(alpha[j+5]+beta[j+5])));
		    }
		  }
		  for(yppp=0; yppp<=(1+alpha[j+5])%2; yppp++) {
		    for(xppp=0;xppp<=(1+beta[j+5])%2; xppp++) {
		      summand += (2.0*(0.125*pow(2.0,(1-y*pow(gamma[i]-gamma[i+1],2)-pow(y-1,2)*pow(gamma[i]-delta[i+1],2))*(1-yp*pow(gamma[i+3]-gamma[i+4],2)-pow(yp-1,2)*pow(gamma[i+3]-delta[i+4],2)))*cexp(M_PI*I/2.0*((delta[i+1]-gamma[i])*pow(y+1,2)+2.0*(beta[i]+beta[i+1]+gamma[i]+delta[i+1])*x*pow(y+1,2)+2.0*(delta[i]+delta[i+1]+beta[i]+beta[i+1])*x*y+(2.0*beta[i]+3.0*delta[i]+delta[i+1])*y))*Gausssum1d(0.0,beta[i+2])*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1])*Kroneck(gamma[i+2]+delta[i+2]) 
			  + 0.125*pow(2.0,(1-y*pow(gamma[i]-gamma[i+1],2)-pow(y-1,2)*pow(gamma[i]-delta[i+1],2))*(1-yp*pow(gamma[i+3]-gamma[i+4],2)-pow(yp-1,2)*pow(gamma[i+3]-delta[i+4],2)))*cexp(M_PI*I/2.0*((delta[i+1]-gamma[i])*pow(y+1,2)+2.0*(beta[i]+beta[i+1]+gamma[i]+delta[i+1])*x*pow(y+1,2)+2.0*(delta[i]+delta[i+1]+beta[i]+beta[i+1])*x*y+(2.0*beta[i]+3.0*delta[i]+delta[i+1])*y))*csqrt(-I)*Gausssum1d(gamma[i+2]+delta[i+2],0)*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1])*Kroneck(alpha[i+2]+beta[i+2]))
		*(0.125*cexp(M_PI*I/2.0*((delta[i+4]-gamma[i+3])*pow(yp+1,2)+2.0*(beta[i+3]+beta[i+4]+gamma[i+3]+delta[i+4])*xp*pow(yp+1,2)+2.0*(delta[i+3]+delta[i+4]+beta[i+3]+beta[i+4])*xp*yp+(2.0*beta[i+3]+3.0*delta[i+3]+delta[i+4])*yp))*Gausssum1d(0.0,beta[i+5])*Kroneck(gamma[i+3]+delta[i+3]-gamma[i+4]-delta[i+4])*Kroneck(gamma[i+5]+delta[i+5]) 
		  + 0.125*cexp(M_PI*I/2.0*((delta[i+4]-gamma[i+3])*pow(yp+1,2)+2.0*(beta[i+3]+beta[i+4]+gamma[i+3]+delta[i+4])*xp*pow(yp+1,2)+2.0*(delta[i+3]+delta[i+4]+beta[i+3]+beta[i+4])*xp*yp+(2.0*beta[i+3]+3.0*delta[i+3]+delta[i+4])*yp))*csqrt(-I)*Gausssum1d(gamma[i+5]+delta[i+5],0)*Kroneck(gamma[i+3]+delta[i+3]-gamma[i+4]-delta[i+4])*Kroneck(alpha[i+5]+beta[i+5])))
			*((0.125*2.0*csqrt(-I)*cexp(M_PI*I/2.0*(2.0*beta[j+2]*ypp+pow(xpp+1,2)*(delta[j]+gamma[j+1]+2.0*beta[j+1])+xpp*(delta[j]+delta[j+1])))*Gausssum1d(1,beta[j]+beta[j+1]+delta[j]+(xpp+1)*gamma[j+1]+xpp*delta[j+1])*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1]+1)*Kroneck(gamma[j+2]+delta[j+2]))
			  *(0.125*2.0*csqrt(-I)*cexp(M_PI*I/2.0*(2.0*beta[j+5]*yppp+pow(xppp+1,2)*(delta[j+3]+gamma[j+4]+2.0*beta[j+4])+xppp*(delta[j+3]+delta[j+4])))*Gausssum1d(1,beta[j+3]+beta[j+4]+delta[j+3]+(xppp+1)*gamma[j+4]+xppp*delta[j+4])*Kroneck(gamma[j+3]+delta[j+3]-gamma[j+4]-delta[j+4]+1)*Kroneck(gamma[j+5]+delta[j+5])));
		    }
		  }
		  for(yppp=0; yppp<=1; yppp++) {
		    for(xppp=(yppp*(delta[j+3]+delta[j+4]))%2;xppp<=(1+yppp*(gamma[j+3]+gamma[j+4]))%2; xppp++) {
		      summand += (2.0*(0.125*pow(2.0,(1-y*pow(gamma[i]-gamma[i+1],2)-pow(y-1,2)*pow(gamma[i]-delta[i+1],2))*(1-yp*pow(gamma[i+3]-gamma[i+4],2)-pow(yp-1,2)*pow(gamma[i+3]-delta[i+4],2)))*cexp(M_PI*I/2.0*((delta[i+1]-gamma[i])*pow(y+1,2)+2.0*(beta[i]+beta[i+1]+gamma[i]+delta[i+1])*x*pow(y+1,2)+2.0*(delta[i]+delta[i+1]+beta[i]+beta[i+1])*x*y+(2.0*beta[i]+3.0*delta[i]+delta[i+1])*y))*Gausssum1d(0.0,beta[i+2])*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1])*Kroneck(gamma[i+2]+delta[i+2]) 
			  + 0.125*pow(2.0,(1-y*pow(gamma[i]-gamma[i+1],2)-pow(y-1,2)*pow(gamma[i]-delta[i+1],2))*(1-yp*pow(gamma[i+3]-gamma[i+4],2)-pow(yp-1,2)*pow(gamma[i+3]-delta[i+4],2)))*cexp(M_PI*I/2.0*((delta[i+1]-gamma[i])*pow(y+1,2)+2.0*(beta[i]+beta[i+1]+gamma[i]+delta[i+1])*x*pow(y+1,2)+2.0*(delta[i]+delta[i+1]+beta[i]+beta[i+1])*x*y+(2.0*beta[i]+3.0*delta[i]+delta[i+1])*y))*csqrt(-I)*Gausssum1d(gamma[i+2]+delta[i+2],0)*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1])*Kroneck(alpha[i+2]+beta[i+2]))
		*(0.125*cexp(M_PI*I/2.0*((delta[i+4]-gamma[i+3])*pow(yp+1,2)+2.0*(beta[i+3]+beta[i+4]+gamma[i+3]+delta[i+4])*xp*pow(yp+1,2)+2.0*(delta[i+3]+delta[i+4]+beta[i+3]+beta[i+4])*xp*yp+(2.0*beta[i+3]+3.0*delta[i+3]+delta[i+4])*yp))*Gausssum1d(0.0,beta[i+5])*Kroneck(gamma[i+3]+delta[i+3]-gamma[i+4]-delta[i+4])*Kroneck(gamma[i+5]+delta[i+5]) 
		  + 0.125*cexp(M_PI*I/2.0*((delta[i+4]-gamma[i+3])*pow(yp+1,2)+2.0*(beta[i+3]+beta[i+4]+gamma[i+3]+delta[i+4])*xp*pow(yp+1,2)+2.0*(delta[i+3]+delta[i+4]+beta[i+3]+beta[i+4])*xp*yp+(2.0*beta[i+3]+3.0*delta[i+3]+delta[i+4])*yp))*csqrt(-I)*Gausssum1d(gamma[i+5]+delta[i+5],0)*Kroneck(gamma[i+3]+delta[i+3]-gamma[i+4]-delta[i+4])*Kroneck(alpha[i+5]+beta[i+5])))
			*((0.125*2.0*csqrt(-I)*cexp(M_PI*I/2.0*(2.0*beta[j+2]*ypp+pow(xpp+1,2)*(delta[j]+gamma[j+1]+2.0*beta[j+1])+xpp*(delta[j]+delta[j+1])))*Gausssum1d(1,beta[j]+beta[j+1]+delta[j]+(xpp+1)*gamma[j+1]+xpp*delta[j+1])*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1]+1)*Kroneck(gamma[j+2]+delta[j+2]))
			  *(0.125*(-I)*pow(2.0,(pow(yppp-1,2)*(pow(xppp,2)*(gamma[j+3]+delta[j+4])+pow(xppp-1,2)*(gamma[j+4]+delta[j+3]))))*cexp(M_PI*I/2.0*(yppp*(delta[j+3]+delta[j+4])+pow(yppp+1,2)*(delta[j+3]+gamma[j+4]+2*beta[j+4])+pow(xppp,2)+2*(beta[j+3]+beta[j+4]+delta[j+3]+gamma[j+4]*(yppp+1)+delta[j+4]*yppp)*xppp))*Gausssum1d(0,xppp+beta[j+3]+beta[j+4]+delta[j+3]+gamma[j+4]*(yppp+1)+delta[j+4]*yppp+gamma[j+5]+delta[j+5])*Kroneck(gamma[j+3]+delta[j+3]-gamma[j+4]-delta[j+4]+1)*Kroneck(alpha[j+5]+beta[j+5])));
		    }
		  }
		}
	      }

	      //for(ypp=0; ypp<=1; ypp++) {
	      //**for(ypp=(x+xp)%2; ypp<=1; ypp++) {
	      for(ypp=(x*(1+alpha[i]+beta[i])+xp*(1+alpha[i+3]+beta[i+3]))%2; ypp<=1; ypp++) {
		//for(xpp=(ypp*(delta[j]+delta[j+1]))%2; xpp<=(1+ypp*(gamma[j]+gamma[j+1]))%2; xpp++) {
		//**for(xpp=(ypp*(delta[j]+delta[j+1])+x+xp)%2; xpp<=(1+ypp*(gamma[j]+gamma[j+1])+x+xp)%2; xpp++) {
		for(xpp=(ypp*(delta[j]+delta[j+1])+x*(1+alpha[i]+beta[i])+xp*(1+alpha[i+3]+beta[i+3]))%2; xpp<=(1+ypp*(gamma[j]+gamma[j+1])+x*(1+alpha[i]+beta[i])+xp*(1+alpha[i+3]+beta[i+3]))%2; xpp++) {
		  //for(yppp=((gamma[j+3]+delta[j+4])*ypp)%2; yppp<=(1+(gamma[j+3]+gamma[j+4])*ypp)%2; yppp++) {
		  for(yppp=((gamma[j+3]+delta[j+4])*(x+xp+ypp))%2; yppp<=(1+(gamma[j+3]+gamma[j+4])*(x+xp+ypp))%2; yppp++) {
		  //****for(yppp=((gamma[j+3]+delta[j+4])*(x*(1+alpha[i]+beta[i])+xp*(1+alpha[i+3]+beta[i+3])+ypp))%2; yppp<=(1+(gamma[j+3]+gamma[j+4])*(x*(1+alpha[i]+beta[i])+xp*(1+alpha[i+3]+beta[i+3])+ypp))%2; yppp++) {
		    //**for(xppp=0;xppp<=(yppp*(gamma[j+3]+gamma[j+4])+(yppp+1)*(gamma[j+3]+delta[j+4]))%2; xppp++) {
		    for(xppp=yppp*(beta[j+3]+alpha[j+4]+beta[j+4])%2;xppp<=(yppp*(beta[j+3]+alpha[j+4]+beta[j+4])+yppp*(gamma[j+3]+gamma[j+4])+(yppp+1)*(gamma[j+3]+delta[j+4]))%2; xppp++) {
		      //summand += (2.0*(0.125*pow(2.0,(1-y*pow(gamma[i]-gamma[i+1],2)-pow(y-1,2)*pow(gamma[i]-delta[i+1],2))*(1-yp*pow(gamma[i+3]-gamma[i+4],2)-pow(yp-1,2)*pow(gamma[i+3]-delta[i+4],2)))*cexp(M_PI*I/2.0*((delta[i+1]-gamma[i])*pow(y+1,2)+2.0*(beta[i]+beta[i+1]+gamma[i]+delta[i+1])*x*pow(y+1,2)+2.0*(delta[i]+delta[i+1]+beta[i]+beta[i+1])*x*y+(2.0*beta[i]+3.0*delta[i]+delta[i+1])*y))*Gausssum1d(0.0,beta[i+2])*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1])*Kroneck(gamma[i+2]+delta[i+2]) 
		      summand += 2.0*(2.0*(0.125*pow(2.0,(1-y*pow(gamma[i]-gamma[i+1],2)-pow(y-1,2)*pow(gamma[i]-delta[i+1],2))*(1-yp*pow(gamma[i+3]-gamma[i+4],2)-pow(yp-1,2)*pow(gamma[i+3]-delta[i+4],2))*(pow(ypp-1,2)*(pow(xpp,2)*(gamma[j]+delta[j+1])+pow(xpp-1,2)*(gamma[j+1]+delta[j])))*(1-yppp*pow(gamma[j+3]-gamma[j+4],2)-pow(yppp-1,2)*pow(gamma[j+3]-delta[j+4],2)))*cexp(M_PI*I/2.0*((delta[i+1]-gamma[i])*pow(y+1,2)+2.0*(beta[i]+beta[i+1]+gamma[i]+delta[i+1])*x*pow(y+1,2)+2.0*(delta[i]+delta[i+1]+beta[i]+beta[i+1])*x*y+(2.0*beta[i]+3.0*delta[i]+delta[i+1])*y))*Gausssum1d(0.0,beta[i+2])*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1])*Kroneck(gamma[i+2]+delta[i+2]) 
				       //+ 0.125*pow(2.0,(1-y*pow(gamma[i]-gamma[i+1],2)-pow(y-1,2)*pow(gamma[i]-delta[i+1],2))*(1-yp*pow(gamma[i+3]-gamma[i+4],2)-pow(yp-1,2)*pow(gamma[i+3]-delta[i+4],2)))*cexp(M_PI*I/2.0*((delta[i+1]-gamma[i])*pow(y+1,2)+2.0*(beta[i]+beta[i+1]+gamma[i]+delta[i+1])*x*pow(y+1,2)+2.0*(delta[i]+delta[i+1]+beta[i]+beta[i+1])*x*y+(2.0*beta[i]+3.0*delta[i]+delta[i+1])*y))*csqrt(-I)*Gausssum1d(gamma[i+2]+delta[i+2],0)*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1])*Kroneck(alpha[i+2]+beta[i+2]))
					   + 0.125*pow(2.0,(1-y*pow(gamma[i]-gamma[i+1],2)-pow(y-1,2)*pow(gamma[i]-delta[i+1],2))*(1-yp*pow(gamma[i+3]-gamma[i+4],2)-pow(yp-1,2)*pow(gamma[i+3]-delta[i+4],2))*(pow(ypp-1,2)*(pow(xpp,2)*(gamma[j]+delta[j+1])+pow(xpp-1,2)*(gamma[j+1]+delta[j])))*(1-yppp*pow(gamma[j+3]-gamma[j+4],2)-pow(yppp-1,2)*pow(gamma[j+3]-delta[j+4],2)))*cexp(M_PI*I/2.0*((delta[i+1]-gamma[i])*pow(y+1,2)+2.0*(beta[i]+beta[i+1]+gamma[i]+delta[i+1])*x*pow(y+1,2)+2.0*(delta[i]+delta[i+1]+beta[i]+beta[i+1])*x*y+(2.0*beta[i]+3.0*delta[i]+delta[i+1])*y))*csqrt(-I)*Gausssum1d(gamma[i+2]+delta[i+2],0)*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1])*Kroneck(alpha[i+2]+beta[i+2]))
		*(0.125*cexp(M_PI*I/2.0*((delta[i+4]-gamma[i+3])*pow(yp+1,2)+2.0*(beta[i+3]+beta[i+4]+gamma[i+3]+delta[i+4])*xp*pow(yp+1,2)+2.0*(delta[i+3]+delta[i+4]+beta[i+3]+beta[i+4])*xp*yp+(2.0*beta[i+3]+3.0*delta[i+3]+delta[i+4])*yp))*Gausssum1d(0.0,beta[i+5])*Kroneck(gamma[i+3]+delta[i+3]-gamma[i+4]-delta[i+4])*Kroneck(gamma[i+5]+delta[i+5]) 
		  + 0.125*cexp(M_PI*I/2.0*((delta[i+4]-gamma[i+3])*pow(yp+1,2)+2.0*(beta[i+3]+beta[i+4]+gamma[i+3]+delta[i+4])*xp*pow(yp+1,2)+2.0*(delta[i+3]+delta[i+4]+beta[i+3]+beta[i+4])*xp*yp+(2.0*beta[i+3]+3.0*delta[i+3]+delta[i+4])*yp))*csqrt(-I)*Gausssum1d(gamma[i+5]+delta[i+5],0)*Kroneck(gamma[i+3]+delta[i+3]-gamma[i+4]-delta[i+4])*Kroneck(alpha[i+5]+beta[i+5])))
			//*(2.0*(0.125*pow(2.0,(pow(ypp-1,2)*(pow(xpp,2)*(gamma[j]+delta[j+1])+pow(xpp-1,2)*(gamma[j+1]+delta[j])))*(1-yppp*pow(gamma[j+3]-gamma[j+4],2)-pow(yppp-1,2)*pow(gamma[j+3]-delta[j+4],2)))*(-I)*cexp(M_PI*I/2.0*(ypp*(delta[j]+delta[j+1])+pow(ypp+1,2)*(delta[j]+gamma[j+1]+2*beta[j+1])+pow(xpp,2)+2*(beta[j]+beta[j+1]+delta[j]+gamma[j+1]*(ypp+1)+delta[j+1]*ypp)*xpp))*Gausssum1d(0,xpp+beta[j]+beta[j+1]+delta[j]+gamma[j+1]*(ypp+1)+delta[j+1]*ypp+gamma[j+2]+delta[j+2])*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1]+1)*Kroneck(alpha[j+2]+beta[j+2]))
			*(2.0*(0.125*(-I)*cexp(M_PI*I/2.0*(ypp*(delta[j]+delta[j+1])+pow(ypp+1,2)*(delta[j]+gamma[j+1]+2*beta[j+1])+pow(xpp,2)+2*(beta[j]+beta[j+1]+delta[j]+gamma[j+1]*(ypp+1)+delta[j+1]*ypp)*xpp))*Gausssum1d(0,xpp+beta[j]+beta[j+1]+delta[j]+gamma[j+1]*(ypp+1)+delta[j+1]*ypp+gamma[j+2]+delta[j+2])*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1]+1)*Kroneck(alpha[j+2]+beta[j+2]))
			  *(0.125*cexp(M_PI*I/2.0*((delta[j+4]-gamma[j+3])*pow(yppp+1,2)+2.0*(beta[j+3]+beta[j+4]+gamma[j+3]+delta[j+4])*xppp*pow(yppp+1,2)+2.0*(delta[j+3]+delta[j+4]+beta[j+3]+beta[j+4])*xppp*yppp+(2.0*beta[j+3]+3.0*delta[j+3]+delta[j+4])*yppp))*Gausssum1d(0.0,beta[j+5])*Kroneck(gamma[j+3]+delta[j+3]-gamma[j+4]-delta[j+4])*Kroneck(gamma[j+5]+delta[j+5]) 
			    + 0.125*cexp(M_PI*I/2.0*((delta[j+4]-gamma[j+3])*pow(yppp+1,2)+2.0*(beta[j+3]+beta[j+4]+gamma[j+3]+delta[j+4])*xppp*pow(yppp+1,2)+2.0*(delta[j+3]+delta[j+4]+beta[j+3]+beta[j+4])*xppp*yppp+(2.0*beta[j+3]+3.0*delta[j+3]+delta[j+4])*yppp))*csqrt(-I)*Gausssum1d(gamma[j+5]+delta[j+5],0)*Kroneck(gamma[j+3]+delta[j+3]-gamma[j+4]-delta[j+4])*Kroneck(alpha[j+5]+beta[j+5])));
		    }
		  }
		}
	      }
	      for(ypp=0; ypp<=1; ypp++) {
		for(xpp=(ypp*(delta[j]+delta[j+1]))%2; xpp<=(1+ypp*(gamma[j]+gamma[j+1]))%2; xpp++) {
		  for(yppp=0; yppp<=(1+alpha[j+5])%2; yppp++) {
		    for(xppp=0;xppp<=(1+beta[j+5])%2; xppp++) {
		      summand += (2.0*(0.125*pow(2.0,(1-y*pow(gamma[i]-gamma[i+1],2)-pow(y-1,2)*pow(gamma[i]-delta[i+1],2))*(1-yp*pow(gamma[i+3]-gamma[i+4],2)-pow(yp-1,2)*pow(gamma[i+3]-delta[i+4],2)))*cexp(M_PI*I/2.0*((delta[i+1]-gamma[i])*pow(y+1,2)+2.0*(beta[i]+beta[i+1]+gamma[i]+delta[i+1])*x*pow(y+1,2)+2.0*(delta[i]+delta[i+1]+beta[i]+beta[i+1])*x*y+(2.0*beta[i]+3.0*delta[i]+delta[i+1])*y))*Gausssum1d(0.0,beta[i+2])*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1])*Kroneck(gamma[i+2]+delta[i+2]) 
				       + 0.125*pow(2.0,(1-y*pow(gamma[i]-gamma[i+1],2)-pow(y-1,2)*pow(gamma[i]-delta[i+1],2))*(1-yp*pow(gamma[i+3]-gamma[i+4],2)-pow(yp-1,2)*pow(gamma[i+3]-delta[i+4],2)))*cexp(M_PI*I/2.0*((delta[i+1]-gamma[i])*pow(y+1,2)+2.0*(beta[i]+beta[i+1]+gamma[i]+delta[i+1])*x*pow(y+1,2)+2.0*(delta[i]+delta[i+1]+beta[i]+beta[i+1])*x*y+(2.0*beta[i]+3.0*delta[i]+delta[i+1])*y))*csqrt(-I)*Gausssum1d(gamma[i+2]+delta[i+2],0)*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1])*Kroneck(alpha[i+2]+beta[i+2]))
				  *(0.125*cexp(M_PI*I/2.0*((delta[i+4]-gamma[i+3])*pow(yp+1,2)+2.0*(beta[i+3]+beta[i+4]+gamma[i+3]+delta[i+4])*xp*pow(yp+1,2)+2.0*(delta[i+3]+delta[i+4]+beta[i+3]+beta[i+4])*xp*yp+(2.0*beta[i+3]+3.0*delta[i+3]+delta[i+4])*yp))*Gausssum1d(0.0,beta[i+5])*Kroneck(gamma[i+3]+delta[i+3]-gamma[i+4]-delta[i+4])*Kroneck(gamma[i+5]+delta[i+5]) 
				    + 0.125*cexp(M_PI*I/2.0*((delta[i+4]-gamma[i+3])*pow(yp+1,2)+2.0*(beta[i+3]+beta[i+4]+gamma[i+3]+delta[i+4])*xp*pow(yp+1,2)+2.0*(delta[i+3]+delta[i+4]+beta[i+3]+beta[i+4])*xp*yp+(2.0*beta[i+3]+3.0*delta[i+3]+delta[i+4])*yp))*csqrt(-I)*Gausssum1d(gamma[i+5]+delta[i+5],0)*Kroneck(gamma[i+3]+delta[i+3]-gamma[i+4]-delta[i+4])*Kroneck(alpha[i+5]+beta[i+5])))
			*((0.125*pow(2.0,pow(ypp-1,2)*(pow(xpp,2)*(gamma[j]+delta[j+1])+pow(xpp-1,2)*(gamma[j+1]+delta[j])))*(-I)*cexp(M_PI*I/2.0*(ypp*(delta[j]+delta[j+1])+pow(ypp+1,2)*(delta[j]+gamma[j+1]+2*beta[j+1])+pow(xpp,2)+2*(beta[j]+beta[j+1]+delta[j]+gamma[j+1]*(ypp+1)+delta[j+1]*ypp)*xpp))*Gausssum1d(0,xpp+beta[j]+beta[j+1]+delta[j]+gamma[j+1]*(ypp+1)+delta[j+1]*ypp+gamma[j+2]+delta[j+2])*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1]+1)*Kroneck(alpha[j+2]+beta[j+2]))
			  *(0.125*2.0*csqrt(-I)*cexp(M_PI*I/2.0*(2.0*beta[j+5]*yppp+pow(xppp+1,2)*(delta[j+3]+gamma[j+4]+2.0*beta[j+4])+xppp*(delta[j+3]+delta[j+4])))*Gausssum1d(1,beta[j+3]+beta[j+4]+delta[j+3]+(xppp+1)*gamma[j+4]+xppp*delta[j+4])*Kroneck(gamma[j+3]+delta[j+3]-gamma[j+4]-delta[j+4]+1)*Kroneck(gamma[j+5]+delta[j+5])));
		    }
		  }
		}
	      }
	      //for(ypp=0; ypp<=1; ypp++) {
	      //**for(ypp=(x+xp)%2; ypp<=1; ypp++) {
	      for(ypp=(x*(1+alpha[i]+beta[i])+xp*(1+alpha[i+3]+beta[i+3]))%2; ypp<=1; ypp++) {
		//for(xpp=(ypp*(delta[j]+delta[j+1]))%2; xpp<=(1+ypp*(gamma[j]+gamma[j+1]))%2; xpp++) {
		//**for(xpp=(ypp*(delta[j]+delta[j+1])+x+xp)%2; xpp<=(1+ypp*(gamma[j]+gamma[j+1])+x+xp)%2; xpp++) {
		for(xpp=(ypp*(delta[j]+delta[j+1])+x*(1+alpha[i]+beta[i])+xp*(1+alpha[i+3]+beta[i+3]))%2; xpp<=(1+ypp*(gamma[j]+gamma[j+1])+x*(1+alpha[i]+beta[i])+xp*(1+alpha[i+3]+beta[i+3]))%2; xpp++) {
		  //for(yppp=ypp; yppp<=1; yppp++) {
		  //**for(yppp=(x+xp+ypp)%2; yppp<=1; yppp++) {
		  for(yppp=(x*(1+alpha[i]+beta[i])+xp*(1+alpha[i+3]+beta[i+3])+ypp)%2; yppp<=1; yppp++) {
		    //for(xppp=(yppp*(delta[j+3]+delta[j+4])+ypp)%2;xppp<=(1+yppp*(gamma[j+3]+gamma[j+4])+ypp)%2; xppp++) {
		    //**for(xppp=(yppp*(delta[j+3]+delta[j+4])+x+xp+ypp)%2;xppp<=(1+yppp*(gamma[j+3]+gamma[j+4])+x+xp+ypp)%2; xppp++) {
		    for(xppp=(yppp*(delta[j+3]+delta[j+4])+x*(1+alpha[i]+beta[i])+xp*(1+alpha[i+3]+beta[i+3])+ypp)%2;xppp<=(1+yppp*(gamma[j+3]+gamma[j+4])+x*(1+alpha[i]+beta[i])+xp*(1+alpha[i+3]+beta[i+3])+ypp)%2; xppp++) {
		      //summand += (2.0*(0.125*pow(2.0,(1-y*pow(gamma[i]-gamma[i+1],2)-pow(y-1,2)*pow(gamma[i]-delta[i+1],2))*(1-yp*pow(gamma[i+3]-gamma[i+4],2)-pow(yp-1,2)*pow(gamma[i+3]-delta[i+4],2)))*cexp(M_PI*I/2.0*((delta[i+1]-gamma[i])*pow(y+1,2)+2.0*(beta[i]+beta[i+1]+gamma[i]+delta[i+1])*x*pow(y+1,2)+2.0*(delta[i]+delta[i+1]+beta[i]+beta[i+1])*x*y+(2.0*beta[i]+3.0*delta[i]+delta[i+1])*y))*Gausssum1d(0.0,beta[i+2])*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1])*Kroneck(gamma[i+2]+delta[i+2]) 
		      summand += 2.0*(2.0*(0.125*pow(2.0,(1-y*pow(gamma[i]-gamma[i+1],2)-pow(y-1,2)*pow(gamma[i]-delta[i+1],2))*(1-yp*pow(gamma[i+3]-gamma[i+4],2)-pow(yp-1,2)*pow(gamma[i+3]-delta[i+4],2))*(pow(ypp-1,2)*(pow(xpp,2)*(gamma[j]+delta[j+1])+pow(xpp-1,2)*(gamma[j+1]+delta[j])))*(pow(yppp-1,2)*(pow(xppp,2)*(gamma[j+3]+delta[j+4])+pow(xppp-1,2)*(gamma[j+4]+delta[j+3]))))*cexp(M_PI*I/2.0*((delta[i+1]-gamma[i])*pow(y+1,2)+2.0*(beta[i]+beta[i+1]+gamma[i]+delta[i+1])*x*pow(y+1,2)+2.0*(delta[i]+delta[i+1]+beta[i]+beta[i+1])*x*y+(2.0*beta[i]+3.0*delta[i]+delta[i+1])*y))*Gausssum1d(0.0,beta[i+2])*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1])*Kroneck(gamma[i+2]+delta[i+2]) 
				       //+ 0.125*pow(2.0,(1-y*pow(gamma[i]-gamma[i+1],2)-pow(y-1,2)*pow(gamma[i]-delta[i+1],2))*(1-yp*pow(gamma[i+3]-gamma[i+4],2)-pow(yp-1,2)*pow(gamma[i+3]-delta[i+4],2)))*cexp(M_PI*I/2.0*((delta[i+1]-gamma[i])*pow(y+1,2)+2.0*(beta[i]+beta[i+1]+gamma[i]+delta[i+1])*x*pow(y+1,2)+2.0*(delta[i]+delta[i+1]+beta[i]+beta[i+1])*x*y+(2.0*beta[i]+3.0*delta[i]+delta[i+1])*y))*csqrt(-I)*Gausssum1d(gamma[i+2]+delta[i+2],0)*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1])*Kroneck(alpha[i+2]+beta[i+2]))
				       + 0.125*pow(2.0,(1-y*pow(gamma[i]-gamma[i+1],2)-pow(y-1,2)*pow(gamma[i]-delta[i+1],2))*(1-yp*pow(gamma[i+3]-gamma[i+4],2)-pow(yp-1,2)*pow(gamma[i+3]-delta[i+4],2))*(pow(ypp-1,2)*(pow(xpp,2)*(gamma[j]+delta[j+1])+pow(xpp-1,2)*(gamma[j+1]+delta[j])))*(pow(yppp-1,2)*(pow(xppp,2)*(gamma[j+3]+delta[j+4])+pow(xppp-1,2)*(gamma[j+4]+delta[j+3]))))*cexp(M_PI*I/2.0*((delta[i+1]-gamma[i])*pow(y+1,2)+2.0*(beta[i]+beta[i+1]+gamma[i]+delta[i+1])*x*pow(y+1,2)+2.0*(delta[i]+delta[i+1]+beta[i]+beta[i+1])*x*y+(2.0*beta[i]+3.0*delta[i]+delta[i+1])*y))*csqrt(-I)*Gausssum1d(gamma[i+2]+delta[i+2],0)*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1])*Kroneck(alpha[i+2]+beta[i+2]))
		*(0.125*cexp(M_PI*I/2.0*((delta[i+4]-gamma[i+3])*pow(yp+1,2)+2.0*(beta[i+3]+beta[i+4]+gamma[i+3]+delta[i+4])*xp*pow(yp+1,2)+2.0*(delta[i+3]+delta[i+4]+beta[i+3]+beta[i+4])*xp*yp+(2.0*beta[i+3]+3.0*delta[i+3]+delta[i+4])*yp))*Gausssum1d(0.0,beta[i+5])*Kroneck(gamma[i+3]+delta[i+3]-gamma[i+4]-delta[i+4])*Kroneck(gamma[i+5]+delta[i+5]) 
		  + 0.125*cexp(M_PI*I/2.0*((delta[i+4]-gamma[i+3])*pow(yp+1,2)+2.0*(beta[i+3]+beta[i+4]+gamma[i+3]+delta[i+4])*xp*pow(yp+1,2)+2.0*(delta[i+3]+delta[i+4]+beta[i+3]+beta[i+4])*xp*yp+(2.0*beta[i+3]+3.0*delta[i+3]+delta[i+4])*yp))*csqrt(-I)*Gausssum1d(gamma[i+5]+delta[i+5],0)*Kroneck(gamma[i+3]+delta[i+3]-gamma[i+4]-delta[i+4])*Kroneck(alpha[i+5]+beta[i+5])))
			//*(2.0*(0.125*pow(2.0,(pow(ypp-1,2)*(pow(xpp,2)*(gamma[j]+delta[j+1])+pow(xpp-1,2)*(gamma[j+1]+delta[j])))*(pow(yppp-1,2)*(pow(xppp,2)*(gamma[j+3]+delta[j+4])+pow(xppp-1,2)*(gamma[j+4]+delta[j+3]))))*(-I)*cexp(M_PI*I/2.0*(ypp*(delta[j]+delta[j+1])+pow(ypp+1,2)*(delta[j]+gamma[j+1]+2*beta[j+1])+pow(xpp,2)+2*(beta[j]+beta[j+1]+delta[j]+gamma[j+1]*(ypp+1)+delta[j+1]*ypp)*xpp))*Gausssum1d(0,xpp+beta[j]+beta[j+1]+delta[j]+gamma[j+1]*(ypp+1)+delta[j+1]*ypp+gamma[j+2]+delta[j+2])*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1]+1)*Kroneck(alpha[j+2]+beta[j+2]))
			*(2.0*(0.125*(-I)*cexp(M_PI*I/2.0*(ypp*(delta[j]+delta[j+1])+pow(ypp+1,2)*(delta[j]+gamma[j+1]+2*beta[j+1])+pow(xpp,2)+2*(beta[j]+beta[j+1]+delta[j]+gamma[j+1]*(ypp+1)+delta[j+1]*ypp)*xpp))*Gausssum1d(0,xpp+beta[j]+beta[j+1]+delta[j]+gamma[j+1]*(ypp+1)+delta[j+1]*ypp+gamma[j+2]+delta[j+2])*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1]+1)*Kroneck(alpha[j+2]+beta[j+2]))
			  *(0.125*(-I)*cexp(M_PI*I/2.0*(yppp*(delta[j+3]+delta[j+4])+pow(yppp+1,2)*(delta[j+3]+gamma[j+4]+2*beta[j+4])+pow(xppp,2)+2*(beta[j+3]+beta[j+4]+delta[j+3]+gamma[j+4]*(yppp+1)+delta[j+4]*yppp)*xppp))*Gausssum1d(0,xppp+beta[j+3]+beta[j+4]+delta[j+3]+gamma[j+4]*(yppp+1)+delta[j+4]*yppp+gamma[j+5]+delta[j+5])*Kroneck(gamma[j+3]+delta[j+3]-gamma[j+4]-delta[j+4]+1)*Kroneck(alpha[j+5]+beta[j+5])));
		    }
		  }
		}
	      }
	    }
	  }
	}
      }
      
      
      // second term
      for(y=0; y<=1; y++) {
      	//**for(x=0;x<=(y*(gamma[i]+gamma[i+1])+(y+1)*(gamma[i]+delta[i+1]))%2; x++) {
      	for(x=y*(beta[i]+alpha[i+1]+beta[i+1])%2;x<=(y*(beta[i]+alpha[i+1]+beta[i+1])+y*(gamma[i]+gamma[i+1])+(y+1)*(gamma[i]+delta[i+1]))%2; x++) {
	  for(yp=0; yp<=(1+alpha[i+5])%2; yp++) {
	    for(xp=0;xp<=(1+beta[i+5])%2; xp++) {
	      for(ypp=0; ypp<=1; ypp++) {
		//**for(xpp=0;xpp<=(ypp*(gamma[j]+gamma[j+1])+(ypp+1)*(gamma[j]+delta[j+1]))%2; xpp++) {
		for(xpp=ypp*(beta[j]+alpha[j+1]+beta[j+1])%2;xpp<=(ypp*(beta[j]+alpha[j+1]+beta[j+1])+ypp*(gamma[j]+gamma[j+1])+(ypp+1)*(gamma[j]+delta[j+1]))%2; xpp++) {
		  for(yppp=((gamma[j+3]+delta[j+4])*xpp)%2; yppp<=(1+(gamma[j+3]+gamma[j+4])*xpp)%2; yppp++) {
		    //**for(xppp=0;xppp<=(yppp*(gamma[j+3]+gamma[j+4])+(yppp+1)*(gamma[j+3]+delta[j+4]))%2; xppp++) {
		    for(xppp=yppp*(beta[j+3]+alpha[j+4]+beta[j+4])%2;xppp<=(yppp*(beta[j+3]+alpha[j+4]+beta[j+4])+yppp*(gamma[j+3]+gamma[j+4])+(yppp+1)*(gamma[j+3]+delta[j+4]))%2; xppp++) {
		      summand += ((0.125*pow(2.0,1-y*pow(gamma[i]-gamma[i+1],2)-pow(y-1,2)*pow(gamma[i]-delta[i+1],2))*cexp(M_PI*I/2.0*((delta[i+1]-gamma[i])*pow(y+1,2)+2.0*(beta[i]+beta[i+1]+gamma[i]+delta[i+1])*x*pow(y+1,2)+2.0*(delta[i]+delta[i+1]+beta[i]+beta[i+1])*x*y+(2.0*beta[i]+3.0*delta[i]+delta[i+1])*y))*Gausssum1d(0.0,beta[i+2])*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1])*Kroneck(gamma[i+2]+delta[i+2]) 
			  + 0.125*pow(2.0,1-y*pow(gamma[i]-gamma[i+1],2)-pow(y-1,2)*pow(gamma[i]-delta[i+1],2))*cexp(M_PI*I/2.0*((delta[i+1]-gamma[i])*pow(y+1,2)+2.0*(beta[i]+beta[i+1]+gamma[i]+delta[i+1])*x*pow(y+1,2)+2.0*(delta[i]+delta[i+1]+beta[i]+beta[i+1])*x*y+(2.0*beta[i]+3.0*delta[i]+delta[i+1])*y))*csqrt(-I)*Gausssum1d(gamma[i+2]+delta[i+2],0)*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1])*Kroneck(alpha[i+2]+beta[i+2]))
				  *(0.125*2.0*csqrt(-I)*cexp(M_PI*I/2.0*(2.0*beta[i+5]*yp+pow(xp+1,2)*(delta[i+3]+gamma[i+4]+2.0*beta[i+4])+xp*(delta[i+3]+delta[i+4])))*Gausssum1d(1,beta[i+3]+beta[i+4]+delta[i+3]+(xp+1)*gamma[i+4]+xp*delta[i+4])*Kroneck(gamma[i+3]+delta[i+3]-gamma[i+4]-delta[i+4]+1)*Kroneck(gamma[i+5]+delta[i+5])))
			*(2.0*(0.125*pow(2.0,(1-ypp*pow(gamma[j]-gamma[j+1],2)-pow(ypp-1,2)*pow(gamma[j]-delta[j+1],2))*(1-yppp*pow(gamma[j+3]-gamma[j+4],2)-pow(yppp-1,2)*pow(gamma[j+3]-delta[j+4],2)))*cexp(M_PI*I/2.0*((delta[j+1]-gamma[j])*pow(ypp+1,2)+2.0*(beta[j]+beta[j+1]+gamma[j]+delta[j+1])*xpp*pow(ypp+1,2)+2.0*(delta[j]+delta[j+1]+beta[j]+beta[j+1])*xpp*ypp+(2.0*beta[j]+3.0*delta[j]+delta[j+1])*ypp))*Gausssum1d(0.0,beta[j+2])*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1])*Kroneck(gamma[j+2]+delta[j+2]) 
			      + 0.125*pow(2.0,(1-ypp*pow(gamma[j]-gamma[j+1],2)-pow(ypp-1,2)*pow(gamma[j]-delta[j+1],2))*(1-yppp*pow(gamma[j+3]-gamma[j+4],2)-pow(yppp-1,2)*pow(gamma[j+3]-delta[j+4],2)))*cexp(M_PI*I/2.0*((delta[j+1]-gamma[j])*pow(ypp+1,2)+2.0*(beta[j]+beta[j+1]+gamma[j]+delta[j+1])*xpp*pow(ypp+1,2)+2.0*(delta[j]+delta[j+1]+beta[j]+beta[j+1])*xpp*ypp+(2.0*beta[j]+3.0*delta[j]+delta[j+1])*ypp))*csqrt(-I)*Gausssum1d(gamma[j+2]+delta[j+2],0)*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1])*Kroneck(alpha[j+2]+beta[j+2]))
			*(0.125*cexp(M_PI*I/2.0*((delta[j+4]-gamma[j+3])*pow(yppp+1,2)+2.0*(beta[j+3]+beta[j+4]+gamma[j+3]+delta[j+4])*xppp*pow(yppp+1,2)+2.0*(delta[j+3]+delta[j+4]+beta[j+3]+beta[j+4])*xppp*yppp+(2.0*beta[j+3]+3.0*delta[j+3]+delta[j+4])*yppp))*Gausssum1d(0.0,beta[j+5])*Kroneck(gamma[j+3]+delta[j+3]-gamma[j+4]-delta[j+4])*Kroneck(gamma[j+5]+delta[j+5]) 
			  + 0.125*cexp(M_PI*I/2.0*((delta[j+4]-gamma[j+3])*pow(yppp+1,2)+2.0*(beta[j+3]+beta[j+4]+gamma[j+3]+delta[j+4])*xppp*pow(yppp+1,2)+2.0*(delta[j+3]+delta[j+4]+beta[j+3]+beta[j+4])*xppp*yppp+(2.0*beta[j+3]+3.0*delta[j+3]+delta[j+4])*yppp))*csqrt(-I)*Gausssum1d(gamma[j+5]+delta[j+5],0)*Kroneck(gamma[j+3]+delta[j+3]-gamma[j+4]-delta[j+4])*Kroneck(alpha[j+5]+beta[j+5])));
		    }
		  }
		  for(yppp=0; yppp<=(1+alpha[j+5])%2; yppp++) {
		    for(xppp=0;xppp<=(1+beta[j+5])%2; xppp++) {
		      summand += ((0.125*pow(2.0,1-y*pow(gamma[i]-gamma[i+1],2)-pow(y-1,2)*pow(gamma[i]-delta[i+1],2))*cexp(M_PI*I/2.0*((delta[i+1]-gamma[i])*pow(y+1,2)+2.0*(beta[i]+beta[i+1]+gamma[i]+delta[i+1])*x*pow(y+1,2)+2.0*(delta[i]+delta[i+1]+beta[i]+beta[i+1])*x*y+(2.0*beta[i]+3.0*delta[i]+delta[i+1])*y))*Gausssum1d(0.0,beta[i+2])*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1])*Kroneck(gamma[i+2]+delta[i+2]) 
			  + 0.125*pow(2.0,1-y*pow(gamma[i]-gamma[i+1],2)-pow(y-1,2)*pow(gamma[i]-delta[i+1],2))*cexp(M_PI*I/2.0*((delta[i+1]-gamma[i])*pow(y+1,2)+2.0*(beta[i]+beta[i+1]+gamma[i]+delta[i+1])*x*pow(y+1,2)+2.0*(delta[i]+delta[i+1]+beta[i]+beta[i+1])*x*y+(2.0*beta[i]+3.0*delta[i]+delta[i+1])*y))*csqrt(-I)*Gausssum1d(gamma[i+2]+delta[i+2],0)*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1])*Kroneck(alpha[i+2]+beta[i+2]))
				  *(0.125*2.0*csqrt(-I)*cexp(M_PI*I/2.0*(2.0*beta[i+5]*yp+pow(xp+1,2)*(delta[i+3]+gamma[i+4]+2.0*beta[i+4])+xp*(delta[i+3]+delta[i+4])))*Gausssum1d(1,beta[i+3]+beta[i+4]+delta[i+3]+(xp+1)*gamma[i+4]+xp*delta[i+4])*Kroneck(gamma[i+3]+delta[i+3]-gamma[i+4]-delta[i+4]+1)*Kroneck(gamma[i+5]+delta[i+5])))
			*((0.125*pow(2.0,1-ypp*pow(gamma[j]-gamma[j+1],2)-pow(ypp-1,2)*pow(gamma[j]-delta[j+1],2))*cexp(M_PI*I/2.0*((delta[j+1]-gamma[j])*pow(ypp+1,2)+2.0*(beta[j]+beta[j+1]+gamma[j]+delta[j+1])*xpp*pow(ypp+1,2)+2.0*(delta[j]+delta[j+1]+beta[j]+beta[j+1])*xpp*ypp+(2.0*beta[j]+3.0*delta[j]+delta[j+1])*ypp))*Gausssum1d(0.0,beta[j+2])*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1])*Kroneck(gamma[j+2]+delta[j+2]) 
				  + 0.125*pow(2.0,1-ypp*pow(gamma[j]-gamma[j+1],2)-pow(ypp-1,2)*pow(gamma[j]-delta[j+1],2))*cexp(M_PI*I/2.0*((delta[j+1]-gamma[j])*pow(ypp+1,2)+2.0*(beta[j]+beta[j+1]+gamma[j]+delta[j+1])*xpp*pow(ypp+1,2)+2.0*(delta[j]+delta[j+1]+beta[j]+beta[j+1])*xpp*ypp+(2.0*beta[j]+3.0*delta[j]+delta[j+1])*ypp))*csqrt(-I)*Gausssum1d(gamma[j+2]+delta[j+2],0)*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1])*Kroneck(alpha[j+2]+beta[j+2]))
			  *(0.125*2.0*csqrt(-I)*cexp(M_PI*I/2.0*(2.0*beta[j+5]*yppp+pow(xppp+1,2)*(delta[j+3]+gamma[j+4]+2.0*beta[j+4])+xppp*(delta[j+3]+delta[j+4])))*Gausssum1d(1,beta[j+3]+beta[j+4]+delta[j+3]+(xppp+1)*gamma[j+4]+xppp*delta[j+4])*Kroneck(gamma[j+3]+delta[j+3]-gamma[j+4]-delta[j+4]+1)*Kroneck(gamma[j+5]+delta[j+5])));
		    }
		  }
		  //**for(yppp=xpp; yppp<=1; yppp++) {
		  for(yppp=xpp*(1+alpha[j]+beta[j])%2; yppp<=1; yppp++) {
		    //**for(xppp=(yppp*(delta[j+3]+delta[j+4])+xpp)%2;xppp<=(1+yppp*(gamma[j+3]+gamma[j+4])+xpp)%2; xppp++) {
		    for(xppp=(yppp*(delta[j+3]+delta[j+4])+xpp*(1+alpha[j]+beta[j]))%2;xppp<=(1+yppp*(gamma[j+3]+gamma[j+4])+xpp*(1+alpha[j]+beta[j]))%2; xppp++) {
		      summand += ((0.125*pow(2.0,1-y*pow(gamma[i]-gamma[i+1],2)-pow(y-1,2)*pow(gamma[i]-delta[i+1],2))*cexp(M_PI*I/2.0*((delta[i+1]-gamma[i])*pow(y+1,2)+2.0*(beta[i]+beta[i+1]+gamma[i]+delta[i+1])*x*pow(y+1,2)+2.0*(delta[i]+delta[i+1]+beta[i]+beta[i+1])*x*y+(2.0*beta[i]+3.0*delta[i]+delta[i+1])*y))*Gausssum1d(0.0,beta[i+2])*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1])*Kroneck(gamma[i+2]+delta[i+2]) 
			  + 0.125*pow(2.0,1-y*pow(gamma[i]-gamma[i+1],2)-pow(y-1,2)*pow(gamma[i]-delta[i+1],2))*cexp(M_PI*I/2.0*((delta[i+1]-gamma[i])*pow(y+1,2)+2.0*(beta[i]+beta[i+1]+gamma[i]+delta[i+1])*x*pow(y+1,2)+2.0*(delta[i]+delta[i+1]+beta[i]+beta[i+1])*x*y+(2.0*beta[i]+3.0*delta[i]+delta[i+1])*y))*csqrt(-I)*Gausssum1d(gamma[i+2]+delta[i+2],0)*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1])*Kroneck(alpha[i+2]+beta[i+2]))
				  *(0.125*2.0*csqrt(-I)*cexp(M_PI*I/2.0*(2.0*beta[i+5]*yp+pow(xp+1,2)*(delta[i+3]+gamma[i+4]+2.0*beta[i+4])+xp*(delta[i+3]+delta[i+4])))*Gausssum1d(1,beta[i+3]+beta[i+4]+delta[i+3]+(xp+1)*gamma[i+4]+xp*delta[i+4])*Kroneck(gamma[i+3]+delta[i+3]-gamma[i+4]-delta[i+4]+1)*Kroneck(gamma[i+5]+delta[i+5])))
			*(2.0*(0.125*pow(2.0,(1-ypp*pow(gamma[j]-gamma[j+1],2)-pow(ypp-1,2)*pow(gamma[j]-delta[j+1],2))*(pow(yppp-1,2)*(pow(xppp,2)*(gamma[j+3]+delta[j+4])+pow(xppp-1,2)*(gamma[j+4]+delta[j+3]))))*cexp(M_PI*I/2.0*((delta[j+1]-gamma[j])*pow(ypp+1,2)+2.0*(beta[j]+beta[j+1]+gamma[j]+delta[j+1])*xpp*pow(ypp+1,2)+2.0*(delta[j]+delta[j+1]+beta[j]+beta[j+1])*xpp*ypp+(2.0*beta[j]+3.0*delta[j]+delta[j+1])*ypp))*Gausssum1d(0.0,beta[j+2])*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1])*Kroneck(gamma[j+2]+delta[j+2]) 
				      + 0.125*pow(2.0,(1-ypp*pow(gamma[j]-gamma[j+1],2)-pow(ypp-1,2)*pow(gamma[j]-delta[j+1],2))*(pow(yppp-1,2)*(pow(xppp,2)*(gamma[j+3]+delta[j+4])+pow(xppp-1,2)*(gamma[j+4]+delta[j+3]))))*cexp(M_PI*I/2.0*((delta[j+1]-gamma[j])*pow(ypp+1,2)+2.0*(beta[j]+beta[j+1]+gamma[j]+delta[j+1])*xpp*pow(ypp+1,2)+2.0*(delta[j]+delta[j+1]+beta[j]+beta[j+1])*xpp*ypp+(2.0*beta[j]+3.0*delta[j]+delta[j+1])*ypp))*csqrt(-I)*Gausssum1d(gamma[j+2]+delta[j+2],0)*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1])*Kroneck(alpha[j+2]+beta[j+2]))
			  *(0.125*(-I)*cexp(M_PI*I/2.0*(yppp*(delta[j+3]+delta[j+4])+pow(yppp+1,2)*(delta[j+3]+gamma[j+4]+2*beta[j+4])+pow(xppp,2)+2*(beta[j+3]+beta[j+4]+delta[j+3]+gamma[j+4]*(yppp+1)+delta[j+4]*yppp)*xppp))*Gausssum1d(0,xppp+beta[j+3]+beta[j+4]+delta[j+3]+gamma[j+4]*(yppp+1)+delta[j+4]*yppp+gamma[j+5]+delta[j+5])*Kroneck(gamma[j+3]+delta[j+3]-gamma[j+4]-delta[j+4]+1)*Kroneck(alpha[j+5]+beta[j+5])));
		    }
		  }
		}
	      }

	      for(ypp=0; ypp<=(1+alpha[j+2])%2; ypp++) {
		for(xpp=0; xpp<=(1+beta[j+2])%2; xpp++) {
		  for(yppp=0; yppp<=1; yppp++) {
		    //**for(xppp=0;xppp<=(yppp*(gamma[j+3]+gamma[j+4])+(yppp+1)*(gamma[j+3]+delta[j+4]))%2; xppp++) {
		    for(xppp=yppp*(beta[j+3]+alpha[j+4]+beta[j+4])%2;xppp<=(yppp*(beta[j+3]+alpha[j+4]+beta[j+4])+yppp*(gamma[j+3]+gamma[j+4])+(yppp+1)*(gamma[j+3]+delta[j+4]))%2; xppp++) {
		      summand += ((0.125*pow(2.0,1-y*pow(gamma[i]-gamma[i+1],2)-pow(y-1,2)*pow(gamma[i]-delta[i+1],2))*cexp(M_PI*I/2.0*((delta[i+1]-gamma[i])*pow(y+1,2)+2.0*(beta[i]+beta[i+1]+gamma[i]+delta[i+1])*x*pow(y+1,2)+2.0*(delta[i]+delta[i+1]+beta[i]+beta[i+1])*x*y+(2.0*beta[i]+3.0*delta[i]+delta[i+1])*y))*Gausssum1d(0.0,beta[i+2])*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1])*Kroneck(gamma[i+2]+delta[i+2]) 
			  + 0.125*pow(2.0,1-y*pow(gamma[i]-gamma[i+1],2)-pow(y-1,2)*pow(gamma[i]-delta[i+1],2))*cexp(M_PI*I/2.0*((delta[i+1]-gamma[i])*pow(y+1,2)+2.0*(beta[i]+beta[i+1]+gamma[i]+delta[i+1])*x*pow(y+1,2)+2.0*(delta[i]+delta[i+1]+beta[i]+beta[i+1])*x*y+(2.0*beta[i]+3.0*delta[i]+delta[i+1])*y))*csqrt(-I)*Gausssum1d(gamma[i+2]+delta[i+2],0)*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1])*Kroneck(alpha[i+2]+beta[i+2]))
				  *(0.125*2.0*csqrt(-I)*cexp(M_PI*I/2.0*(2.0*beta[i+5]*yp+pow(xp+1,2)*(delta[i+3]+gamma[i+4]+2.0*beta[i+4])+xp*(delta[i+3]+delta[i+4])))*Gausssum1d(1,beta[i+3]+beta[i+4]+delta[i+3]+(xp+1)*gamma[i+4]+xp*delta[i+4])*Kroneck(gamma[i+3]+delta[i+3]-gamma[i+4]-delta[i+4]+1)*Kroneck(gamma[i+5]+delta[i+5])))
			*((0.125*2.0*csqrt(-I)*cexp(M_PI*I/2.0*(2.0*beta[j+2]*ypp+pow(xpp+1,2)*(delta[j]+gamma[j+1]+2.0*beta[j+1])+xpp*(delta[j]+delta[j+1])))*Gausssum1d(1,beta[j]+beta[j+1]+delta[j]+(xpp+1)*gamma[j+1]+xpp*delta[j+1])*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1]+1)*Kroneck(gamma[j+2]+delta[j+2]))
			  *(0.125*pow(2.0,1-yppp*pow(gamma[j+3]-gamma[j+4],2)-pow(yppp-1,2)*pow(gamma[j+3]-delta[j+4],2))*cexp(M_PI*I/2.0*((delta[j+4]-gamma[j+3])*pow(yppp+1,2)+2.0*(beta[j+3]+beta[j+4]+gamma[j+3]+delta[j+4])*xppp*pow(yppp+1,2)+2.0*(delta[j+3]+delta[j+4]+beta[j+3]+beta[j+4])*xppp*yppp+(2.0*beta[j+3]+3.0*delta[j+3]+delta[j+4])*yppp))*Gausssum1d(0.0,beta[j+5])*Kroneck(gamma[j+3]+delta[j+3]-gamma[j+4]-delta[j+4])*Kroneck(gamma[j+5]+delta[j+5]) 
			    + 0.125*pow(2.0,1-yppp*pow(gamma[j+3]-gamma[j+4],2)-pow(yppp-1,2)*pow(gamma[j+3]-delta[j+4],2))*cexp(M_PI*I/2.0*((delta[j+4]-gamma[j+3])*pow(yppp+1,2)+2.0*(beta[j+3]+beta[j+4]+gamma[j+3]+delta[j+4])*xppp*pow(yppp+1,2)+2.0*(delta[j+3]+delta[j+4]+beta[j+3]+beta[j+4])*xppp*yppp+(2.0*beta[j+3]+3.0*delta[j+3]+delta[j+4])*yppp))*csqrt(-I)*Gausssum1d(gamma[j+5]+delta[j+5],0)*Kroneck(gamma[j+3]+delta[j+3]-gamma[j+4]-delta[j+4])*Kroneck(alpha[j+5]+beta[j+5])));
		    }
		  }
		  for(yppp=0; yppp<=(1+alpha[j+5])%2; yppp++) {
		    for(xppp=0;xppp<=(1+beta[j+5])%2; xppp++) {
		      summand += ((0.125*pow(2.0,1-y*pow(gamma[i]-gamma[i+1],2)-pow(y-1,2)*pow(gamma[i]-delta[i+1],2))*cexp(M_PI*I/2.0*((delta[i+1]-gamma[i])*pow(y+1,2)+2.0*(beta[i]+beta[i+1]+gamma[i]+delta[i+1])*x*pow(y+1,2)+2.0*(delta[i]+delta[i+1]+beta[i]+beta[i+1])*x*y+(2.0*beta[i]+3.0*delta[i]+delta[i+1])*y))*Gausssum1d(0.0,beta[i+2])*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1])*Kroneck(gamma[i+2]+delta[i+2]) 
			  + 0.125*pow(2.0,1-y*pow(gamma[i]-gamma[i+1],2)-pow(y-1,2)*pow(gamma[i]-delta[i+1],2))*cexp(M_PI*I/2.0*((delta[i+1]-gamma[i])*pow(y+1,2)+2.0*(beta[i]+beta[i+1]+gamma[i]+delta[i+1])*x*pow(y+1,2)+2.0*(delta[i]+delta[i+1]+beta[i]+beta[i+1])*x*y+(2.0*beta[i]+3.0*delta[i]+delta[i+1])*y))*csqrt(-I)*Gausssum1d(gamma[i+2]+delta[i+2],0)*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1])*Kroneck(alpha[i+2]+beta[i+2]))
				  *(0.125*2.0*csqrt(-I)*cexp(M_PI*I/2.0*(2.0*beta[i+5]*yp+pow(xp+1,2)*(delta[i+3]+gamma[i+4]+2.0*beta[i+4])+xp*(delta[i+3]+delta[i+4])))*Gausssum1d(1,beta[i+3]+beta[i+4]+delta[i+3]+(xp+1)*gamma[i+4]+xp*delta[i+4])*Kroneck(gamma[i+3]+delta[i+3]-gamma[i+4]-delta[i+4]+1)*Kroneck(gamma[i+5]+delta[i+5])))
			*((0.125*2.0*csqrt(-I)*cexp(M_PI*I/2.0*(2.0*beta[j+2]*ypp+pow(xpp+1,2)*(delta[j]+gamma[j+1]+2.0*beta[j+1])+xpp*(delta[j]+delta[j+1])))*Gausssum1d(1,beta[j]+beta[j+1]+delta[j]+(xpp+1)*gamma[j+1]+xpp*delta[j+1])*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1]+1)*Kroneck(gamma[j+2]+delta[j+2]))
			  *(0.125*2.0*csqrt(-I)*cexp(M_PI*I/2.0*(2.0*beta[j+5]*yppp+pow(xppp+1,2)*(delta[j+3]+gamma[j+4]+2.0*beta[j+4])+xppp*(delta[j+3]+delta[j+4])))*Gausssum1d(1,beta[j+3]+beta[j+4]+delta[j+3]+(xppp+1)*gamma[j+4]+xppp*delta[j+4])*Kroneck(gamma[j+3]+delta[j+3]-gamma[j+4]-delta[j+4]+1)*Kroneck(gamma[j+5]+delta[j+5])));
		    }
		  }
		  for(yppp=0; yppp<=1; yppp++) {
		    for(xppp=(yppp*(delta[j+3]+delta[j+4]))%2;xppp<=(1+yppp*(gamma[j+3]+gamma[j+4]))%2; xppp++) {
		      summand += ((0.125*pow(2.0,1-y*pow(gamma[i]-gamma[i+1],2)-pow(y-1,2)*pow(gamma[i]-delta[i+1],2))*cexp(M_PI*I/2.0*((delta[i+1]-gamma[i])*pow(y+1,2)+2.0*(beta[i]+beta[i+1]+gamma[i]+delta[i+1])*x*pow(y+1,2)+2.0*(delta[i]+delta[i+1]+beta[i]+beta[i+1])*x*y+(2.0*beta[i]+3.0*delta[i]+delta[i+1])*y))*Gausssum1d(0.0,beta[i+2])*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1])*Kroneck(gamma[i+2]+delta[i+2]) 
			  + 0.125*pow(2.0,1-y*pow(gamma[i]-gamma[i+1],2)-pow(y-1,2)*pow(gamma[i]-delta[i+1],2))*cexp(M_PI*I/2.0*((delta[i+1]-gamma[i])*pow(y+1,2)+2.0*(beta[i]+beta[i+1]+gamma[i]+delta[i+1])*x*pow(y+1,2)+2.0*(delta[i]+delta[i+1]+beta[i]+beta[i+1])*x*y+(2.0*beta[i]+3.0*delta[i]+delta[i+1])*y))*csqrt(-I)*Gausssum1d(gamma[i+2]+delta[i+2],0)*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1])*Kroneck(alpha[i+2]+beta[i+2]))
				  *(0.125*2.0*csqrt(-I)*cexp(M_PI*I/2.0*(2.0*beta[i+5]*yp+pow(xp+1,2)*(delta[i+3]+gamma[i+4]+2.0*beta[i+4])+xp*(delta[i+3]+delta[i+4])))*Gausssum1d(1,beta[i+3]+beta[i+4]+delta[i+3]+(xp+1)*gamma[i+4]+xp*delta[i+4])*Kroneck(gamma[i+3]+delta[i+3]-gamma[i+4]-delta[i+4]+1)*Kroneck(gamma[i+5]+delta[i+5])))
			*((0.125*2.0*csqrt(-I)*cexp(M_PI*I/2.0*(2.0*beta[j+2]*ypp+pow(xpp+1,2)*(delta[j]+gamma[j+1]+2.0*beta[j+1])+xpp*(delta[j]+delta[j+1])))*Gausssum1d(1,beta[j]+beta[j+1]+delta[j]+(xpp+1)*gamma[j+1]+xpp*delta[j+1])*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1]+1)*Kroneck(gamma[j+2]+delta[j+2]))
			  *(0.125*(-I)*pow(2.0,(pow(yppp-1,2)*(pow(xppp,2)*(gamma[j+3]+delta[j+4])+pow(xppp-1,2)*(gamma[j+4]+delta[j+3]))))*cexp(M_PI*I/2.0*(yppp*(delta[j+3]+delta[j+4])+pow(yppp+1,2)*(delta[j+3]+gamma[j+4]+2*beta[j+4])+pow(xppp,2)+2*(beta[j+3]+beta[j+4]+delta[j+3]+gamma[j+4]*(yppp+1)+delta[j+4]*yppp)*xppp))*Gausssum1d(0,xppp+beta[j+3]+beta[j+4]+delta[j+3]+gamma[j+4]*(yppp+1)+delta[j+4]*yppp+gamma[j+5]+delta[j+5])*Kroneck(gamma[j+3]+delta[j+3]-gamma[j+4]-delta[j+4]+1)*Kroneck(alpha[j+5]+beta[j+5])));
		    }
		  }
		}
	      }

	      for(ypp=0; ypp<=1; ypp++) {
		for(xpp=(ypp*(delta[j]+delta[j+1]))%2; xpp<=(1+ypp*(gamma[j]+gamma[j+1]))%2; xpp++) {
		  for(yppp=((gamma[j+3]+delta[j+4])*ypp)%2; yppp<=(1+(gamma[j+3]+gamma[j+4])*ypp)%2; yppp++) {
		    //**for(xppp=0;xppp<=(yppp*(gamma[j+3]+gamma[j+4])+(yppp+1)*(gamma[j+3]+delta[j+4]))%2; xppp++) {
		    for(xppp=yppp*(beta[j+3]+alpha[j+4]+beta[j+4])%2;xppp<=(yppp*(beta[j+3]+alpha[j+4]+beta[j+4])+yppp*(gamma[j+3]+gamma[j+4])+(yppp+1)*(gamma[j+3]+delta[j+4]))%2; xppp++) {
		      summand += ((0.125*pow(2.0,1-y*pow(gamma[i]-gamma[i+1],2)-pow(y-1,2)*pow(gamma[i]-delta[i+1],2))*cexp(M_PI*I/2.0*((delta[i+1]-gamma[i])*pow(y+1,2)+2.0*(beta[i]+beta[i+1]+gamma[i]+delta[i+1])*x*pow(y+1,2)+2.0*(delta[i]+delta[i+1]+beta[i]+beta[i+1])*x*y+(2.0*beta[i]+3.0*delta[i]+delta[i+1])*y))*Gausssum1d(0.0,beta[i+2])*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1])*Kroneck(gamma[i+2]+delta[i+2]) 
			  + 0.125*pow(2.0,1-y*pow(gamma[i]-gamma[i+1],2)-pow(y-1,2)*pow(gamma[i]-delta[i+1],2))*cexp(M_PI*I/2.0*((delta[i+1]-gamma[i])*pow(y+1,2)+2.0*(beta[i]+beta[i+1]+gamma[i]+delta[i+1])*x*pow(y+1,2)+2.0*(delta[i]+delta[i+1]+beta[i]+beta[i+1])*x*y+(2.0*beta[i]+3.0*delta[i]+delta[i+1])*y))*csqrt(-I)*Gausssum1d(gamma[i+2]+delta[i+2],0)*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1])*Kroneck(alpha[i+2]+beta[i+2]))
				  *(0.125*2.0*csqrt(-I)*cexp(M_PI*I/2.0*(2.0*beta[i+5]*yp+pow(xp+1,2)*(delta[i+3]+gamma[i+4]+2.0*beta[i+4])+xp*(delta[i+3]+delta[i+4])))*Gausssum1d(1,beta[i+3]+beta[i+4]+delta[i+3]+(xp+1)*gamma[i+4]+xp*delta[i+4])*Kroneck(gamma[i+3]+delta[i+3]-gamma[i+4]-delta[i+4]+1)*Kroneck(gamma[i+5]+delta[i+5])))
			*(2.0*(0.125*pow(2.0,(pow(ypp-1,2)*(pow(xpp,2)*(gamma[j]+delta[j+1])+pow(xpp-1,2)*(gamma[j+1]+delta[j])))*(1-yppp*pow(gamma[j+3]-gamma[j+4],2)-pow(yppp-1,2)*pow(gamma[j+3]-delta[j+4],2)))*(-I)*cexp(M_PI*I/2.0*(ypp*(delta[j]+delta[j+1])+pow(ypp+1,2)*(delta[j]+gamma[j+1]+2*beta[j+1])+pow(xpp,2)+2*(beta[j]+beta[j+1]+delta[j]+gamma[j+1]*(ypp+1)+delta[j+1]*ypp)*xpp))*Gausssum1d(0,xpp+beta[j]+beta[j+1]+delta[j]+gamma[j+1]*(ypp+1)+delta[j+1]*ypp+gamma[j+2]+delta[j+2])*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1]+1)*Kroneck(alpha[j+2]+beta[j+2]))
			  *(0.125*cexp(M_PI*I/2.0*((delta[j+4]-gamma[j+3])*pow(yppp+1,2)+2.0*(beta[j+3]+beta[j+4]+gamma[j+3]+delta[j+4])*xppp*pow(yppp+1,2)+2.0*(delta[j+3]+delta[j+4]+beta[j+3]+beta[j+4])*xppp*yppp+(2.0*beta[j+3]+3.0*delta[j+3]+delta[j+4])*yppp))*Gausssum1d(0.0,beta[j+5])*Kroneck(gamma[j+3]+delta[j+3]-gamma[j+4]-delta[j+4])*Kroneck(gamma[j+5]+delta[j+5]) 
			    + 0.125*cexp(M_PI*I/2.0*((delta[j+4]-gamma[j+3])*pow(yppp+1,2)+2.0*(beta[j+3]+beta[j+4]+gamma[j+3]+delta[j+4])*xppp*pow(yppp+1,2)+2.0*(delta[j+3]+delta[j+4]+beta[j+3]+beta[j+4])*xppp*yppp+(2.0*beta[j+3]+3.0*delta[j+3]+delta[j+4])*yppp))*csqrt(-I)*Gausssum1d(gamma[j+5]+delta[j+5],0)*Kroneck(gamma[j+3]+delta[j+3]-gamma[j+4]-delta[j+4])*Kroneck(alpha[j+5]+beta[j+5])));
		    }
		  }
		  for(yppp=0; yppp<=(1+alpha[j+5])%2; yppp++) {
		    for(xppp=0;xppp<=(1+beta[j+5])%2; xppp++) {
		      summand += ((0.125*pow(2.0,1-y*pow(gamma[i]-gamma[i+1],2)-pow(y-1,2)*pow(gamma[i]-delta[i+1],2))*cexp(M_PI*I/2.0*((delta[i+1]-gamma[i])*pow(y+1,2)+2.0*(beta[i]+beta[i+1]+gamma[i]+delta[i+1])*x*pow(y+1,2)+2.0*(delta[i]+delta[i+1]+beta[i]+beta[i+1])*x*y+(2.0*beta[i]+3.0*delta[i]+delta[i+1])*y))*Gausssum1d(0.0,beta[i+2])*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1])*Kroneck(gamma[i+2]+delta[i+2]) 
			  + 0.125*pow(2.0,1-y*pow(gamma[i]-gamma[i+1],2)-pow(y-1,2)*pow(gamma[i]-delta[i+1],2))*cexp(M_PI*I/2.0*((delta[i+1]-gamma[i])*pow(y+1,2)+2.0*(beta[i]+beta[i+1]+gamma[i]+delta[i+1])*x*pow(y+1,2)+2.0*(delta[i]+delta[i+1]+beta[i]+beta[i+1])*x*y+(2.0*beta[i]+3.0*delta[i]+delta[i+1])*y))*csqrt(-I)*Gausssum1d(gamma[i+2]+delta[i+2],0)*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1])*Kroneck(alpha[i+2]+beta[i+2]))
				  *(0.125*2.0*csqrt(-I)*cexp(M_PI*I/2.0*(2.0*beta[i+5]*yp+pow(xp+1,2)*(delta[i+3]+gamma[i+4]+2.0*beta[i+4])+xp*(delta[i+3]+delta[i+4])))*Gausssum1d(1,beta[i+3]+beta[i+4]+delta[i+3]+(xp+1)*gamma[i+4]+xp*delta[i+4])*Kroneck(gamma[i+3]+delta[i+3]-gamma[i+4]-delta[i+4]+1)*Kroneck(gamma[i+5]+delta[i+5])))
			*((0.125*pow(2.0,pow(ypp-1,2)*(pow(xpp,2)*(gamma[j]+delta[j+1])+pow(xpp-1,2)*(gamma[j+1]+delta[j])))*(-I)*cexp(M_PI*I/2.0*(ypp*(delta[j]+delta[j+1])+pow(ypp+1,2)*(delta[j]+gamma[j+1]+2*beta[j+1])+pow(xpp,2)+2*(beta[j]+beta[j+1]+delta[j]+gamma[j+1]*(ypp+1)+delta[j+1]*ypp)*xpp))*Gausssum1d(0,xpp+beta[j]+beta[j+1]+delta[j]+gamma[j+1]*(ypp+1)+delta[j+1]*ypp+gamma[j+2]+delta[j+2])*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1]+1)*Kroneck(alpha[j+2]+beta[j+2]))
			  *(0.125*2.0*csqrt(-I)*cexp(M_PI*I/2.0*(2.0*beta[j+5]*yppp+pow(xppp+1,2)*(delta[j+3]+gamma[j+4]+2.0*beta[j+4])+xppp*(delta[j+3]+delta[j+4])))*Gausssum1d(1,beta[j+3]+beta[j+4]+delta[j+3]+(xppp+1)*gamma[j+4]+xppp*delta[j+4])*Kroneck(gamma[j+3]+delta[j+3]-gamma[j+4]-delta[j+4]+1)*Kroneck(gamma[j+5]+delta[j+5])));
		    }
		  }
		  for(yppp=ypp; yppp<=1; yppp++) {
		    for(xppp=(yppp*(delta[j+3]+delta[j+4])+ypp)%2;xppp<=(1+yppp*(gamma[j+3]+gamma[j+4])+ypp)%2; xppp++) {
		      summand += ((0.125*pow(2.0,1-y*pow(gamma[i]-gamma[i+1],2)-pow(y-1,2)*pow(gamma[i]-delta[i+1],2))*cexp(M_PI*I/2.0*((delta[i+1]-gamma[i])*pow(y+1,2)+2.0*(beta[i]+beta[i+1]+gamma[i]+delta[i+1])*x*pow(y+1,2)+2.0*(delta[i]+delta[i+1]+beta[i]+beta[i+1])*x*y+(2.0*beta[i]+3.0*delta[i]+delta[i+1])*y))*Gausssum1d(0.0,beta[i+2])*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1])*Kroneck(gamma[i+2]+delta[i+2]) 
			  + 0.125*pow(2.0,1-y*pow(gamma[i]-gamma[i+1],2)-pow(y-1,2)*pow(gamma[i]-delta[i+1],2))*cexp(M_PI*I/2.0*((delta[i+1]-gamma[i])*pow(y+1,2)+2.0*(beta[i]+beta[i+1]+gamma[i]+delta[i+1])*x*pow(y+1,2)+2.0*(delta[i]+delta[i+1]+beta[i]+beta[i+1])*x*y+(2.0*beta[i]+3.0*delta[i]+delta[i+1])*y))*csqrt(-I)*Gausssum1d(gamma[i+2]+delta[i+2],0)*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1])*Kroneck(alpha[i+2]+beta[i+2]))
				  *(0.125*2.0*csqrt(-I)*cexp(M_PI*I/2.0*(2.0*beta[i+5]*yp+pow(xp+1,2)*(delta[i+3]+gamma[i+4]+2.0*beta[i+4])+xp*(delta[i+3]+delta[i+4])))*Gausssum1d(1,beta[i+3]+beta[i+4]+delta[i+3]+(xp+1)*gamma[i+4]+xp*delta[i+4])*Kroneck(gamma[i+3]+delta[i+3]-gamma[i+4]-delta[i+4]+1)*Kroneck(gamma[i+5]+delta[i+5])))
			*(2.0*(0.125*pow(2.0,(pow(ypp-1,2)*(pow(xpp,2)*(gamma[j]+delta[j+1])+pow(xpp-1,2)*(gamma[j+1]+delta[j])))*(pow(yppp-1,2)*(pow(xppp,2)*(gamma[j+3]+delta[j+4])+pow(xppp-1,2)*(gamma[j+4]+delta[j+3]))))*(-I)*cexp(M_PI*I/2.0*(ypp*(delta[j]+delta[j+1])+pow(ypp+1,2)*(delta[j]+gamma[j+1]+2*beta[j+1])+pow(xpp,2)+2*(beta[j]+beta[j+1]+delta[j]+gamma[j+1]*(ypp+1)+delta[j+1]*ypp)*xpp))*Gausssum1d(0,xpp+beta[j]+beta[j+1]+delta[j]+gamma[j+1]*(ypp+1)+delta[j+1]*ypp+gamma[j+2]+delta[j+2])*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1]+1)*Kroneck(alpha[j+2]+beta[j+2]))
			  *(0.125*(-I)*cexp(M_PI*I/2.0*(yppp*(delta[j+3]+delta[j+4])+pow(yppp+1,2)*(delta[j+3]+gamma[j+4]+2*beta[j+4])+pow(xppp,2)+2*(beta[j+3]+beta[j+4]+delta[j+3]+gamma[j+4]*(yppp+1)+delta[j+4]*yppp)*xppp))*Gausssum1d(0,xppp+beta[j+3]+beta[j+4]+delta[j+3]+gamma[j+4]*(yppp+1)+delta[j+4]*yppp+gamma[j+5]+delta[j+5])*Kroneck(gamma[j+3]+delta[j+3]-gamma[j+4]-delta[j+4]+1)*Kroneck(alpha[j+5]+beta[j+5])));
		    }
		  }
		}
	      }
	    }
	  }
	}
      }

      
      // third term
      for(y=0; y<=1; y++) {
      	//**for(x=0;x<=(y*(gamma[i]+gamma[i+1])+(y+1)*(gamma[i]+delta[i+1]))%2; x++) {
	for(x=y*(beta[i]+alpha[i+1]+beta[i+1])%2;x<=(y*(beta[i]+alpha[i+1]+beta[i+1])+y*(gamma[i]+gamma[i+1])+(y+1)*(gamma[i]+delta[i+1]))%2; x++) {
	  //**for(yp=x; yp<=1; yp++) {
	  for(yp=x*(1+alpha[i]+beta[i])%2; yp<=1; yp++) {
	    //**for(xp=(yp*(delta[i+3]+delta[i+4])+x)%2;xp<=(1+yp*(gamma[i+3]+gamma[i+4])+x)%2; xp++) {
	    for(xp=(yp*(delta[i+3]+delta[i+4])+x*(1+alpha[i]+beta[i]))%2;xp<=(1+yp*(gamma[i+3]+gamma[i+4])+x*(1+alpha[i]+beta[i]))%2; xp++) {
	      //for(ypp=0; ypp<=1; ypp++) {
	      for(ypp=((gamma[j]+delta[j+1])*(x+yp))%2;ypp<=(1+(gamma[j]+gamma[j+1])*(x+yp))%2;ypp++) {
	      //****for(ypp=((gamma[j]+delta[j+1])*(x*(1+alpha[i]+beta[i])+yp))%2;ypp<=(1+(gamma[j]+gamma[j+1])*(x*(1+alpha[i]+beta[i])+yp))%2;ypp++) {
		//**for(xpp=0;xpp<=(ypp*(gamma[j]+gamma[j+1])+(ypp+1)*(gamma[j]+delta[j+1]))%2; xpp++) {
		for(xpp=ypp*(beta[j]+alpha[j+1]+beta[j+1])%2;xpp<=(ypp*(beta[j]+alpha[j+1]+beta[j+1])+ypp*(gamma[j]+gamma[j+1])+(ypp+1)*(gamma[j]+delta[j+1]))%2; xpp++) {
		  //for(yppp=((gamma[j+3]+delta[j+4])*xpp)%2; yppp<=(1+(gamma[j+3]+gamma[j+4])*xpp)%2; yppp++) {
		  for(yppp=((gamma[j+3]+delta[j+4])*(x+yp+xpp))%2; yppp<=(1+(gamma[j+3]+gamma[j+4])*(x+yp+xpp))%2; yppp++) {
		  //****for(yppp=((gamma[j+3]+delta[j+4])*(x*(1+alpha[i]+beta[i])+yp+xpp*(1+alpha[j]+beta[j])))%2; yppp<=(1+(gamma[j+3]+gamma[j+4])*(x*(1+alpha[i]+beta[i])+yp+xpp*(1+alpha[j]+beta[j])))%2; yppp++) {
		    //**for(xppp=0;xppp<=(yppp*(gamma[j+3]+gamma[j+4])+(yppp+1)*(gamma[j+3]+delta[j+4]))%2; xppp++) {
		    for(xppp=yppp*(beta[j+3]+alpha[j+4]+beta[j+4])%2;xppp<=(yppp*(beta[j+3]+alpha[j+4]+beta[j+4])+yppp*(gamma[j+3]+gamma[j+4])+(yppp+1)*(gamma[j+3]+delta[j+4]))%2; xppp++) {
		      //summand += (2.0*(0.125*pow(2.0,(1-y*pow(gamma[i]-gamma[i+1],2)-pow(y-1,2)*pow(gamma[i]-delta[i+1],2))*(pow(yp-1,2)*(pow(xp,2)*(gamma[i+3]+delta[i+4])+pow(xp-1,2)*(gamma[i+4]+delta[i+3]))))*cexp(M_PI*I/2.0*((delta[i+1]-gamma[i])*pow(y+1,2)+2.0*(beta[i]+beta[i+1]+gamma[i]+delta[i+1])*x*pow(y+1,2)+2.0*(delta[i]+delta[i+1]+beta[i]+beta[i+1])*x*y+(2.0*beta[i]+3.0*delta[i]+delta[i+1])*y))*Gausssum1d(0.0,beta[i+2])*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1])*Kroneck(gamma[i+2]+delta[i+2]) 
		      summand += 2.0*(2.0*(0.125*pow(2.0,(1-y*pow(gamma[i]-gamma[i+1],2)-pow(y-1,2)*pow(gamma[i]-delta[i+1],2))*(pow(yp-1,2)*(pow(xp,2)*(gamma[i+3]+delta[i+4])+pow(xp-1,2)*(gamma[i+4]+delta[i+3])))*(1-ypp*pow(gamma[j]-gamma[j+1],2)-pow(ypp-1,2)*pow(gamma[j]-delta[j+1],2))*(1-yppp*pow(gamma[j+3]-gamma[j+4],2)-pow(yppp-1,2)*pow(gamma[j+3]-delta[j+4],2)))*cexp(M_PI*I/2.0*((delta[i+1]-gamma[i])*pow(y+1,2)+2.0*(beta[i]+beta[i+1]+gamma[i]+delta[i+1])*x*pow(y+1,2)+2.0*(delta[i]+delta[i+1]+beta[i]+beta[i+1])*x*y+(2.0*beta[i]+3.0*delta[i]+delta[i+1])*y))*Gausssum1d(0.0,beta[i+2])*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1])*Kroneck(gamma[i+2]+delta[i+2]) 
				       //+ 0.125*pow(2.0,(1-y*pow(gamma[i]-gamma[i+1],2)-pow(y-1,2)*pow(gamma[i]-delta[i+1],2))*(pow(yp-1,2)*(pow(xp,2)*(gamma[i+3]+delta[i+4])+pow(xp-1,2)*(gamma[i+4]+delta[i+3]))))*cexp(M_PI*I/2.0*((delta[i+1]-gamma[i])*pow(y+1,2)+2.0*(beta[i]+beta[i+1]+gamma[i]+delta[i+1])*x*pow(y+1,2)+2.0*(delta[i]+delta[i+1]+beta[i]+beta[i+1])*x*y+(2.0*beta[i]+3.0*delta[i]+delta[i+1])*y))*csqrt(-I)*Gausssum1d(gamma[i+2]+delta[i+2],0)*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1])*Kroneck(alpha[i+2]+beta[i+2]))
				       + 0.125*pow(2.0,(1-y*pow(gamma[i]-gamma[i+1],2)-pow(y-1,2)*pow(gamma[i]-delta[i+1],2))*(pow(yp-1,2)*(pow(xp,2)*(gamma[i+3]+delta[i+4])+pow(xp-1,2)*(gamma[i+4]+delta[i+3])))*(1-ypp*pow(gamma[j]-gamma[j+1],2)-pow(ypp-1,2)*pow(gamma[j]-delta[j+1],2))*(1-yppp*pow(gamma[j+3]-gamma[j+4],2)-pow(yppp-1,2)*pow(gamma[j+3]-delta[j+4],2)))*cexp(M_PI*I/2.0*((delta[i+1]-gamma[i])*pow(y+1,2)+2.0*(beta[i]+beta[i+1]+gamma[i]+delta[i+1])*x*pow(y+1,2)+2.0*(delta[i]+delta[i+1]+beta[i]+beta[i+1])*x*y+(2.0*beta[i]+3.0*delta[i]+delta[i+1])*y))*csqrt(-I)*Gausssum1d(gamma[i+2]+delta[i+2],0)*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1])*Kroneck(alpha[i+2]+beta[i+2]))
				  *(0.125*(-I)*cexp(M_PI*I/2.0*(yp*(delta[i+3]+delta[i+4])+pow(yp+1,2)*(delta[i+3]+gamma[i+4]+2*beta[i+4])+pow(xp,2)+2*(beta[i+3]+beta[i+4]+delta[i+3]+gamma[i+4]*(yp+1)+delta[i+4]*yp)*xp))*Gausssum1d(0,xp+beta[i+3]+beta[i+4]+delta[i+3]+gamma[i+4]*(yp+1)+delta[i+4]*yp+gamma[i+5]+delta[i+5])*Kroneck(gamma[i+3]+delta[i+3]-gamma[i+4]-delta[i+4]+1)*Kroneck(alpha[i+5]+beta[i+5])))
			//*(2.0*(0.125*pow(2.0,(1-ypp*pow(gamma[j]-gamma[j+1],2)-pow(ypp-1,2)*pow(gamma[j]-delta[j+1],2))*(1-yppp*pow(gamma[j+3]-gamma[j+4],2)-pow(yppp-1,2)*pow(gamma[j+3]-delta[j+4],2)))*cexp(M_PI*I/2.0*((delta[j+1]-gamma[j])*pow(ypp+1,2)+2.0*(beta[j]+beta[j+1]+gamma[j]+delta[j+1])*xpp*pow(ypp+1,2)+2.0*(delta[j]+delta[j+1]+beta[j]+beta[j+1])*xpp*ypp+(2.0*beta[j]+3.0*delta[j]+delta[j+1])*ypp))*Gausssum1d(0.0,beta[j+2])*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1])*Kroneck(gamma[j+2]+delta[j+2]) 
			*(2.0*(0.125*cexp(M_PI*I/2.0*((delta[j+1]-gamma[j])*pow(ypp+1,2)+2.0*(beta[j]+beta[j+1]+gamma[j]+delta[j+1])*xpp*pow(ypp+1,2)+2.0*(delta[j]+delta[j+1]+beta[j]+beta[j+1])*xpp*ypp+(2.0*beta[j]+3.0*delta[j]+delta[j+1])*ypp))*Gausssum1d(0.0,beta[j+2])*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1])*Kroneck(gamma[j+2]+delta[j+2]) 
			       //+ 0.125*pow(2.0,(1-ypp*pow(gamma[j]-gamma[j+1],2)-pow(ypp-1,2)*pow(gamma[j]-delta[j+1],2))*(1-yppp*pow(gamma[j+3]-gamma[j+4],2)-pow(yppp-1,2)*pow(gamma[j+3]-delta[j+4],2)))*cexp(M_PI*I/2.0*((delta[j+1]-gamma[j])*pow(ypp+1,2)+2.0*(beta[j]+beta[j+1]+gamma[j]+delta[j+1])*xpp*pow(ypp+1,2)+2.0*(delta[j]+delta[j+1]+beta[j]+beta[j+1])*xpp*ypp+(2.0*beta[j]+3.0*delta[j]+delta[j+1])*ypp))*csqrt(-I)*Gausssum1d(gamma[j+2]+delta[j+2],0)*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1])*Kroneck(alpha[j+2]+beta[j+2]))
			      + 0.125*cexp(M_PI*I/2.0*((delta[j+1]-gamma[j])*pow(ypp+1,2)+2.0*(beta[j]+beta[j+1]+gamma[j]+delta[j+1])*xpp*pow(ypp+1,2)+2.0*(delta[j]+delta[j+1]+beta[j]+beta[j+1])*xpp*ypp+(2.0*beta[j]+3.0*delta[j]+delta[j+1])*ypp))*csqrt(-I)*Gausssum1d(gamma[j+2]+delta[j+2],0)*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1])*Kroneck(alpha[j+2]+beta[j+2]))
			*(0.125*cexp(M_PI*I/2.0*((delta[j+4]-gamma[j+3])*pow(yppp+1,2)+2.0*(beta[j+3]+beta[j+4]+gamma[j+3]+delta[j+4])*xppp*pow(yppp+1,2)+2.0*(delta[j+3]+delta[j+4]+beta[j+3]+beta[j+4])*xppp*yppp+(2.0*beta[j+3]+3.0*delta[j+3]+delta[j+4])*yppp))*Gausssum1d(0.0,beta[j+5])*Kroneck(gamma[j+3]+delta[j+3]-gamma[j+4]-delta[j+4])*Kroneck(gamma[j+5]+delta[j+5]) 
			  + 0.125*cexp(M_PI*I/2.0*((delta[j+4]-gamma[j+3])*pow(yppp+1,2)+2.0*(beta[j+3]+beta[j+4]+gamma[j+3]+delta[j+4])*xppp*pow(yppp+1,2)+2.0*(delta[j+3]+delta[j+4]+beta[j+3]+beta[j+4])*xppp*yppp+(2.0*beta[j+3]+3.0*delta[j+3]+delta[j+4])*yppp))*csqrt(-I)*Gausssum1d(gamma[j+5]+delta[j+5],0)*Kroneck(gamma[j+3]+delta[j+3]-gamma[j+4]-delta[j+4])*Kroneck(alpha[j+5]+beta[j+5])));
		    }
		  }
		}
	      }
	      //for(ypp=0; ypp<=1; ypp++) {
	      for(ypp=((gamma[j]+delta[j+1])*(x+yp))%2;ypp<=(1+(gamma[j]+gamma[j+1])*(x+yp))%2;ypp++) {
		//**for(xpp=0;xpp<=(ypp*(gamma[j]+gamma[j+1])+(ypp+1)*(gamma[j]+delta[j+1]))%2; xpp++) {
		for(xpp=ypp*(beta[j]+alpha[j+1]+beta[j+1])%2;xpp<=(ypp*(beta[j]+alpha[j+1]+beta[j+1])+ypp*(gamma[j]+gamma[j+1])+(ypp+1)*(gamma[j]+delta[j+1]))%2; xpp++) {
		  for(yppp=0; yppp<=(1+alpha[j+5])%2; yppp++) {
		    for(xppp=0;xppp<=(1+beta[j+5])%2; xppp++) {
		      summand += (2.0*(0.125*pow(2.0,(1-y*pow(gamma[i]-gamma[i+1],2)-pow(y-1,2)*pow(gamma[i]-delta[i+1],2))*(pow(yp-1,2)*(pow(xp,2)*(gamma[i+3]+delta[i+4])+pow(xp-1,2)*(gamma[i+4]+delta[i+3]))))*cexp(M_PI*I/2.0*((delta[i+1]-gamma[i])*pow(y+1,2)+2.0*(beta[i]+beta[i+1]+gamma[i]+delta[i+1])*x*pow(y+1,2)+2.0*(delta[i]+delta[i+1]+beta[i]+beta[i+1])*x*y+(2.0*beta[i]+3.0*delta[i]+delta[i+1])*y))*Gausssum1d(0.0,beta[i+2])*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1])*Kroneck(gamma[i+2]+delta[i+2]) 
				       + 0.125*pow(2.0,(1-y*pow(gamma[i]-gamma[i+1],2)-pow(y-1,2)*pow(gamma[i]-delta[i+1],2))*(pow(yp-1,2)*(pow(xp,2)*(gamma[i+3]+delta[i+4])+pow(xp-1,2)*(gamma[i+4]+delta[i+3]))))*cexp(M_PI*I/2.0*((delta[i+1]-gamma[i])*pow(y+1,2)+2.0*(beta[i]+beta[i+1]+gamma[i]+delta[i+1])*x*pow(y+1,2)+2.0*(delta[i]+delta[i+1]+beta[i]+beta[i+1])*x*y+(2.0*beta[i]+3.0*delta[i]+delta[i+1])*y))*csqrt(-I)*Gausssum1d(gamma[i+2]+delta[i+2],0)*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1])*Kroneck(alpha[i+2]+beta[i+2]))
				  *(0.125*(-I)*cexp(M_PI*I/2.0*(yp*(delta[i+3]+delta[i+4])+pow(yp+1,2)*(delta[i+3]+gamma[i+4]+2*beta[i+4])+pow(xp,2)+2*(beta[i+3]+beta[i+4]+delta[i+3]+gamma[i+4]*(yp+1)+delta[i+4]*yp)*xp))*Gausssum1d(0,xp+beta[i+3]+beta[i+4]+delta[i+3]+gamma[i+4]*(yp+1)+delta[i+4]*yp+gamma[i+5]+delta[i+5])*Kroneck(gamma[i+3]+delta[i+3]-gamma[i+4]-delta[i+4]+1)*Kroneck(alpha[i+5]+beta[i+5])))
			*((0.125*pow(2.0,1-ypp*pow(gamma[j]-gamma[j+1],2)-pow(ypp-1,2)*pow(gamma[j]-delta[j+1],2))*cexp(M_PI*I/2.0*((delta[j+1]-gamma[j])*pow(ypp+1,2)+2.0*(beta[j]+beta[j+1]+gamma[j]+delta[j+1])*xpp*pow(ypp+1,2)+2.0*(delta[j]+delta[j+1]+beta[j]+beta[j+1])*xpp*ypp+(2.0*beta[j]+3.0*delta[j]+delta[j+1])*ypp))*Gausssum1d(0.0,beta[j+2])*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1])*Kroneck(gamma[j+2]+delta[j+2]) 
				  + 0.125*pow(2.0,1-ypp*pow(gamma[j]-gamma[j+1],2)-pow(ypp-1,2)*pow(gamma[j]-delta[j+1],2))*cexp(M_PI*I/2.0*((delta[j+1]-gamma[j])*pow(ypp+1,2)+2.0*(beta[j]+beta[j+1]+gamma[j]+delta[j+1])*xpp*pow(ypp+1,2)+2.0*(delta[j]+delta[j+1]+beta[j]+beta[j+1])*xpp*ypp+(2.0*beta[j]+3.0*delta[j]+delta[j+1])*ypp))*csqrt(-I)*Gausssum1d(gamma[j+2]+delta[j+2],0)*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1])*Kroneck(alpha[j+2]+beta[j+2]))
			  *(0.125*2.0*csqrt(-I)*cexp(M_PI*I/2.0*(2.0*beta[j+5]*yppp+pow(xppp+1,2)*(delta[j+3]+gamma[j+4]+2.0*beta[j+4])+xppp*(delta[j+3]+delta[j+4])))*Gausssum1d(1,beta[j+3]+beta[j+4]+delta[j+3]+(xppp+1)*gamma[j+4]+xppp*delta[j+4])*Kroneck(gamma[j+3]+delta[j+3]-gamma[j+4]-delta[j+4]+1)*Kroneck(gamma[j+5]+delta[j+5])));
		    }
		  }
		}
	      }
	      //for(ypp=0; ypp<=1; ypp++) {
	      for(ypp=((gamma[j]+delta[j+1])*(x+yp))%2;ypp<=(1+(gamma[j]+gamma[j+1])*(x+yp))%2;ypp++) {
	      //****for(ypp=((gamma[j]+delta[j+1])*(x*(1+alpha[i]+beta[i])+yp))%2;ypp<=(1+(gamma[j]+gamma[j+1])*(x*(1+alpha[i]+beta[i])+yp))%2;ypp++) {
		//**for(xpp=0;xpp<=(ypp*(gamma[j]+gamma[j+1])+(ypp+1)*(gamma[j]+delta[j+1]))%2; xpp++) {
		for(xpp=ypp*(beta[j]+alpha[j+1]+beta[j+1])%2;xpp<=(ypp*(beta[j]+alpha[j+1]+beta[j+1])+ypp*(gamma[j]+gamma[j+1])+(ypp+1)*(gamma[j]+delta[j+1]))%2; xpp++) {
		  //for(yppp=xpp; yppp<=1; yppp++) {
		  //**for(yppp=(x+yp+xpp)%2; yppp<=1; yppp++) {
		  for(yppp=(x*(1+alpha[i]+beta[i])+yp+xpp*(1+alpha[j]+beta[j]))%2; yppp<=1; yppp++) {
		    //for(xppp=(yppp*(delta[j+3]+delta[j+4])+xpp)%2;xppp<=(1+yppp*(gamma[j+3]+gamma[j+4])+xpp)%2; xppp++) {
		    //**for(xppp=(yppp*(delta[j+3]+delta[j+4])+(x+yp+xpp))%2;xppp<=(1+yppp*(gamma[j+3]+gamma[j+4])+(x+yp+xpp))%2; xppp++) {
		    for(xppp=(yppp*(delta[j+3]+delta[j+4])+(x*(1+alpha[i]+beta[i])+yp+xpp*(1+alpha[j]+beta[j])))%2;xppp<=(1+yppp*(gamma[j+3]+gamma[j+4])+(x*(1+alpha[i]+beta[i])+yp+xpp*(1+alpha[j]+beta[j])))%2; xppp++) {
		      //summand += (2.0*(0.125*pow(2.0,(1-y*pow(gamma[i]-gamma[i+1],2)-pow(y-1,2)*pow(gamma[i]-delta[i+1],2))*(pow(yp-1,2)*(pow(xp,2)*(gamma[i+3]+delta[i+4])+pow(xp-1,2)*(gamma[i+4]+delta[i+3]))))*cexp(M_PI*I/2.0*((delta[i+1]-gamma[i])*pow(y+1,2)+2.0*(beta[i]+beta[i+1]+gamma[i]+delta[i+1])*x*pow(y+1,2)+2.0*(delta[i]+delta[i+1]+beta[i]+beta[i+1])*x*y+(2.0*beta[i]+3.0*delta[i]+delta[i+1])*y))*Gausssum1d(0.0,beta[i+2])*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1])*Kroneck(gamma[i+2]+delta[i+2]) 
		      summand += 2.0*(2.0*(0.125*pow(2.0,(1-y*pow(gamma[i]-gamma[i+1],2)-pow(y-1,2)*pow(gamma[i]-delta[i+1],2))*(pow(yp-1,2)*(pow(xp,2)*(gamma[i+3]+delta[i+4])+pow(xp-1,2)*(gamma[i+4]+delta[i+3])))*(1-ypp*pow(gamma[j]-gamma[j+1],2)-pow(ypp-1,2)*pow(gamma[j]-delta[j+1],2))*(pow(yppp-1,2)*(pow(xppp,2)*(gamma[j+3]+delta[j+4])+pow(xppp-1,2)*(gamma[j+4]+delta[j+3]))))*cexp(M_PI*I/2.0*((delta[i+1]-gamma[i])*pow(y+1,2)+2.0*(beta[i]+beta[i+1]+gamma[i]+delta[i+1])*x*pow(y+1,2)+2.0*(delta[i]+delta[i+1]+beta[i]+beta[i+1])*x*y+(2.0*beta[i]+3.0*delta[i]+delta[i+1])*y))*Gausssum1d(0.0,beta[i+2])*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1])*Kroneck(gamma[i+2]+delta[i+2]) 
				       //+ 0.125*pow(2.0,(1-y*pow(gamma[i]-gamma[i+1],2)-pow(y-1,2)*pow(gamma[i]-delta[i+1],2))*(pow(yp-1,2)*(pow(xp,2)*(gamma[i+3]+delta[i+4])+pow(xp-1,2)*(gamma[i+4]+delta[i+3]))))*cexp(M_PI*I/2.0*((delta[i+1]-gamma[i])*pow(y+1,2)+2.0*(beta[i]+beta[i+1]+gamma[i]+delta[i+1])*x*pow(y+1,2)+2.0*(delta[i]+delta[i+1]+beta[i]+beta[i+1])*x*y+(2.0*beta[i]+3.0*delta[i]+delta[i+1])*y))*csqrt(-I)*Gausssum1d(gamma[i+2]+delta[i+2],0)*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1])*Kroneck(alpha[i+2]+beta[i+2]))
					   + 0.125*pow(2.0,(1-y*pow(gamma[i]-gamma[i+1],2)-pow(y-1,2)*pow(gamma[i]-delta[i+1],2))*(pow(yp-1,2)*(pow(xp,2)*(gamma[i+3]+delta[i+4])+pow(xp-1,2)*(gamma[i+4]+delta[i+3])))*(1-ypp*pow(gamma[j]-gamma[j+1],2)-pow(ypp-1,2)*pow(gamma[j]-delta[j+1],2))*(pow(yppp-1,2)*(pow(xppp,2)*(gamma[j+3]+delta[j+4])+pow(xppp-1,2)*(gamma[j+4]+delta[j+3]))))*cexp(M_PI*I/2.0*((delta[i+1]-gamma[i])*pow(y+1,2)+2.0*(beta[i]+beta[i+1]+gamma[i]+delta[i+1])*x*pow(y+1,2)+2.0*(delta[i]+delta[i+1]+beta[i]+beta[i+1])*x*y+(2.0*beta[i]+3.0*delta[i]+delta[i+1])*y))*csqrt(-I)*Gausssum1d(gamma[i+2]+delta[i+2],0)*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1])*Kroneck(alpha[i+2]+beta[i+2]))
				  *(0.125*(-I)*cexp(M_PI*I/2.0*(yp*(delta[i+3]+delta[i+4])+pow(yp+1,2)*(delta[i+3]+gamma[i+4]+2*beta[i+4])+pow(xp,2)+2*(beta[i+3]+beta[i+4]+delta[i+3]+gamma[i+4]*(yp+1)+delta[i+4]*yp)*xp))*Gausssum1d(0,xp+beta[i+3]+beta[i+4]+delta[i+3]+gamma[i+4]*(yp+1)+delta[i+4]*yp+gamma[i+5]+delta[i+5])*Kroneck(gamma[i+3]+delta[i+3]-gamma[i+4]-delta[i+4]+1)*Kroneck(alpha[i+5]+beta[i+5])))
			//*(2.0*(0.125*pow(2.0,(1-ypp*pow(gamma[j]-gamma[j+1],2)-pow(ypp-1,2)*pow(gamma[j]-delta[j+1],2))*(pow(yppp-1,2)*(pow(xppp,2)*(gamma[j+3]+delta[j+4])+pow(xppp-1,2)*(gamma[j+4]+delta[j+3]))))*cexp(M_PI*I/2.0*((delta[j+1]-gamma[j])*pow(ypp+1,2)+2.0*(beta[j]+beta[j+1]+gamma[j]+delta[j+1])*xpp*pow(ypp+1,2)+2.0*(delta[j]+delta[j+1]+beta[j]+beta[j+1])*xpp*ypp+(2.0*beta[j]+3.0*delta[j]+delta[j+1])*ypp))*Gausssum1d(0.0,beta[j+2])*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1])*Kroneck(gamma[j+2]+delta[j+2]) 
			*(2.0*(0.125*cexp(M_PI*I/2.0*((delta[j+1]-gamma[j])*pow(ypp+1,2)+2.0*(beta[j]+beta[j+1]+gamma[j]+delta[j+1])*xpp*pow(ypp+1,2)+2.0*(delta[j]+delta[j+1]+beta[j]+beta[j+1])*xpp*ypp+(2.0*beta[j]+3.0*delta[j]+delta[j+1])*ypp))*Gausssum1d(0.0,beta[j+2])*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1])*Kroneck(gamma[j+2]+delta[j+2]) 
			       //+ 0.125*pow(2.0,(1-ypp*pow(gamma[j]-gamma[j+1],2)-pow(ypp-1,2)*pow(gamma[j]-delta[j+1],2))*(pow(yppp-1,2)*(pow(xppp,2)*(gamma[j+3]+delta[j+4])+pow(xppp-1,2)*(gamma[j+4]+delta[j+3]))))*cexp(M_PI*I/2.0*((delta[j+1]-gamma[j])*pow(ypp+1,2)+2.0*(beta[j]+beta[j+1]+gamma[j]+delta[j+1])*xpp*pow(ypp+1,2)+2.0*(delta[j]+delta[j+1]+beta[j]+beta[j+1])*xpp*ypp+(2.0*beta[j]+3.0*delta[j]+delta[j+1])*ypp))*csqrt(-I)*Gausssum1d(gamma[j+2]+delta[j+2],0)*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1])*Kroneck(alpha[j+2]+beta[j+2]))
			       + 0.125*cexp(M_PI*I/2.0*((delta[j+1]-gamma[j])*pow(ypp+1,2)+2.0*(beta[j]+beta[j+1]+gamma[j]+delta[j+1])*xpp*pow(ypp+1,2)+2.0*(delta[j]+delta[j+1]+beta[j]+beta[j+1])*xpp*ypp+(2.0*beta[j]+3.0*delta[j]+delta[j+1])*ypp))*csqrt(-I)*Gausssum1d(gamma[j+2]+delta[j+2],0)*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1])*Kroneck(alpha[j+2]+beta[j+2]))
			  *(0.125*(-I)*cexp(M_PI*I/2.0*(yppp*(delta[j+3]+delta[j+4])+pow(yppp+1,2)*(delta[j+3]+gamma[j+4]+2*beta[j+4])+pow(xppp,2)+2*(beta[j+3]+beta[j+4]+delta[j+3]+gamma[j+4]*(yppp+1)+delta[j+4]*yppp)*xppp))*Gausssum1d(0,xppp+beta[j+3]+beta[j+4]+delta[j+3]+gamma[j+4]*(yppp+1)+delta[j+4]*yppp+gamma[j+5]+delta[j+5])*Kroneck(gamma[j+3]+delta[j+3]-gamma[j+4]-delta[j+4]+1)*Kroneck(alpha[j+5]+beta[j+5])));
		    }
		  }
		}
	      }
	      
	      for(ypp=0; ypp<=(1+alpha[j+2])%2; ypp++) {
		for(xpp=0; xpp<=(1+beta[j+2])%2; xpp++) {
		  for(yppp=0; yppp<=1; yppp++) {
		    //**for(xppp=0;xppp<=(yppp*(gamma[j+3]+gamma[j+4])+(yppp+1)*(gamma[j+3]+delta[j+4]))%2; xppp++) {
		    for(xppp=yppp*(beta[j+3]+alpha[j+4]+beta[j+4])%2;xppp<=(yppp*(beta[j+3]+alpha[j+4]+beta[j+4])+yppp*(gamma[j+3]+gamma[j+4])+(yppp+1)*(gamma[j+3]+delta[j+4]))%2; xppp++) {
		      summand += (2.0*(0.125*pow(2.0,(1-y*pow(gamma[i]-gamma[i+1],2)-pow(y-1,2)*pow(gamma[i]-delta[i+1],2))*(pow(yp-1,2)*(pow(xp,2)*(gamma[i+3]+delta[i+4])+pow(xp-1,2)*(gamma[i+4]+delta[i+3]))))*cexp(M_PI*I/2.0*((delta[i+1]-gamma[i])*pow(y+1,2)+2.0*(beta[i]+beta[i+1]+gamma[i]+delta[i+1])*x*pow(y+1,2)+2.0*(delta[i]+delta[i+1]+beta[i]+beta[i+1])*x*y+(2.0*beta[i]+3.0*delta[i]+delta[i+1])*y))*Gausssum1d(0.0,beta[i+2])*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1])*Kroneck(gamma[i+2]+delta[i+2]) 
				       + 0.125*pow(2.0,(1-y*pow(gamma[i]-gamma[i+1],2)-pow(y-1,2)*pow(gamma[i]-delta[i+1],2))*(pow(yp-1,2)*(pow(xp,2)*(gamma[i+3]+delta[i+4])+pow(xp-1,2)*(gamma[i+4]+delta[i+3]))))*cexp(M_PI*I/2.0*((delta[i+1]-gamma[i])*pow(y+1,2)+2.0*(beta[i]+beta[i+1]+gamma[i]+delta[i+1])*x*pow(y+1,2)+2.0*(delta[i]+delta[i+1]+beta[i]+beta[i+1])*x*y+(2.0*beta[i]+3.0*delta[i]+delta[i+1])*y))*csqrt(-I)*Gausssum1d(gamma[i+2]+delta[i+2],0)*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1])*Kroneck(alpha[i+2]+beta[i+2]))
				  *(0.125*(-I)*cexp(M_PI*I/2.0*(yp*(delta[i+3]+delta[i+4])+pow(yp+1,2)*(delta[i+3]+gamma[i+4]+2*beta[i+4])+pow(xp,2)+2*(beta[i+3]+beta[i+4]+delta[i+3]+gamma[i+4]*(yp+1)+delta[i+4]*yp)*xp))*Gausssum1d(0,xp+beta[i+3]+beta[i+4]+delta[i+3]+gamma[i+4]*(yp+1)+delta[i+4]*yp+gamma[i+5]+delta[i+5])*Kroneck(gamma[i+3]+delta[i+3]-gamma[i+4]-delta[i+4]+1)*Kroneck(alpha[i+5]+beta[i+5])))
			*((0.125*2.0*csqrt(-I)*cexp(M_PI*I/2.0*(2.0*beta[j+2]*ypp+pow(xpp+1,2)*(delta[j]+gamma[j+1]+2.0*beta[j+1])+xpp*(delta[j]+delta[j+1])))*Gausssum1d(1,beta[j]+beta[j+1]+delta[j]+(xpp+1)*gamma[j+1]+xpp*delta[j+1])*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1]+1)*Kroneck(gamma[j+2]+delta[j+2]))
			  *(0.125*pow(2.0,1-yppp*pow(gamma[j+3]-gamma[j+4],2)-pow(yppp-1,2)*pow(gamma[j+3]-delta[j+4],2))*cexp(M_PI*I/2.0*((delta[j+4]-gamma[j+3])*pow(yppp+1,2)+2.0*(beta[j+3]+beta[j+4]+gamma[j+3]+delta[j+4])*xppp*pow(yppp+1,2)+2.0*(delta[j+3]+delta[j+4]+beta[j+3]+beta[j+4])*xppp*yppp+(2.0*beta[j+3]+3.0*delta[j+3]+delta[j+4])*yppp))*Gausssum1d(0.0,beta[j+5])*Kroneck(gamma[j+3]+delta[j+3]-gamma[j+4]-delta[j+4])*Kroneck(gamma[j+5]+delta[j+5]) 
			    + 0.125*pow(2.0,1-yppp*pow(gamma[j+3]-gamma[j+4],2)-pow(yppp-1,2)*pow(gamma[j+3]-delta[j+4],2))*cexp(M_PI*I/2.0*((delta[j+4]-gamma[j+3])*pow(yppp+1,2)+2.0*(beta[j+3]+beta[j+4]+gamma[j+3]+delta[j+4])*xppp*pow(yppp+1,2)+2.0*(delta[j+3]+delta[j+4]+beta[j+3]+beta[j+4])*xppp*yppp+(2.0*beta[j+3]+3.0*delta[j+3]+delta[j+4])*yppp))*csqrt(-I)*Gausssum1d(gamma[j+5]+delta[j+5],0)*Kroneck(gamma[j+3]+delta[j+3]-gamma[j+4]-delta[j+4])*Kroneck(alpha[j+5]+beta[j+5])));
		    }
		  }
		  for(yppp=0; yppp<=(1+alpha[j+5])%2; yppp++) {
		    for(xppp=0;xppp<=(1+beta[j+5])%2; xppp++) {
		      summand += (2.0*(0.125*pow(2.0,(1-y*pow(gamma[i]-gamma[i+1],2)-pow(y-1,2)*pow(gamma[i]-delta[i+1],2))*(pow(yp-1,2)*(pow(xp,2)*(gamma[i+3]+delta[i+4])+pow(xp-1,2)*(gamma[i+4]+delta[i+3]))))*cexp(M_PI*I/2.0*((delta[i+1]-gamma[i])*pow(y+1,2)+2.0*(beta[i]+beta[i+1]+gamma[i]+delta[i+1])*x*pow(y+1,2)+2.0*(delta[i]+delta[i+1]+beta[i]+beta[i+1])*x*y+(2.0*beta[i]+3.0*delta[i]+delta[i+1])*y))*Gausssum1d(0.0,beta[i+2])*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1])*Kroneck(gamma[i+2]+delta[i+2]) 
				       + 0.125*pow(2.0,(1-y*pow(gamma[i]-gamma[i+1],2)-pow(y-1,2)*pow(gamma[i]-delta[i+1],2))*(pow(yp-1,2)*(pow(xp,2)*(gamma[i+3]+delta[i+4])+pow(xp-1,2)*(gamma[i+4]+delta[i+3]))))*cexp(M_PI*I/2.0*((delta[i+1]-gamma[i])*pow(y+1,2)+2.0*(beta[i]+beta[i+1]+gamma[i]+delta[i+1])*x*pow(y+1,2)+2.0*(delta[i]+delta[i+1]+beta[i]+beta[i+1])*x*y+(2.0*beta[i]+3.0*delta[i]+delta[i+1])*y))*csqrt(-I)*Gausssum1d(gamma[i+2]+delta[i+2],0)*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1])*Kroneck(alpha[i+2]+beta[i+2]))
				  *(0.125*(-I)*cexp(M_PI*I/2.0*(yp*(delta[i+3]+delta[i+4])+pow(yp+1,2)*(delta[i+3]+gamma[i+4]+2*beta[i+4])+pow(xp,2)+2*(beta[i+3]+beta[i+4]+delta[i+3]+gamma[i+4]*(yp+1)+delta[i+4]*yp)*xp))*Gausssum1d(0,xp+beta[i+3]+beta[i+4]+delta[i+3]+gamma[i+4]*(yp+1)+delta[i+4]*yp+gamma[i+5]+delta[i+5])*Kroneck(gamma[i+3]+delta[i+3]-gamma[i+4]-delta[i+4]+1)*Kroneck(alpha[i+5]+beta[i+5])))
			*((0.125*2.0*csqrt(-I)*cexp(M_PI*I/2.0*(2.0*beta[j+2]*ypp+pow(xpp+1,2)*(delta[j]+gamma[j+1]+2.0*beta[j+1])+xpp*(delta[j]+delta[j+1])))*Gausssum1d(1,beta[j]+beta[j+1]+delta[j]+(xpp+1)*gamma[j+1]+xpp*delta[j+1])*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1]+1)*Kroneck(gamma[j+2]+delta[j+2]))
			  *(0.125*2.0*csqrt(-I)*cexp(M_PI*I/2.0*(2.0*beta[j+5]*yppp+pow(xppp+1,2)*(delta[j+3]+gamma[j+4]+2.0*beta[j+4])+xppp*(delta[j+3]+delta[j+4])))*Gausssum1d(1,beta[j+3]+beta[j+4]+delta[j+3]+(xppp+1)*gamma[j+4]+xppp*delta[j+4])*Kroneck(gamma[j+3]+delta[j+3]-gamma[j+4]-delta[j+4]+1)*Kroneck(gamma[j+5]+delta[j+5])));
		    }
		  }
		  for(yppp=0; yppp<=1; yppp++) {
		    for(xppp=(yppp*(delta[j+3]+delta[j+4]))%2;xppp<=(1+yppp*(gamma[j+3]+gamma[j+4]))%2; xppp++) {
		      summand += (2.0*(0.125*pow(2.0,(1-y*pow(gamma[i]-gamma[i+1],2)-pow(y-1,2)*pow(gamma[i]-delta[i+1],2))*(pow(yp-1,2)*(pow(xp,2)*(gamma[i+3]+delta[i+4])+pow(xp-1,2)*(gamma[i+4]+delta[i+3]))))*cexp(M_PI*I/2.0*((delta[i+1]-gamma[i])*pow(y+1,2)+2.0*(beta[i]+beta[i+1]+gamma[i]+delta[i+1])*x*pow(y+1,2)+2.0*(delta[i]+delta[i+1]+beta[i]+beta[i+1])*x*y+(2.0*beta[i]+3.0*delta[i]+delta[i+1])*y))*Gausssum1d(0.0,beta[i+2])*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1])*Kroneck(gamma[i+2]+delta[i+2]) 
				       + 0.125*pow(2.0,(1-y*pow(gamma[i]-gamma[i+1],2)-pow(y-1,2)*pow(gamma[i]-delta[i+1],2))*(pow(yp-1,2)*(pow(xp,2)*(gamma[i+3]+delta[i+4])+pow(xp-1,2)*(gamma[i+4]+delta[i+3]))))*cexp(M_PI*I/2.0*((delta[i+1]-gamma[i])*pow(y+1,2)+2.0*(beta[i]+beta[i+1]+gamma[i]+delta[i+1])*x*pow(y+1,2)+2.0*(delta[i]+delta[i+1]+beta[i]+beta[i+1])*x*y+(2.0*beta[i]+3.0*delta[i]+delta[i+1])*y))*csqrt(-I)*Gausssum1d(gamma[i+2]+delta[i+2],0)*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1])*Kroneck(alpha[i+2]+beta[i+2]))
				  *(0.125*(-I)*cexp(M_PI*I/2.0*(yp*(delta[i+3]+delta[i+4])+pow(yp+1,2)*(delta[i+3]+gamma[i+4]+2*beta[i+4])+pow(xp,2)+2*(beta[i+3]+beta[i+4]+delta[i+3]+gamma[i+4]*(yp+1)+delta[i+4]*yp)*xp))*Gausssum1d(0,xp+beta[i+3]+beta[i+4]+delta[i+3]+gamma[i+4]*(yp+1)+delta[i+4]*yp+gamma[i+5]+delta[i+5])*Kroneck(gamma[i+3]+delta[i+3]-gamma[i+4]-delta[i+4]+1)*Kroneck(alpha[i+5]+beta[i+5])))
			*((0.125*2.0*csqrt(-I)*cexp(M_PI*I/2.0*(2.0*beta[j+2]*ypp+pow(xpp+1,2)*(delta[j]+gamma[j+1]+2.0*beta[j+1])+xpp*(delta[j]+delta[j+1])))*Gausssum1d(1,beta[j]+beta[j+1]+delta[j]+(xpp+1)*gamma[j+1]+xpp*delta[j+1])*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1]+1)*Kroneck(gamma[j+2]+delta[j+2]))
			  *(0.125*(-I)*pow(2.0,(pow(yppp-1,2)*(pow(xppp,2)*(gamma[j+3]+delta[j+4])+pow(xppp-1,2)*(gamma[j+4]+delta[j+3]))))*cexp(M_PI*I/2.0*(yppp*(delta[j+3]+delta[j+4])+pow(yppp+1,2)*(delta[j+3]+gamma[j+4]+2*beta[j+4])+pow(xppp,2)+2*(beta[j+3]+beta[j+4]+delta[j+3]+gamma[j+4]*(yppp+1)+delta[j+4]*yppp)*xppp))*Gausssum1d(0,xppp+beta[j+3]+beta[j+4]+delta[j+3]+gamma[j+4]*(yppp+1)+delta[j+4]*yppp+gamma[j+5]+delta[j+5])*Kroneck(gamma[j+3]+delta[j+3]-gamma[j+4]-delta[j+4]+1)*Kroneck(alpha[j+5]+beta[j+5])));
		    }
		  }
		}
	      }

	      //for(ypp=0; ypp<=1; ypp++) {
	      //**for(ypp=(x+yp)%2; ypp<=1; ypp++) {
	      for(ypp=(x*(1+alpha[i]+beta[i])+yp)%2; ypp<=1; ypp++) {
		//for(xpp=(ypp*(delta[j]+delta[j+1]))%2; xpp<=(1+ypp*(gamma[j]+gamma[j+1]))%2; xpp++) {
		//**for(xpp=(ypp*(delta[j]+delta[j+1])+x+yp)%2; xpp<=(1+ypp*(gamma[j]+gamma[j+1])+x+yp)%2; xpp++) {
		for(xpp=(ypp*(delta[j]+delta[j+1])+x*(1+alpha[i]+beta[i])+yp)%2; xpp<=(1+ypp*(gamma[j]+gamma[j+1])+x*(1+alpha[i]+beta[i])+yp)%2; xpp++) {
		  //for(yppp=((gamma[j+3]+delta[j+4])*ypp)%2; yppp<=(1+(gamma[j+3]+gamma[j+4])*ypp)%2; yppp++) {
		  for(yppp=((gamma[j+3]+delta[j+4])*(x+yp+ypp))%2; yppp<=(1+(gamma[j+3]+gamma[j+4])*(x+yp+ypp))%2; yppp++) {
		  //****for(yppp=((gamma[j+3]+delta[j+4])*(x*(1+alpha[i]+beta[i])+yp+ypp))%2; yppp<=(1+(gamma[j+3]+gamma[j+4])*(x*(1+alpha[i]+beta[i])+yp+ypp))%2; yppp++) {
		    //**for(xppp=0;xppp<=(yppp*(gamma[j+3]+gamma[j+4])+(yppp+1)*(gamma[j+3]+delta[j+4]))%2; xppp++) {
		    for(xppp=yppp*(beta[j+3]+alpha[j+4]+beta[j+4])%2;xppp<=(yppp*(beta[j+3]+alpha[j+4]+beta[j+4])+yppp*(gamma[j+3]+gamma[j+4])+(yppp+1)*(gamma[j+3]+delta[j+4]))%2; xppp++) {
		      //summand += (2.0*(0.125*pow(2.0,(1-y*pow(gamma[i]-gamma[i+1],2)-pow(y-1,2)*pow(gamma[i]-delta[i+1],2))*(pow(yp-1,2)*(pow(xp,2)*(gamma[i+3]+delta[i+4])+pow(xp-1,2)*(gamma[i+4]+delta[i+3]))))*cexp(M_PI*I/2.0*((delta[i+1]-gamma[i])*pow(y+1,2)+2.0*(beta[i]+beta[i+1]+gamma[i]+delta[i+1])*x*pow(y+1,2)+2.0*(delta[i]+delta[i+1]+beta[i]+beta[i+1])*x*y+(2.0*beta[i]+3.0*delta[i]+delta[i+1])*y))*Gausssum1d(0.0,beta[i+2])*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1])*Kroneck(gamma[i+2]+delta[i+2]) 
		      summand += 2.0*(2.0*(0.125*pow(2.0,(1-y*pow(gamma[i]-gamma[i+1],2)-pow(y-1,2)*pow(gamma[i]-delta[i+1],2))*(pow(yp-1,2)*(pow(xp,2)*(gamma[i+3]+delta[i+4])+pow(xp-1,2)*(gamma[i+4]+delta[i+3])))*(pow(ypp-1,2)*(pow(xpp,2)*(gamma[j]+delta[j+1])+pow(xpp-1,2)*(gamma[j+1]+delta[j])))*(1-yppp*pow(gamma[j+3]-gamma[j+4],2)-pow(yppp-1,2)*pow(gamma[j+3]-delta[j+4],2)))*cexp(M_PI*I/2.0*((delta[i+1]-gamma[i])*pow(y+1,2)+2.0*(beta[i]+beta[i+1]+gamma[i]+delta[i+1])*x*pow(y+1,2)+2.0*(delta[i]+delta[i+1]+beta[i]+beta[i+1])*x*y+(2.0*beta[i]+3.0*delta[i]+delta[i+1])*y))*Gausssum1d(0.0,beta[i+2])*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1])*Kroneck(gamma[i+2]+delta[i+2]) 
				       //+ 0.125*pow(2.0,(1-y*pow(gamma[i]-gamma[i+1],2)-pow(y-1,2)*pow(gamma[i]-delta[i+1],2))*(pow(yp-1,2)*(pow(xp,2)*(gamma[i+3]+delta[i+4])+pow(xp-1,2)*(gamma[i+4]+delta[i+3]))))*cexp(M_PI*I/2.0*((delta[i+1]-gamma[i])*pow(y+1,2)+2.0*(beta[i]+beta[i+1]+gamma[i]+delta[i+1])*x*pow(y+1,2)+2.0*(delta[i]+delta[i+1]+beta[i]+beta[i+1])*x*y+(2.0*beta[i]+3.0*delta[i]+delta[i+1])*y))*csqrt(-I)*Gausssum1d(gamma[i+2]+delta[i+2],0)*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1])*Kroneck(alpha[i+2]+beta[i+2]))
				       + 0.125*pow(2.0,(1-y*pow(gamma[i]-gamma[i+1],2)-pow(y-1,2)*pow(gamma[i]-delta[i+1],2))*(pow(yp-1,2)*(pow(xp,2)*(gamma[i+3]+delta[i+4])+pow(xp-1,2)*(gamma[i+4]+delta[i+3])))*(pow(ypp-1,2)*(pow(xpp,2)*(gamma[j]+delta[j+1])+pow(xpp-1,2)*(gamma[j+1]+delta[j])))*(1-yppp*pow(gamma[j+3]-gamma[j+4],2)-pow(yppp-1,2)*pow(gamma[j+3]-delta[j+4],2)))*cexp(M_PI*I/2.0*((delta[i+1]-gamma[i])*pow(y+1,2)+2.0*(beta[i]+beta[i+1]+gamma[i]+delta[i+1])*x*pow(y+1,2)+2.0*(delta[i]+delta[i+1]+beta[i]+beta[i+1])*x*y+(2.0*beta[i]+3.0*delta[i]+delta[i+1])*y))*csqrt(-I)*Gausssum1d(gamma[i+2]+delta[i+2],0)*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1])*Kroneck(alpha[i+2]+beta[i+2]))
				  *(0.125*(-I)*cexp(M_PI*I/2.0*(yp*(delta[i+3]+delta[i+4])+pow(yp+1,2)*(delta[i+3]+gamma[i+4]+2*beta[i+4])+pow(xp,2)+2*(beta[i+3]+beta[i+4]+delta[i+3]+gamma[i+4]*(yp+1)+delta[i+4]*yp)*xp))*Gausssum1d(0,xp+beta[i+3]+beta[i+4]+delta[i+3]+gamma[i+4]*(yp+1)+delta[i+4]*yp+gamma[i+5]+delta[i+5])*Kroneck(gamma[i+3]+delta[i+3]-gamma[i+4]-delta[i+4]+1)*Kroneck(alpha[i+5]+beta[i+5])))
			//*(2.0*(0.125*pow(2.0,(pow(ypp-1,2)*(pow(xpp,2)*(gamma[j]+delta[j+1])+pow(xpp-1,2)*(gamma[j+1]+delta[j])))*(1-yppp*pow(gamma[j+3]-gamma[j+4],2)-pow(yppp-1,2)*pow(gamma[j+3]-delta[j+4],2)))*(-I)*cexp(M_PI*I/2.0*(ypp*(delta[j]+delta[j+1])+pow(ypp+1,2)*(delta[j]+gamma[j+1]+2*beta[j+1])+pow(xpp,2)+2*(beta[j]+beta[j+1]+delta[j]+gamma[j+1]*(ypp+1)+delta[j+1]*ypp)*xpp))*Gausssum1d(0,xpp+beta[j]+beta[j+1]+delta[j]+gamma[j+1]*(ypp+1)+delta[j+1]*ypp+gamma[j+2]+delta[j+2])*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1]+1)*Kroneck(alpha[j+2]+beta[j+2]))
			*(2.0*(0.125*(-I)*cexp(M_PI*I/2.0*(ypp*(delta[j]+delta[j+1])+pow(ypp+1,2)*(delta[j]+gamma[j+1]+2*beta[j+1])+pow(xpp,2)+2*(beta[j]+beta[j+1]+delta[j]+gamma[j+1]*(ypp+1)+delta[j+1]*ypp)*xpp))*Gausssum1d(0,xpp+beta[j]+beta[j+1]+delta[j]+gamma[j+1]*(ypp+1)+delta[j+1]*ypp+gamma[j+2]+delta[j+2])*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1]+1)*Kroneck(alpha[j+2]+beta[j+2]))
			  *(0.125*cexp(M_PI*I/2.0*((delta[j+4]-gamma[j+3])*pow(yppp+1,2)+2.0*(beta[j+3]+beta[j+4]+gamma[j+3]+delta[j+4])*xppp*pow(yppp+1,2)+2.0*(delta[j+3]+delta[j+4]+beta[j+3]+beta[j+4])*xppp*yppp+(2.0*beta[j+3]+3.0*delta[j+3]+delta[j+4])*yppp))*Gausssum1d(0.0,beta[j+5])*Kroneck(gamma[j+3]+delta[j+3]-gamma[j+4]-delta[j+4])*Kroneck(gamma[j+5]+delta[j+5]) 
			    + 0.125*cexp(M_PI*I/2.0*((delta[j+4]-gamma[j+3])*pow(yppp+1,2)+2.0*(beta[j+3]+beta[j+4]+gamma[j+3]+delta[j+4])*xppp*pow(yppp+1,2)+2.0*(delta[j+3]+delta[j+4]+beta[j+3]+beta[j+4])*xppp*yppp+(2.0*beta[j+3]+3.0*delta[j+3]+delta[j+4])*yppp))*csqrt(-I)*Gausssum1d(gamma[j+5]+delta[j+5],0)*Kroneck(gamma[j+3]+delta[j+3]-gamma[j+4]-delta[j+4])*Kroneck(alpha[j+5]+beta[j+5])));
		    }
		  }
		}
	      }
	      for(ypp=0; ypp<=1; ypp++) {
		for(xpp=(ypp*(delta[j]+delta[j+1]))%2; xpp<=(1+ypp*(gamma[j]+gamma[j+1]))%2; xpp++) {
		  for(yppp=0; yppp<=(1+alpha[j+5])%2; yppp++) {
		    for(xppp=0;xppp<=(1+beta[j+5])%2; xppp++) {
		      summand += (2.0*(0.125*pow(2.0,(1-y*pow(gamma[i]-gamma[i+1],2)-pow(y-1,2)*pow(gamma[i]-delta[i+1],2))*(pow(yp-1,2)*(pow(xp,2)*(gamma[i+3]+delta[i+4])+pow(xp-1,2)*(gamma[i+4]+delta[i+3]))))*cexp(M_PI*I/2.0*((delta[i+1]-gamma[i])*pow(y+1,2)+2.0*(beta[i]+beta[i+1]+gamma[i]+delta[i+1])*x*pow(y+1,2)+2.0*(delta[i]+delta[i+1]+beta[i]+beta[i+1])*x*y+(2.0*beta[i]+3.0*delta[i]+delta[i+1])*y))*Gausssum1d(0.0,beta[i+2])*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1])*Kroneck(gamma[i+2]+delta[i+2]) 
				       + 0.125*pow(2.0,(1-y*pow(gamma[i]-gamma[i+1],2)-pow(y-1,2)*pow(gamma[i]-delta[i+1],2))*(pow(yp-1,2)*(pow(xp,2)*(gamma[i+3]+delta[i+4])+pow(xp-1,2)*(gamma[i+4]+delta[i+3]))))*cexp(M_PI*I/2.0*((delta[i+1]-gamma[i])*pow(y+1,2)+2.0*(beta[i]+beta[i+1]+gamma[i]+delta[i+1])*x*pow(y+1,2)+2.0*(delta[i]+delta[i+1]+beta[i]+beta[i+1])*x*y+(2.0*beta[i]+3.0*delta[i]+delta[i+1])*y))*csqrt(-I)*Gausssum1d(gamma[i+2]+delta[i+2],0)*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1])*Kroneck(alpha[i+2]+beta[i+2]))
				  *(0.125*(-I)*cexp(M_PI*I/2.0*(yp*(delta[i+3]+delta[i+4])+pow(yp+1,2)*(delta[i+3]+gamma[i+4]+2*beta[i+4])+pow(xp,2)+2*(beta[i+3]+beta[i+4]+delta[i+3]+gamma[i+4]*(yp+1)+delta[i+4]*yp)*xp))*Gausssum1d(0,xp+beta[i+3]+beta[i+4]+delta[i+3]+gamma[i+4]*(yp+1)+delta[i+4]*yp+gamma[i+5]+delta[i+5])*Kroneck(gamma[i+3]+delta[i+3]-gamma[i+4]-delta[i+4]+1)*Kroneck(alpha[i+5]+beta[i+5])))
			*((0.125*pow(2.0,pow(ypp-1,2)*(pow(xpp,2)*(gamma[j]+delta[j+1])+pow(xpp-1,2)*(gamma[j+1]+delta[j])))*(-I)*cexp(M_PI*I/2.0*(ypp*(delta[j]+delta[j+1])+pow(ypp+1,2)*(delta[j]+gamma[j+1]+2*beta[j+1])+pow(xpp,2)+2*(beta[j]+beta[j+1]+delta[j]+gamma[j+1]*(ypp+1)+delta[j+1]*ypp)*xpp))*Gausssum1d(0,xpp+beta[j]+beta[j+1]+delta[j]+gamma[j+1]*(ypp+1)+delta[j+1]*ypp+gamma[j+2]+delta[j+2])*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1]+1)*Kroneck(alpha[j+2]+beta[j+2]))
			  *(0.125*2.0*csqrt(-I)*cexp(M_PI*I/2.0*(2.0*beta[j+5]*yppp+pow(xppp+1,2)*(delta[j+3]+gamma[j+4]+2.0*beta[j+4])+xppp*(delta[j+3]+delta[j+4])))*Gausssum1d(1,beta[j+3]+beta[j+4]+delta[j+3]+(xppp+1)*gamma[j+4]+xppp*delta[j+4])*Kroneck(gamma[j+3]+delta[j+3]-gamma[j+4]-delta[j+4]+1)*Kroneck(gamma[j+5]+delta[j+5])));
		    }
		  }
		}
	      }
	      //for(ypp=0; ypp<=1; ypp++) {
	      //**for(ypp=(x+yp)%2; ypp<=1; ypp++) {
	      for(ypp=(x*(1+alpha[i]+beta[i])+yp)%2; ypp<=1; ypp++) {
		//for(xpp=(ypp*(delta[j]+delta[j+1]))%2; xpp<=(1+ypp*(gamma[j]+gamma[j+1]))%2; xpp++) {
		//**for(xpp=(ypp*(delta[j]+delta[j+1])+x+yp)%2; xpp<=(1+ypp*(gamma[j]+gamma[j+1])+x+yp)%2; xpp++) {
		for(xpp=(ypp*(delta[j]+delta[j+1])+x*(1+alpha[i]+beta[i])+yp)%2; xpp<=(1+ypp*(gamma[j]+gamma[j+1])+x*(1+alpha[i]+beta[i])+yp)%2; xpp++) {
		  //for(yppp=ypp; yppp<=1; yppp++) {
		  //**for(yppp=(x+yp+ypp)%2; yppp<=1; yppp++) {
		  for(yppp=(x*(1+alpha[i]+beta[i])+yp+ypp)%2; yppp<=1; yppp++) {
		    //for(xppp=(yppp*(delta[j+3]+delta[j+4])+ypp)%2;xppp<=(1+yppp*(gamma[j+3]+gamma[j+4])+ypp)%2; xppp++) {
		    //**for(xppp=(yppp*(delta[j+3]+delta[j+4])+x+yp+ypp)%2;xppp<=(1+yppp*(gamma[j+3]+gamma[j+4])+x+yp+ypp)%2; xppp++) {
		    for(xppp=(yppp*(delta[j+3]+delta[j+4])+x*(1+alpha[i]+beta[i])+yp+ypp)%2;xppp<=(1+yppp*(gamma[j+3]+gamma[j+4])+x*(1+alpha[i]+beta[i])+yp+ypp)%2; xppp++) {
		      //summand += (2.0*(0.125*pow(2.0,(1-y*pow(gamma[i]-gamma[i+1],2)-pow(y-1,2)*pow(gamma[i]-delta[i+1],2))*(pow(yp-1,2)*(pow(xp,2)*(gamma[i+3]+delta[i+4])+pow(xp-1,2)*(gamma[i+4]+delta[i+3]))))*cexp(M_PI*I/2.0*((delta[i+1]-gamma[i])*pow(y+1,2)+2.0*(beta[i]+beta[i+1]+gamma[i]+delta[i+1])*x*pow(y+1,2)+2.0*(delta[i]+delta[i+1]+beta[i]+beta[i+1])*x*y+(2.0*beta[i]+3.0*delta[i]+delta[i+1])*y))*Gausssum1d(0.0,beta[i+2])*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1])*Kroneck(gamma[i+2]+delta[i+2]) 
		      summand += 2.0*(2.0*(0.125*pow(2.0,(1-y*pow(gamma[i]-gamma[i+1],2)-pow(y-1,2)*pow(gamma[i]-delta[i+1],2))*(pow(yp-1,2)*(pow(xp,2)*(gamma[i+3]+delta[i+4])+pow(xp-1,2)*(gamma[i+4]+delta[i+3])))*(pow(ypp-1,2)*(pow(xpp,2)*(gamma[j]+delta[j+1])+pow(xpp-1,2)*(gamma[j+1]+delta[j])))*(pow(yppp-1,2)*(pow(xppp,2)*(gamma[j+3]+delta[j+4])+pow(xppp-1,2)*(gamma[j+4]+delta[j+3]))))*cexp(M_PI*I/2.0*((delta[i+1]-gamma[i])*pow(y+1,2)+2.0*(beta[i]+beta[i+1]+gamma[i]+delta[i+1])*x*pow(y+1,2)+2.0*(delta[i]+delta[i+1]+beta[i]+beta[i+1])*x*y+(2.0*beta[i]+3.0*delta[i]+delta[i+1])*y))*Gausssum1d(0.0,beta[i+2])*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1])*Kroneck(gamma[i+2]+delta[i+2]) 
				       //+ 0.125*pow(2.0,(1-y*pow(gamma[i]-gamma[i+1],2)-pow(y-1,2)*pow(gamma[i]-delta[i+1],2))*(pow(yp-1,2)*(pow(xp,2)*(gamma[i+3]+delta[i+4])+pow(xp-1,2)*(gamma[i+4]+delta[i+3]))))*cexp(M_PI*I/2.0*((delta[i+1]-gamma[i])*pow(y+1,2)+2.0*(beta[i]+beta[i+1]+gamma[i]+delta[i+1])*x*pow(y+1,2)+2.0*(delta[i]+delta[i+1]+beta[i]+beta[i+1])*x*y+(2.0*beta[i]+3.0*delta[i]+delta[i+1])*y))*csqrt(-I)*Gausssum1d(gamma[i+2]+delta[i+2],0)*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1])*Kroneck(alpha[i+2]+beta[i+2]))
				       + 0.125*pow(2.0,(1-y*pow(gamma[i]-gamma[i+1],2)-pow(y-1,2)*pow(gamma[i]-delta[i+1],2))*(pow(yp-1,2)*(pow(xp,2)*(gamma[i+3]+delta[i+4])+pow(xp-1,2)*(gamma[i+4]+delta[i+3])))*(pow(ypp-1,2)*(pow(xpp,2)*(gamma[j]+delta[j+1])+pow(xpp-1,2)*(gamma[j+1]+delta[j])))*(pow(yppp-1,2)*(pow(xppp,2)*(gamma[j+3]+delta[j+4])+pow(xppp-1,2)*(gamma[j+4]+delta[j+3]))))*cexp(M_PI*I/2.0*((delta[i+1]-gamma[i])*pow(y+1,2)+2.0*(beta[i]+beta[i+1]+gamma[i]+delta[i+1])*x*pow(y+1,2)+2.0*(delta[i]+delta[i+1]+beta[i]+beta[i+1])*x*y+(2.0*beta[i]+3.0*delta[i]+delta[i+1])*y))*csqrt(-I)*Gausssum1d(gamma[i+2]+delta[i+2],0)*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1])*Kroneck(alpha[i+2]+beta[i+2]))
				  *(0.125*(-I)*cexp(M_PI*I/2.0*(yp*(delta[i+3]+delta[i+4])+pow(yp+1,2)*(delta[i+3]+gamma[i+4]+2*beta[i+4])+pow(xp,2)+2*(beta[i+3]+beta[i+4]+delta[i+3]+gamma[i+4]*(yp+1)+delta[i+4]*yp)*xp))*Gausssum1d(0,xp+beta[i+3]+beta[i+4]+delta[i+3]+gamma[i+4]*(yp+1)+delta[i+4]*yp+gamma[i+5]+delta[i+5])*Kroneck(gamma[i+3]+delta[i+3]-gamma[i+4]-delta[i+4]+1)*Kroneck(alpha[i+5]+beta[i+5])))
			//*(2.0*(0.125*pow(2.0,(pow(ypp-1,2)*(pow(xpp,2)*(gamma[j]+delta[j+1])+pow(xpp-1,2)*(gamma[j+1]+delta[j])))*(pow(yppp-1,2)*(pow(xppp,2)*(gamma[j+3]+delta[j+4])+pow(xppp-1,2)*(gamma[j+4]+delta[j+3]))))*(-I)*cexp(M_PI*I/2.0*(ypp*(delta[j]+delta[j+1])+pow(ypp+1,2)*(delta[j]+gamma[j+1]+2*beta[j+1])+pow(xpp,2)+2*(beta[j]+beta[j+1]+delta[j]+gamma[j+1]*(ypp+1)+delta[j+1]*ypp)*xpp))*Gausssum1d(0,xpp+beta[j]+beta[j+1]+delta[j]+gamma[j+1]*(ypp+1)+delta[j+1]*ypp+gamma[j+2]+delta[j+2])*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1]+1)*Kroneck(alpha[j+2]+beta[j+2]))
			*(2.0*(0.125*(-I)*cexp(M_PI*I/2.0*(ypp*(delta[j]+delta[j+1])+pow(ypp+1,2)*(delta[j]+gamma[j+1]+2*beta[j+1])+pow(xpp,2)+2*(beta[j]+beta[j+1]+delta[j]+gamma[j+1]*(ypp+1)+delta[j+1]*ypp)*xpp))*Gausssum1d(0,xpp+beta[j]+beta[j+1]+delta[j]+gamma[j+1]*(ypp+1)+delta[j+1]*ypp+gamma[j+2]+delta[j+2])*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1]+1)*Kroneck(alpha[j+2]+beta[j+2]))
			  *(0.125*(-I)*cexp(M_PI*I/2.0*(yppp*(delta[j+3]+delta[j+4])+pow(yppp+1,2)*(delta[j+3]+gamma[j+4]+2*beta[j+4])+pow(xppp,2)+2*(beta[j+3]+beta[j+4]+delta[j+3]+gamma[j+4]*(yppp+1)+delta[j+4]*yppp)*xppp))*Gausssum1d(0,xppp+beta[j+3]+beta[j+4]+delta[j+3]+gamma[j+4]*(yppp+1)+delta[j+4]*yppp+gamma[j+5]+delta[j+5])*Kroneck(gamma[j+3]+delta[j+3]-gamma[j+4]-delta[j+4]+1)*Kroneck(alpha[j+5]+beta[j+5])));
		    }
		  }
		}
	      }
	    }
	  }
	}
      }
      
      
      // fourth term
      for(y=0; y<=(1+alpha[i+2])%2; y++) {
	for(x=0; x<=(1+beta[i+2])%2; x++) {
	  for(yp=0; yp<=1; yp++) {
	    //**for(xp=0;xp<=(yp*(gamma[i+3]+gamma[i+4])+(yp+1)*(gamma[i+3]+delta[i+4]))%2; xp++) {
	    for(xp=yp*(beta[i+3]+alpha[i+4]+beta[i+4])%2;xp<=(yp*(beta[i+3]+alpha[i+4]+beta[i+4])+yp*(gamma[i+3]+gamma[i+4])+(yp+1)*(gamma[i+3]+delta[i+4]))%2; xp++) {
	      for(ypp=0; ypp<=1; ypp++) {
		//**for(xpp=0;xpp<=(ypp*(gamma[j]+gamma[j+1])+(ypp+1)*(gamma[j]+delta[j+1]))%2; xpp++) {
		for(xpp=ypp*(beta[j]+alpha[j+1]+beta[j+1])%2;xpp<=(ypp*(beta[j]+alpha[j+1]+beta[j+1])+ypp*(gamma[j]+gamma[j+1])+(ypp+1)*(gamma[j]+delta[j+1]))%2; xpp++) {
		  for(yppp=((gamma[j+3]+delta[j+4])*xpp)%2; yppp<=(1+(gamma[j+3]+gamma[j+4])*xpp)%2; yppp++) {
		    //**for(xppp=0;xppp<=(yppp*(gamma[j+3]+gamma[j+4])+(yppp+1)*(gamma[j+3]+delta[j+4]))%2; xppp++) {
		    for(xppp=yppp*(beta[j+3]+alpha[j+4]+beta[j+4])%2;xppp<=(yppp*(beta[j+3]+alpha[j+4]+beta[j+4])+yppp*(gamma[j+3]+gamma[j+4])+(yppp+1)*(gamma[j+3]+delta[j+4]))%2; xppp++) {
		    
		      summand += ((0.125*2.0*csqrt(-I)*cexp(M_PI*I/2.0*(2.0*beta[i+2]*y+pow(x+1,2)*(delta[i]+gamma[i+1]+2.0*beta[i+1])+x*(delta[i]+delta[i+1])))*Gausssum1d(1,beta[i]+beta[i+1]+delta[i]+(x+1)*gamma[i+1]+x*delta[i+1])*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1]+1)*Kroneck(gamma[i+2]+delta[i+2]))
		*(0.125*pow(2.0,1-yp*pow(gamma[i+3]-gamma[i+4],2)-pow(yp-1,2)*pow(gamma[i+3]-delta[i+4],2))*cexp(M_PI*I/2.0*((delta[i+4]-gamma[i+3])*pow(yp+1,2)+2.0*(beta[i+3]+beta[i+4]+gamma[i+3]+delta[i+4])*xp*pow(yp+1,2)+2.0*(delta[i+3]+delta[i+4]+beta[i+3]+beta[i+4])*xp*yp+(2.0*beta[i+3]+3.0*delta[i+3]+delta[i+4])*yp))*Gausssum1d(0.0,beta[i+5])*Kroneck(gamma[i+3]+delta[i+3]-gamma[i+4]-delta[i+4])*Kroneck(gamma[i+5]+delta[i+5]) 
		  + 0.125*pow(2.0,1-yp*pow(gamma[i+3]-gamma[i+4],2)-pow(yp-1,2)*pow(gamma[i+3]-delta[i+4],2))*cexp(M_PI*I/2.0*((delta[i+4]-gamma[i+3])*pow(yp+1,2)+2.0*(beta[i+3]+beta[i+4]+gamma[i+3]+delta[i+4])*xp*pow(yp+1,2)+2.0*(delta[i+3]+delta[i+4]+beta[i+3]+beta[i+4])*xp*yp+(2.0*beta[i+3]+3.0*delta[i+3]+delta[i+4])*yp))*csqrt(-I)*Gausssum1d(gamma[i+5]+delta[i+5],0)*Kroneck(gamma[i+3]+delta[i+3]-gamma[i+4]-delta[i+4])*Kroneck(alpha[i+5]+beta[i+5])))
			*(2.0*(0.125*pow(2.0,(1-ypp*pow(gamma[j]-gamma[j+1],2)-pow(ypp-1,2)*pow(gamma[j]-delta[j+1],2))*(1-yppp*pow(gamma[j+3]-gamma[j+4],2)-pow(yppp-1,2)*pow(gamma[j+3]-delta[j+4],2)))*cexp(M_PI*I/2.0*((delta[j+1]-gamma[j])*pow(ypp+1,2)+2.0*(beta[j]+beta[j+1]+gamma[j]+delta[j+1])*xpp*pow(ypp+1,2)+2.0*(delta[j]+delta[j+1]+beta[j]+beta[j+1])*xpp*ypp+(2.0*beta[j]+3.0*delta[j]+delta[j+1])*ypp))*Gausssum1d(0.0,beta[j+2])*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1])*Kroneck(gamma[j+2]+delta[j+2]) 
			      + 0.125*pow(2.0,(1-ypp*pow(gamma[j]-gamma[j+1],2)-pow(ypp-1,2)*pow(gamma[j]-delta[j+1],2))*(1-yppp*pow(gamma[j+3]-gamma[j+4],2)-pow(yppp-1,2)*pow(gamma[j+3]-delta[j+4],2)))*cexp(M_PI*I/2.0*((delta[j+1]-gamma[j])*pow(ypp+1,2)+2.0*(beta[j]+beta[j+1]+gamma[j]+delta[j+1])*xpp*pow(ypp+1,2)+2.0*(delta[j]+delta[j+1]+beta[j]+beta[j+1])*xpp*ypp+(2.0*beta[j]+3.0*delta[j]+delta[j+1])*ypp))*csqrt(-I)*Gausssum1d(gamma[j+2]+delta[j+2],0)*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1])*Kroneck(alpha[j+2]+beta[j+2]))
			*(0.125*cexp(M_PI*I/2.0*((delta[j+4]-gamma[j+3])*pow(yppp+1,2)+2.0*(beta[j+3]+beta[j+4]+gamma[j+3]+delta[j+4])*xppp*pow(yppp+1,2)+2.0*(delta[j+3]+delta[j+4]+beta[j+3]+beta[j+4])*xppp*yppp+(2.0*beta[j+3]+3.0*delta[j+3]+delta[j+4])*yppp))*Gausssum1d(0.0,beta[j+5])*Kroneck(gamma[j+3]+delta[j+3]-gamma[j+4]-delta[j+4])*Kroneck(gamma[j+5]+delta[j+5]) 
			  + 0.125*cexp(M_PI*I/2.0*((delta[j+4]-gamma[j+3])*pow(yppp+1,2)+2.0*(beta[j+3]+beta[j+4]+gamma[j+3]+delta[j+4])*xppp*pow(yppp+1,2)+2.0*(delta[j+3]+delta[j+4]+beta[j+3]+beta[j+4])*xppp*yppp+(2.0*beta[j+3]+3.0*delta[j+3]+delta[j+4])*yppp))*csqrt(-I)*Gausssum1d(gamma[j+5]+delta[j+5],0)*Kroneck(gamma[j+3]+delta[j+3]-gamma[j+4]-delta[j+4])*Kroneck(alpha[j+5]+beta[j+5])));
		    }
		  }
		  for(yppp=0; yppp<=(1+alpha[j+5])%2; yppp++) {
		    for(xppp=0;xppp<=(1+beta[j+5])%2; xppp++) {
		      summand += ((0.125*2.0*csqrt(-I)*cexp(M_PI*I/2.0*(2.0*beta[i+2]*y+pow(x+1,2)*(delta[i]+gamma[i+1]+2.0*beta[i+1])+x*(delta[i]+delta[i+1])))*Gausssum1d(1,beta[i]+beta[i+1]+delta[i]+(x+1)*gamma[i+1]+x*delta[i+1])*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1]+1)*Kroneck(gamma[i+2]+delta[i+2]))
		*(0.125*pow(2.0,1-yp*pow(gamma[i+3]-gamma[i+4],2)-pow(yp-1,2)*pow(gamma[i+3]-delta[i+4],2))*cexp(M_PI*I/2.0*((delta[i+4]-gamma[i+3])*pow(yp+1,2)+2.0*(beta[i+3]+beta[i+4]+gamma[i+3]+delta[i+4])*xp*pow(yp+1,2)+2.0*(delta[i+3]+delta[i+4]+beta[i+3]+beta[i+4])*xp*yp+(2.0*beta[i+3]+3.0*delta[i+3]+delta[i+4])*yp))*Gausssum1d(0.0,beta[i+5])*Kroneck(gamma[i+3]+delta[i+3]-gamma[i+4]-delta[i+4])*Kroneck(gamma[i+5]+delta[i+5]) 
		  + 0.125*pow(2.0,1-yp*pow(gamma[i+3]-gamma[i+4],2)-pow(yp-1,2)*pow(gamma[i+3]-delta[i+4],2))*cexp(M_PI*I/2.0*((delta[i+4]-gamma[i+3])*pow(yp+1,2)+2.0*(beta[i+3]+beta[i+4]+gamma[i+3]+delta[i+4])*xp*pow(yp+1,2)+2.0*(delta[i+3]+delta[i+4]+beta[i+3]+beta[i+4])*xp*yp+(2.0*beta[i+3]+3.0*delta[i+3]+delta[i+4])*yp))*csqrt(-I)*Gausssum1d(gamma[i+5]+delta[i+5],0)*Kroneck(gamma[i+3]+delta[i+3]-gamma[i+4]-delta[i+4])*Kroneck(alpha[i+5]+beta[i+5])))
			*((0.125*pow(2.0,1-ypp*pow(gamma[j]-gamma[j+1],2)-pow(ypp-1,2)*pow(gamma[j]-delta[j+1],2))*cexp(M_PI*I/2.0*((delta[j+1]-gamma[j])*pow(ypp+1,2)+2.0*(beta[j]+beta[j+1]+gamma[j]+delta[j+1])*xpp*pow(ypp+1,2)+2.0*(delta[j]+delta[j+1]+beta[j]+beta[j+1])*xpp*ypp+(2.0*beta[j]+3.0*delta[j]+delta[j+1])*ypp))*Gausssum1d(0.0,beta[j+2])*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1])*Kroneck(gamma[j+2]+delta[j+2]) 
				  + 0.125*pow(2.0,1-ypp*pow(gamma[j]-gamma[j+1],2)-pow(ypp-1,2)*pow(gamma[j]-delta[j+1],2))*cexp(M_PI*I/2.0*((delta[j+1]-gamma[j])*pow(ypp+1,2)+2.0*(beta[j]+beta[j+1]+gamma[j]+delta[j+1])*xpp*pow(ypp+1,2)+2.0*(delta[j]+delta[j+1]+beta[j]+beta[j+1])*xpp*ypp+(2.0*beta[j]+3.0*delta[j]+delta[j+1])*ypp))*csqrt(-I)*Gausssum1d(gamma[j+2]+delta[j+2],0)*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1])*Kroneck(alpha[j+2]+beta[j+2]))
			  *(0.125*2.0*csqrt(-I)*cexp(M_PI*I/2.0*(2.0*beta[j+5]*yppp+pow(xppp+1,2)*(delta[j+3]+gamma[j+4]+2.0*beta[j+4])+xppp*(delta[j+3]+delta[j+4])))*Gausssum1d(1,beta[j+3]+beta[j+4]+delta[j+3]+(xppp+1)*gamma[j+4]+xppp*delta[j+4])*Kroneck(gamma[j+3]+delta[j+3]-gamma[j+4]-delta[j+4]+1)*Kroneck(gamma[j+5]+delta[j+5])));
		    }
		  }
		  //**for(yppp=xpp; yppp<=1; yppp++) {
		  for(yppp=xpp*(1+alpha[j]+beta[j])%2; yppp<=1; yppp++) {
		    //**for(xppp=(yppp*(delta[j+3]+delta[j+4])+xpp)%2;xppp<=(1+yppp*(gamma[j+3]+gamma[j+4])+xpp)%2; xppp++) {
		    for(xppp=(yppp*(delta[j+3]+delta[j+4])+xpp*(1+alpha[j]+beta[j]))%2;xppp<=(1+yppp*(gamma[j+3]+gamma[j+4])+xpp*(1+alpha[j]+beta[j]))%2; xppp++) {
		      summand += ((0.125*2.0*csqrt(-I)*cexp(M_PI*I/2.0*(2.0*beta[i+2]*y+pow(x+1,2)*(delta[i]+gamma[i+1]+2.0*beta[i+1])+x*(delta[i]+delta[i+1])))*Gausssum1d(1,beta[i]+beta[i+1]+delta[i]+(x+1)*gamma[i+1]+x*delta[i+1])*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1]+1)*Kroneck(gamma[i+2]+delta[i+2]))
		*(0.125*pow(2.0,1-yp*pow(gamma[i+3]-gamma[i+4],2)-pow(yp-1,2)*pow(gamma[i+3]-delta[i+4],2))*cexp(M_PI*I/2.0*((delta[i+4]-gamma[i+3])*pow(yp+1,2)+2.0*(beta[i+3]+beta[i+4]+gamma[i+3]+delta[i+4])*xp*pow(yp+1,2)+2.0*(delta[i+3]+delta[i+4]+beta[i+3]+beta[i+4])*xp*yp+(2.0*beta[i+3]+3.0*delta[i+3]+delta[i+4])*yp))*Gausssum1d(0.0,beta[i+5])*Kroneck(gamma[i+3]+delta[i+3]-gamma[i+4]-delta[i+4])*Kroneck(gamma[i+5]+delta[i+5]) 
		  + 0.125*pow(2.0,1-yp*pow(gamma[i+3]-gamma[i+4],2)-pow(yp-1,2)*pow(gamma[i+3]-delta[i+4],2))*cexp(M_PI*I/2.0*((delta[i+4]-gamma[i+3])*pow(yp+1,2)+2.0*(beta[i+3]+beta[i+4]+gamma[i+3]+delta[i+4])*xp*pow(yp+1,2)+2.0*(delta[i+3]+delta[i+4]+beta[i+3]+beta[i+4])*xp*yp+(2.0*beta[i+3]+3.0*delta[i+3]+delta[i+4])*yp))*csqrt(-I)*Gausssum1d(gamma[i+5]+delta[i+5],0)*Kroneck(gamma[i+3]+delta[i+3]-gamma[i+4]-delta[i+4])*Kroneck(alpha[i+5]+beta[i+5])))
			*(2.0*(0.125*pow(2.0,(1-ypp*pow(gamma[j]-gamma[j+1],2)-pow(ypp-1,2)*pow(gamma[j]-delta[j+1],2))*(pow(yppp-1,2)*(pow(xppp,2)*(gamma[j+3]+delta[j+4])+pow(xppp-1,2)*(gamma[j+4]+delta[j+3]))))*cexp(M_PI*I/2.0*((delta[j+1]-gamma[j])*pow(ypp+1,2)+2.0*(beta[j]+beta[j+1]+gamma[j]+delta[j+1])*xpp*pow(ypp+1,2)+2.0*(delta[j]+delta[j+1]+beta[j]+beta[j+1])*xpp*ypp+(2.0*beta[j]+3.0*delta[j]+delta[j+1])*ypp))*Gausssum1d(0.0,beta[j+2])*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1])*Kroneck(gamma[j+2]+delta[j+2]) 
				      + 0.125*pow(2.0,(1-ypp*pow(gamma[j]-gamma[j+1],2)-pow(ypp-1,2)*pow(gamma[j]-delta[j+1],2))*(pow(yppp-1,2)*(pow(xppp,2)*(gamma[j+3]+delta[j+4])+pow(xppp-1,2)*(gamma[j+4]+delta[j+3]))))*cexp(M_PI*I/2.0*((delta[j+1]-gamma[j])*pow(ypp+1,2)+2.0*(beta[j]+beta[j+1]+gamma[j]+delta[j+1])*xpp*pow(ypp+1,2)+2.0*(delta[j]+delta[j+1]+beta[j]+beta[j+1])*xpp*ypp+(2.0*beta[j]+3.0*delta[j]+delta[j+1])*ypp))*csqrt(-I)*Gausssum1d(gamma[j+2]+delta[j+2],0)*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1])*Kroneck(alpha[j+2]+beta[j+2]))
			  *(0.125*(-I)*cexp(M_PI*I/2.0*(yppp*(delta[j+3]+delta[j+4])+pow(yppp+1,2)*(delta[j+3]+gamma[j+4]+2*beta[j+4])+pow(xppp,2)+2*(beta[j+3]+beta[j+4]+delta[j+3]+gamma[j+4]*(yppp+1)+delta[j+4]*yppp)*xppp))*Gausssum1d(0,xppp+beta[j+3]+beta[j+4]+delta[j+3]+gamma[j+4]*(yppp+1)+delta[j+4]*yppp+gamma[j+5]+delta[j+5])*Kroneck(gamma[j+3]+delta[j+3]-gamma[j+4]-delta[j+4]+1)*Kroneck(alpha[j+5]+beta[j+5])));
		    }
		  }
		}
	      }

	      for(ypp=0; ypp<=(1+alpha[j+2])%2; ypp++) {
		for(xpp=0; xpp<=(1+beta[j+2])%2; xpp++) {
		  for(yppp=0; yppp<=1; yppp++) {
		    //**for(xppp=0;xppp<=(yppp*(gamma[j+3]+gamma[j+4])+(yppp+1)*(gamma[j+3]+delta[j+4]))%2; xppp++) {
		    for(xppp=yppp*(beta[j+3]+alpha[j+4]+beta[j+4])%2;xppp<=(yppp*(beta[j+3]+alpha[j+4]+beta[j+4])+yppp*(gamma[j+3]+gamma[j+4])+(yppp+1)*(gamma[j+3]+delta[j+4]))%2; xppp++) {
		      summand += ((0.125*2.0*csqrt(-I)*cexp(M_PI*I/2.0*(2.0*beta[i+2]*y+pow(x+1,2)*(delta[i]+gamma[i+1]+2.0*beta[i+1])+x*(delta[i]+delta[i+1])))*Gausssum1d(1,beta[i]+beta[i+1]+delta[i]+(x+1)*gamma[i+1]+x*delta[i+1])*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1]+1)*Kroneck(gamma[i+2]+delta[i+2]))
		*(0.125*pow(2.0,1-yp*pow(gamma[i+3]-gamma[i+4],2)-pow(yp-1,2)*pow(gamma[i+3]-delta[i+4],2))*cexp(M_PI*I/2.0*((delta[i+4]-gamma[i+3])*pow(yp+1,2)+2.0*(beta[i+3]+beta[i+4]+gamma[i+3]+delta[i+4])*xp*pow(yp+1,2)+2.0*(delta[i+3]+delta[i+4]+beta[i+3]+beta[i+4])*xp*yp+(2.0*beta[i+3]+3.0*delta[i+3]+delta[i+4])*yp))*Gausssum1d(0.0,beta[i+5])*Kroneck(gamma[i+3]+delta[i+3]-gamma[i+4]-delta[i+4])*Kroneck(gamma[i+5]+delta[i+5]) 
		  + 0.125*pow(2.0,1-yp*pow(gamma[i+3]-gamma[i+4],2)-pow(yp-1,2)*pow(gamma[i+3]-delta[i+4],2))*cexp(M_PI*I/2.0*((delta[i+4]-gamma[i+3])*pow(yp+1,2)+2.0*(beta[i+3]+beta[i+4]+gamma[i+3]+delta[i+4])*xp*pow(yp+1,2)+2.0*(delta[i+3]+delta[i+4]+beta[i+3]+beta[i+4])*xp*yp+(2.0*beta[i+3]+3.0*delta[i+3]+delta[i+4])*yp))*csqrt(-I)*Gausssum1d(gamma[i+5]+delta[i+5],0)*Kroneck(gamma[i+3]+delta[i+3]-gamma[i+4]-delta[i+4])*Kroneck(alpha[i+5]+beta[i+5])))
			*((0.125*2.0*csqrt(-I)*cexp(M_PI*I/2.0*(2.0*beta[j+2]*ypp+pow(xpp+1,2)*(delta[j]+gamma[j+1]+2.0*beta[j+1])+xpp*(delta[j]+delta[j+1])))*Gausssum1d(1,beta[j]+beta[j+1]+delta[j]+(xpp+1)*gamma[j+1]+xpp*delta[j+1])*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1]+1)*Kroneck(gamma[j+2]+delta[j+2]))
			  *(0.125*pow(2.0,1-yppp*pow(gamma[j+3]-gamma[j+4],2)-pow(yppp-1,2)*pow(gamma[j+3]-delta[j+4],2))*cexp(M_PI*I/2.0*((delta[j+4]-gamma[j+3])*pow(yppp+1,2)+2.0*(beta[j+3]+beta[j+4]+gamma[j+3]+delta[j+4])*xppp*pow(yppp+1,2)+2.0*(delta[j+3]+delta[j+4]+beta[j+3]+beta[j+4])*xppp*yppp+(2.0*beta[j+3]+3.0*delta[j+3]+delta[j+4])*yppp))*Gausssum1d(0.0,beta[j+5])*Kroneck(gamma[j+3]+delta[j+3]-gamma[j+4]-delta[j+4])*Kroneck(gamma[j+5]+delta[j+5]) 
			    + 0.125*pow(2.0,1-yppp*pow(gamma[j+3]-gamma[j+4],2)-pow(yppp-1,2)*pow(gamma[j+3]-delta[j+4],2))*cexp(M_PI*I/2.0*((delta[j+4]-gamma[j+3])*pow(yppp+1,2)+2.0*(beta[j+3]+beta[j+4]+gamma[j+3]+delta[j+4])*xppp*pow(yppp+1,2)+2.0*(delta[j+3]+delta[j+4]+beta[j+3]+beta[j+4])*xppp*yppp+(2.0*beta[j+3]+3.0*delta[j+3]+delta[j+4])*yppp))*csqrt(-I)*Gausssum1d(gamma[j+5]+delta[j+5],0)*Kroneck(gamma[j+3]+delta[j+3]-gamma[j+4]-delta[j+4])*Kroneck(alpha[j+5]+beta[j+5])));
		    }
		  }
		  for(yppp=0; yppp<=(1+alpha[j+5])%2; yppp++) {
		    for(xppp=0;xppp<=(1+beta[j+5])%2; xppp++) {
		      summand += ((0.125*2.0*csqrt(-I)*cexp(M_PI*I/2.0*(2.0*beta[i+2]*y+pow(x+1,2)*(delta[i]+gamma[i+1]+2.0*beta[i+1])+x*(delta[i]+delta[i+1])))*Gausssum1d(1,beta[i]+beta[i+1]+delta[i]+(x+1)*gamma[i+1]+x*delta[i+1])*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1]+1)*Kroneck(gamma[i+2]+delta[i+2]))
		*(0.125*pow(2.0,1-yp*pow(gamma[i+3]-gamma[i+4],2)-pow(yp-1,2)*pow(gamma[i+3]-delta[i+4],2))*cexp(M_PI*I/2.0*((delta[i+4]-gamma[i+3])*pow(yp+1,2)+2.0*(beta[i+3]+beta[i+4]+gamma[i+3]+delta[i+4])*xp*pow(yp+1,2)+2.0*(delta[i+3]+delta[i+4]+beta[i+3]+beta[i+4])*xp*yp+(2.0*beta[i+3]+3.0*delta[i+3]+delta[i+4])*yp))*Gausssum1d(0.0,beta[i+5])*Kroneck(gamma[i+3]+delta[i+3]-gamma[i+4]-delta[i+4])*Kroneck(gamma[i+5]+delta[i+5]) 
		  + 0.125*pow(2.0,1-yp*pow(gamma[i+3]-gamma[i+4],2)-pow(yp-1,2)*pow(gamma[i+3]-delta[i+4],2))*cexp(M_PI*I/2.0*((delta[i+4]-gamma[i+3])*pow(yp+1,2)+2.0*(beta[i+3]+beta[i+4]+gamma[i+3]+delta[i+4])*xp*pow(yp+1,2)+2.0*(delta[i+3]+delta[i+4]+beta[i+3]+beta[i+4])*xp*yp+(2.0*beta[i+3]+3.0*delta[i+3]+delta[i+4])*yp))*csqrt(-I)*Gausssum1d(gamma[i+5]+delta[i+5],0)*Kroneck(gamma[i+3]+delta[i+3]-gamma[i+4]-delta[i+4])*Kroneck(alpha[i+5]+beta[i+5])))
			*((0.125*2.0*csqrt(-I)*cexp(M_PI*I/2.0*(2.0*beta[j+2]*ypp+pow(xpp+1,2)*(delta[j]+gamma[j+1]+2.0*beta[j+1])+xpp*(delta[j]+delta[j+1])))*Gausssum1d(1,beta[j]+beta[j+1]+delta[j]+(xpp+1)*gamma[j+1]+xpp*delta[j+1])*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1]+1)*Kroneck(gamma[j+2]+delta[j+2]))
			  *(0.125*2.0*csqrt(-I)*cexp(M_PI*I/2.0*(2.0*beta[j+5]*yppp+pow(xppp+1,2)*(delta[j+3]+gamma[j+4]+2.0*beta[j+4])+xppp*(delta[j+3]+delta[j+4])))*Gausssum1d(1,beta[j+3]+beta[j+4]+delta[j+3]+(xppp+1)*gamma[j+4]+xppp*delta[j+4])*Kroneck(gamma[j+3]+delta[j+3]-gamma[j+4]-delta[j+4]+1)*Kroneck(gamma[j+5]+delta[j+5])));
		    }
		  }
		  for(yppp=0; yppp<=1; yppp++) {
		    for(xppp=(yppp*(delta[j+3]+delta[j+4]))%2;xppp<=(1+yppp*(gamma[j+3]+gamma[j+4]))%2; xppp++) {
		      summand += ((0.125*2.0*csqrt(-I)*cexp(M_PI*I/2.0*(2.0*beta[i+2]*y+pow(x+1,2)*(delta[i]+gamma[i+1]+2.0*beta[i+1])+x*(delta[i]+delta[i+1])))*Gausssum1d(1,beta[i]+beta[i+1]+delta[i]+(x+1)*gamma[i+1]+x*delta[i+1])*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1]+1)*Kroneck(gamma[i+2]+delta[i+2]))
		*(0.125*pow(2.0,1-yp*pow(gamma[i+3]-gamma[i+4],2)-pow(yp-1,2)*pow(gamma[i+3]-delta[i+4],2))*cexp(M_PI*I/2.0*((delta[i+4]-gamma[i+3])*pow(yp+1,2)+2.0*(beta[i+3]+beta[i+4]+gamma[i+3]+delta[i+4])*xp*pow(yp+1,2)+2.0*(delta[i+3]+delta[i+4]+beta[i+3]+beta[i+4])*xp*yp+(2.0*beta[i+3]+3.0*delta[i+3]+delta[i+4])*yp))*Gausssum1d(0.0,beta[i+5])*Kroneck(gamma[i+3]+delta[i+3]-gamma[i+4]-delta[i+4])*Kroneck(gamma[i+5]+delta[i+5]) 
		  + 0.125*pow(2.0,1-yp*pow(gamma[i+3]-gamma[i+4],2)-pow(yp-1,2)*pow(gamma[i+3]-delta[i+4],2))*cexp(M_PI*I/2.0*((delta[i+4]-gamma[i+3])*pow(yp+1,2)+2.0*(beta[i+3]+beta[i+4]+gamma[i+3]+delta[i+4])*xp*pow(yp+1,2)+2.0*(delta[i+3]+delta[i+4]+beta[i+3]+beta[i+4])*xp*yp+(2.0*beta[i+3]+3.0*delta[i+3]+delta[i+4])*yp))*csqrt(-I)*Gausssum1d(gamma[i+5]+delta[i+5],0)*Kroneck(gamma[i+3]+delta[i+3]-gamma[i+4]-delta[i+4])*Kroneck(alpha[i+5]+beta[i+5])))
			*((0.125*2.0*csqrt(-I)*cexp(M_PI*I/2.0*(2.0*beta[j+2]*ypp+pow(xpp+1,2)*(delta[j]+gamma[j+1]+2.0*beta[j+1])+xpp*(delta[j]+delta[j+1])))*Gausssum1d(1,beta[j]+beta[j+1]+delta[j]+(xpp+1)*gamma[j+1]+xpp*delta[j+1])*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1]+1)*Kroneck(gamma[j+2]+delta[j+2]))
			  *(0.125*(-I)*pow(2.0,(pow(yppp-1,2)*(pow(xppp,2)*(gamma[j+3]+delta[j+4])+pow(xppp-1,2)*(gamma[j+4]+delta[j+3]))))*cexp(M_PI*I/2.0*(yppp*(delta[j+3]+delta[j+4])+pow(yppp+1,2)*(delta[j+3]+gamma[j+4]+2*beta[j+4])+pow(xppp,2)+2*(beta[j+3]+beta[j+4]+delta[j+3]+gamma[j+4]*(yppp+1)+delta[j+4]*yppp)*xppp))*Gausssum1d(0,xppp+beta[j+3]+beta[j+4]+delta[j+3]+gamma[j+4]*(yppp+1)+delta[j+4]*yppp+gamma[j+5]+delta[j+5])*Kroneck(gamma[j+3]+delta[j+3]-gamma[j+4]-delta[j+4]+1)*Kroneck(alpha[j+5]+beta[j+5])));
		    }
		  }
		}
	      }
	      
	      for(ypp=0; ypp<=1; ypp++) {
		for(xpp=(ypp*(delta[j]+delta[j+1]))%2; xpp<=(1+ypp*(gamma[j]+gamma[j+1]))%2; xpp++) {
		  for(yppp=((gamma[j+3]+delta[j+4])*ypp)%2; yppp<=(1+(gamma[j+3]+gamma[j+4])*ypp)%2; yppp++) {
		    //**for(xppp=0;xppp<=(yppp*(gamma[j+3]+gamma[j+4])+(yppp+1)*(gamma[j+3]+delta[j+4]))%2; xppp++) {
		    for(xppp=yppp*(beta[j+3]+alpha[j+4]+beta[j+4])%2;xppp<=(yppp*(beta[j+3]+alpha[j+4]+beta[j+4])+yppp*(gamma[j+3]+gamma[j+4])+(yppp+1)*(gamma[j+3]+delta[j+4]))%2; xppp++) {
		      summand += ((0.125*2.0*csqrt(-I)*cexp(M_PI*I/2.0*(2.0*beta[i+2]*y+pow(x+1,2)*(delta[i]+gamma[i+1]+2.0*beta[i+1])+x*(delta[i]+delta[i+1])))*Gausssum1d(1,beta[i]+beta[i+1]+delta[i]+(x+1)*gamma[i+1]+x*delta[i+1])*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1]+1)*Kroneck(gamma[i+2]+delta[i+2]))
		*(0.125*pow(2.0,1-yp*pow(gamma[i+3]-gamma[i+4],2)-pow(yp-1,2)*pow(gamma[i+3]-delta[i+4],2))*cexp(M_PI*I/2.0*((delta[i+4]-gamma[i+3])*pow(yp+1,2)+2.0*(beta[i+3]+beta[i+4]+gamma[i+3]+delta[i+4])*xp*pow(yp+1,2)+2.0*(delta[i+3]+delta[i+4]+beta[i+3]+beta[i+4])*xp*yp+(2.0*beta[i+3]+3.0*delta[i+3]+delta[i+4])*yp))*Gausssum1d(0.0,beta[i+5])*Kroneck(gamma[i+3]+delta[i+3]-gamma[i+4]-delta[i+4])*Kroneck(gamma[i+5]+delta[i+5]) 
		  + 0.125*pow(2.0,1-yp*pow(gamma[i+3]-gamma[i+4],2)-pow(yp-1,2)*pow(gamma[i+3]-delta[i+4],2))*cexp(M_PI*I/2.0*((delta[i+4]-gamma[i+3])*pow(yp+1,2)+2.0*(beta[i+3]+beta[i+4]+gamma[i+3]+delta[i+4])*xp*pow(yp+1,2)+2.0*(delta[i+3]+delta[i+4]+beta[i+3]+beta[i+4])*xp*yp+(2.0*beta[i+3]+3.0*delta[i+3]+delta[i+4])*yp))*csqrt(-I)*Gausssum1d(gamma[i+5]+delta[i+5],0)*Kroneck(gamma[i+3]+delta[i+3]-gamma[i+4]-delta[i+4])*Kroneck(alpha[i+5]+beta[i+5])))
			*(2.0*(0.125*pow(2.0,(pow(ypp-1,2)*(pow(xpp,2)*(gamma[j]+delta[j+1])+pow(xpp-1,2)*(gamma[j+1]+delta[j])))*(1-yppp*pow(gamma[j+3]-gamma[j+4],2)-pow(yppp-1,2)*pow(gamma[j+3]-delta[j+4],2)))*(-I)*cexp(M_PI*I/2.0*(ypp*(delta[j]+delta[j+1])+pow(ypp+1,2)*(delta[j]+gamma[j+1]+2*beta[j+1])+pow(xpp,2)+2*(beta[j]+beta[j+1]+delta[j]+gamma[j+1]*(ypp+1)+delta[j+1]*ypp)*xpp))*Gausssum1d(0,xpp+beta[j]+beta[j+1]+delta[j]+gamma[j+1]*(ypp+1)+delta[j+1]*ypp+gamma[j+2]+delta[j+2])*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1]+1)*Kroneck(alpha[j+2]+beta[j+2]))
			  *(0.125*cexp(M_PI*I/2.0*((delta[j+4]-gamma[j+3])*pow(yppp+1,2)+2.0*(beta[j+3]+beta[j+4]+gamma[j+3]+delta[j+4])*xppp*pow(yppp+1,2)+2.0*(delta[j+3]+delta[j+4]+beta[j+3]+beta[j+4])*xppp*yppp+(2.0*beta[j+3]+3.0*delta[j+3]+delta[j+4])*yppp))*Gausssum1d(0.0,beta[j+5])*Kroneck(gamma[j+3]+delta[j+3]-gamma[j+4]-delta[j+4])*Kroneck(gamma[j+5]+delta[j+5]) 
			    + 0.125*cexp(M_PI*I/2.0*((delta[j+4]-gamma[j+3])*pow(yppp+1,2)+2.0*(beta[j+3]+beta[j+4]+gamma[j+3]+delta[j+4])*xppp*pow(yppp+1,2)+2.0*(delta[j+3]+delta[j+4]+beta[j+3]+beta[j+4])*xppp*yppp+(2.0*beta[j+3]+3.0*delta[j+3]+delta[j+4])*yppp))*csqrt(-I)*Gausssum1d(gamma[j+5]+delta[j+5],0)*Kroneck(gamma[j+3]+delta[j+3]-gamma[j+4]-delta[j+4])*Kroneck(alpha[j+5]+beta[j+5])));
		    }
		  }
		  for(yppp=0; yppp<=(1+alpha[j+5])%2; yppp++) {
		    for(xppp=0;xppp<=(1+beta[j+5])%2; xppp++) {
		      summand += ((0.125*2.0*csqrt(-I)*cexp(M_PI*I/2.0*(2.0*beta[i+2]*y+pow(x+1,2)*(delta[i]+gamma[i+1]+2.0*beta[i+1])+x*(delta[i]+delta[i+1])))*Gausssum1d(1,beta[i]+beta[i+1]+delta[i]+(x+1)*gamma[i+1]+x*delta[i+1])*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1]+1)*Kroneck(gamma[i+2]+delta[i+2]))
		*(0.125*pow(2.0,1-yp*pow(gamma[i+3]-gamma[i+4],2)-pow(yp-1,2)*pow(gamma[i+3]-delta[i+4],2))*cexp(M_PI*I/2.0*((delta[i+4]-gamma[i+3])*pow(yp+1,2)+2.0*(beta[i+3]+beta[i+4]+gamma[i+3]+delta[i+4])*xp*pow(yp+1,2)+2.0*(delta[i+3]+delta[i+4]+beta[i+3]+beta[i+4])*xp*yp+(2.0*beta[i+3]+3.0*delta[i+3]+delta[i+4])*yp))*Gausssum1d(0.0,beta[i+5])*Kroneck(gamma[i+3]+delta[i+3]-gamma[i+4]-delta[i+4])*Kroneck(gamma[i+5]+delta[i+5]) 
		  + 0.125*pow(2.0,1-yp*pow(gamma[i+3]-gamma[i+4],2)-pow(yp-1,2)*pow(gamma[i+3]-delta[i+4],2))*cexp(M_PI*I/2.0*((delta[i+4]-gamma[i+3])*pow(yp+1,2)+2.0*(beta[i+3]+beta[i+4]+gamma[i+3]+delta[i+4])*xp*pow(yp+1,2)+2.0*(delta[i+3]+delta[i+4]+beta[i+3]+beta[i+4])*xp*yp+(2.0*beta[i+3]+3.0*delta[i+3]+delta[i+4])*yp))*csqrt(-I)*Gausssum1d(gamma[i+5]+delta[i+5],0)*Kroneck(gamma[i+3]+delta[i+3]-gamma[i+4]-delta[i+4])*Kroneck(alpha[i+5]+beta[i+5])))
			*((0.125*pow(2.0,pow(ypp-1,2)*(pow(xpp,2)*(gamma[j]+delta[j+1])+pow(xpp-1,2)*(gamma[j+1]+delta[j])))*(-I)*cexp(M_PI*I/2.0*(ypp*(delta[j]+delta[j+1])+pow(ypp+1,2)*(delta[j]+gamma[j+1]+2*beta[j+1])+pow(xpp,2)+2*(beta[j]+beta[j+1]+delta[j]+gamma[j+1]*(ypp+1)+delta[j+1]*ypp)*xpp))*Gausssum1d(0,xpp+beta[j]+beta[j+1]+delta[j]+gamma[j+1]*(ypp+1)+delta[j+1]*ypp+gamma[j+2]+delta[j+2])*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1]+1)*Kroneck(alpha[j+2]+beta[j+2]))
			  *(0.125*2.0*csqrt(-I)*cexp(M_PI*I/2.0*(2.0*beta[j+5]*yppp+pow(xppp+1,2)*(delta[j+3]+gamma[j+4]+2.0*beta[j+4])+xppp*(delta[j+3]+delta[j+4])))*Gausssum1d(1,beta[j+3]+beta[j+4]+delta[j+3]+(xppp+1)*gamma[j+4]+xppp*delta[j+4])*Kroneck(gamma[j+3]+delta[j+3]-gamma[j+4]-delta[j+4]+1)*Kroneck(gamma[j+5]+delta[j+5])));
		    }
		  }
		  for(yppp=ypp; yppp<=1; yppp++) {
		    for(xppp=(yppp*(delta[j+3]+delta[j+4])+ypp)%2;xppp<=(1+yppp*(gamma[j+3]+gamma[j+4])+ypp)%2; xppp++) {
		      summand += ((0.125*2.0*csqrt(-I)*cexp(M_PI*I/2.0*(2.0*beta[i+2]*y+pow(x+1,2)*(delta[i]+gamma[i+1]+2.0*beta[i+1])+x*(delta[i]+delta[i+1])))*Gausssum1d(1,beta[i]+beta[i+1]+delta[i]+(x+1)*gamma[i+1]+x*delta[i+1])*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1]+1)*Kroneck(gamma[i+2]+delta[i+2]))
		*(0.125*pow(2.0,1-yp*pow(gamma[i+3]-gamma[i+4],2)-pow(yp-1,2)*pow(gamma[i+3]-delta[i+4],2))*cexp(M_PI*I/2.0*((delta[i+4]-gamma[i+3])*pow(yp+1,2)+2.0*(beta[i+3]+beta[i+4]+gamma[i+3]+delta[i+4])*xp*pow(yp+1,2)+2.0*(delta[i+3]+delta[i+4]+beta[i+3]+beta[i+4])*xp*yp+(2.0*beta[i+3]+3.0*delta[i+3]+delta[i+4])*yp))*Gausssum1d(0.0,beta[i+5])*Kroneck(gamma[i+3]+delta[i+3]-gamma[i+4]-delta[i+4])*Kroneck(gamma[i+5]+delta[i+5]) 
		  + 0.125*pow(2.0,1-yp*pow(gamma[i+3]-gamma[i+4],2)-pow(yp-1,2)*pow(gamma[i+3]-delta[i+4],2))*cexp(M_PI*I/2.0*((delta[i+4]-gamma[i+3])*pow(yp+1,2)+2.0*(beta[i+3]+beta[i+4]+gamma[i+3]+delta[i+4])*xp*pow(yp+1,2)+2.0*(delta[i+3]+delta[i+4]+beta[i+3]+beta[i+4])*xp*yp+(2.0*beta[i+3]+3.0*delta[i+3]+delta[i+4])*yp))*csqrt(-I)*Gausssum1d(gamma[i+5]+delta[i+5],0)*Kroneck(gamma[i+3]+delta[i+3]-gamma[i+4]-delta[i+4])*Kroneck(alpha[i+5]+beta[i+5])))
			*(2.0*(0.125*pow(2.0,(pow(ypp-1,2)*(pow(xpp,2)*(gamma[j]+delta[j+1])+pow(xpp-1,2)*(gamma[j+1]+delta[j])))*(pow(yppp-1,2)*(pow(xppp,2)*(gamma[j+3]+delta[j+4])+pow(xppp-1,2)*(gamma[j+4]+delta[j+3]))))*(-I)*cexp(M_PI*I/2.0*(ypp*(delta[j]+delta[j+1])+pow(ypp+1,2)*(delta[j]+gamma[j+1]+2*beta[j+1])+pow(xpp,2)+2*(beta[j]+beta[j+1]+delta[j]+gamma[j+1]*(ypp+1)+delta[j+1]*ypp)*xpp))*Gausssum1d(0,xpp+beta[j]+beta[j+1]+delta[j]+gamma[j+1]*(ypp+1)+delta[j+1]*ypp+gamma[j+2]+delta[j+2])*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1]+1)*Kroneck(alpha[j+2]+beta[j+2]))
			  *(0.125*(-I)*cexp(M_PI*I/2.0*(yppp*(delta[j+3]+delta[j+4])+pow(yppp+1,2)*(delta[j+3]+gamma[j+4]+2*beta[j+4])+pow(xppp,2)+2*(beta[j+3]+beta[j+4]+delta[j+3]+gamma[j+4]*(yppp+1)+delta[j+4]*yppp)*xppp))*Gausssum1d(0,xppp+beta[j+3]+beta[j+4]+delta[j+3]+gamma[j+4]*(yppp+1)+delta[j+4]*yppp+gamma[j+5]+delta[j+5])*Kroneck(gamma[j+3]+delta[j+3]-gamma[j+4]-delta[j+4]+1)*Kroneck(alpha[j+5]+beta[j+5])));
		    }
		  }
		}
	      }
	    }
	  }
	}
      }


      // fifth term
      for(y=0; y<=(1+alpha[i+2])%2; y++) {
	for(x=0; x<=(1+beta[i+2])%2; x++) {
	  for(yp=0; yp<=(1+alpha[i+5])%2; yp++) {
	    for(xp=0;xp<=(1+beta[i+5])%2; xp++) {
	      for(ypp=0; ypp<=1; ypp++) {
		//**for(xpp=0;xpp<=(ypp*(gamma[j]+gamma[j+1])+(ypp+1)*(gamma[j]+delta[j+1]))%2; xpp++) {
		for(xpp=ypp*(beta[j]+alpha[j+1]+beta[j+1])%2;xpp<=(ypp*(beta[j]+alpha[j+1]+beta[j+1])+ypp*(gamma[j]+gamma[j+1])+(ypp+1)*(gamma[j]+delta[j+1]))%2; xpp++) {
		  for(yppp=((gamma[j+3]+delta[j+4])*xpp)%2; yppp<=(1+(gamma[j+3]+gamma[j+4])*xpp)%2; yppp++) {
		    //**for(xppp=0;xppp<=(yppp*(gamma[j+3]+gamma[j+4])+(yppp+1)*(gamma[j+3]+delta[j+4]))%2; xppp++) {
		    for(xppp=yppp*(beta[j+3]+alpha[j+4]+beta[j+4])%2;xppp<=(yppp*(beta[j+3]+alpha[j+4]+beta[j+4])+yppp*(gamma[j+3]+gamma[j+4])+(yppp+1)*(gamma[j+3]+delta[j+4]))%2; xppp++) {
		      summand += ((0.125*2.0*csqrt(-I)*cexp(M_PI*I/2.0*(2.0*beta[i+2]*y+pow(x+1,2)*(delta[i]+gamma[i+1]+2.0*beta[i+1])+x*(delta[i]+delta[i+1])))*Gausssum1d(1,beta[i]+beta[i+1]+delta[i]+(x+1)*gamma[i+1]+x*delta[i+1])*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1]+1)*Kroneck(gamma[i+2]+delta[i+2]))
				  *(0.125*2.0*csqrt(-I)*cexp(M_PI*I/2.0*(2.0*beta[i+5]*yp+pow(xp+1,2)*(delta[i+3]+gamma[i+4]+2.0*beta[i+4])+xp*(delta[i+3]+delta[i+4])))*Gausssum1d(1,beta[i+3]+beta[i+4]+delta[i+3]+(xp+1)*gamma[i+4]+xp*delta[i+4])*Kroneck(gamma[i+3]+delta[i+3]-gamma[i+4]-delta[i+4]+1)*Kroneck(gamma[i+5]+delta[i+5])))
			*(2.0*(0.125*pow(2.0,(1-ypp*pow(gamma[j]-gamma[j+1],2)-pow(ypp-1,2)*pow(gamma[j]-delta[j+1],2))*(1-yppp*pow(gamma[j+3]-gamma[j+4],2)-pow(yppp-1,2)*pow(gamma[j+3]-delta[j+4],2)))*cexp(M_PI*I/2.0*((delta[j+1]-gamma[j])*pow(ypp+1,2)+2.0*(beta[j]+beta[j+1]+gamma[j]+delta[j+1])*xpp*pow(ypp+1,2)+2.0*(delta[j]+delta[j+1]+beta[j]+beta[j+1])*xpp*ypp+(2.0*beta[j]+3.0*delta[j]+delta[j+1])*ypp))*Gausssum1d(0.0,beta[j+2])*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1])*Kroneck(gamma[j+2]+delta[j+2]) 
			      + 0.125*pow(2.0,(1-ypp*pow(gamma[j]-gamma[j+1],2)-pow(ypp-1,2)*pow(gamma[j]-delta[j+1],2))*(1-yppp*pow(gamma[j+3]-gamma[j+4],2)-pow(yppp-1,2)*pow(gamma[j+3]-delta[j+4],2)))*cexp(M_PI*I/2.0*((delta[j+1]-gamma[j])*pow(ypp+1,2)+2.0*(beta[j]+beta[j+1]+gamma[j]+delta[j+1])*xpp*pow(ypp+1,2)+2.0*(delta[j]+delta[j+1]+beta[j]+beta[j+1])*xpp*ypp+(2.0*beta[j]+3.0*delta[j]+delta[j+1])*ypp))*csqrt(-I)*Gausssum1d(gamma[j+2]+delta[j+2],0)*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1])*Kroneck(alpha[j+2]+beta[j+2]))
			*(0.125*cexp(M_PI*I/2.0*((delta[j+4]-gamma[j+3])*pow(yppp+1,2)+2.0*(beta[j+3]+beta[j+4]+gamma[j+3]+delta[j+4])*xppp*pow(yppp+1,2)+2.0*(delta[j+3]+delta[j+4]+beta[j+3]+beta[j+4])*xppp*yppp+(2.0*beta[j+3]+3.0*delta[j+3]+delta[j+4])*yppp))*Gausssum1d(0.0,beta[j+5])*Kroneck(gamma[j+3]+delta[j+3]-gamma[j+4]-delta[j+4])*Kroneck(gamma[j+5]+delta[j+5]) 
			  + 0.125*cexp(M_PI*I/2.0*((delta[j+4]-gamma[j+3])*pow(yppp+1,2)+2.0*(beta[j+3]+beta[j+4]+gamma[j+3]+delta[j+4])*xppp*pow(yppp+1,2)+2.0*(delta[j+3]+delta[j+4]+beta[j+3]+beta[j+4])*xppp*yppp+(2.0*beta[j+3]+3.0*delta[j+3]+delta[j+4])*yppp))*csqrt(-I)*Gausssum1d(gamma[j+5]+delta[j+5],0)*Kroneck(gamma[j+3]+delta[j+3]-gamma[j+4]-delta[j+4])*Kroneck(alpha[j+5]+beta[j+5])));
		    }
		  }
		  for(yppp=0; yppp<=(1+alpha[j+5])%2; yppp++) {
		    for(xppp=0;xppp<=(1+beta[j+5])%2; xppp++) {
		      summand += ((0.125*2.0*csqrt(-I)*cexp(M_PI*I/2.0*(2.0*beta[i+2]*y+pow(x+1,2)*(delta[i]+gamma[i+1]+2.0*beta[i+1])+x*(delta[i]+delta[i+1])))*Gausssum1d(1,beta[i]+beta[i+1]+delta[i]+(x+1)*gamma[i+1]+x*delta[i+1])*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1]+1)*Kroneck(gamma[i+2]+delta[i+2]))
				  *(0.125*2.0*csqrt(-I)*cexp(M_PI*I/2.0*(2.0*beta[i+5]*yp+pow(xp+1,2)*(delta[i+3]+gamma[i+4]+2.0*beta[i+4])+xp*(delta[i+3]+delta[i+4])))*Gausssum1d(1,beta[i+3]+beta[i+4]+delta[i+3]+(xp+1)*gamma[i+4]+xp*delta[i+4])*Kroneck(gamma[i+3]+delta[i+3]-gamma[i+4]-delta[i+4]+1)*Kroneck(gamma[i+5]+delta[i+5])))
			*((0.125*pow(2.0,1-ypp*pow(gamma[j]-gamma[j+1],2)-pow(ypp-1,2)*pow(gamma[j]-delta[j+1],2))*cexp(M_PI*I/2.0*((delta[j+1]-gamma[j])*pow(ypp+1,2)+2.0*(beta[j]+beta[j+1]+gamma[j]+delta[j+1])*xpp*pow(ypp+1,2)+2.0*(delta[j]+delta[j+1]+beta[j]+beta[j+1])*xpp*ypp+(2.0*beta[j]+3.0*delta[j]+delta[j+1])*ypp))*Gausssum1d(0.0,beta[j+2])*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1])*Kroneck(gamma[j+2]+delta[j+2]) 
				  + 0.125*pow(2.0,1-ypp*pow(gamma[j]-gamma[j+1],2)-pow(ypp-1,2)*pow(gamma[j]-delta[j+1],2))*cexp(M_PI*I/2.0*((delta[j+1]-gamma[j])*pow(ypp+1,2)+2.0*(beta[j]+beta[j+1]+gamma[j]+delta[j+1])*xpp*pow(ypp+1,2)+2.0*(delta[j]+delta[j+1]+beta[j]+beta[j+1])*xpp*ypp+(2.0*beta[j]+3.0*delta[j]+delta[j+1])*ypp))*csqrt(-I)*Gausssum1d(gamma[j+2]+delta[j+2],0)*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1])*Kroneck(alpha[j+2]+beta[j+2]))
			  *(0.125*2.0*csqrt(-I)*cexp(M_PI*I/2.0*(2.0*beta[j+5]*yppp+pow(xppp+1,2)*(delta[j+3]+gamma[j+4]+2.0*beta[j+4])+xppp*(delta[j+3]+delta[j+4])))*Gausssum1d(1,beta[j+3]+beta[j+4]+delta[j+3]+(xppp+1)*gamma[j+4]+xppp*delta[j+4])*Kroneck(gamma[j+3]+delta[j+3]-gamma[j+4]-delta[j+4]+1)*Kroneck(gamma[j+5]+delta[j+5])));
		    }
		  }
		  //**for(yppp=xpp; yppp<=1; yppp++) {
		  for(yppp=xpp*(1+alpha[j]+beta[j])%2; yppp<=1; yppp++) {
		    //**for(xppp=(yppp*(delta[j+3]+delta[j+4])+xpp)%2;xppp<=(1+yppp*(gamma[j+3]+gamma[j+4])+xpp)%2; xppp++) {
		    for(xppp=(yppp*(delta[j+3]+delta[j+4])+xpp*(1+alpha[j]+beta[j]))%2;xppp<=(1+yppp*(gamma[j+3]+gamma[j+4])+xpp*(1+alpha[j]+beta[j]))%2; xppp++) {
		      summand += ((0.125*2.0*csqrt(-I)*cexp(M_PI*I/2.0*(2.0*beta[i+2]*y+pow(x+1,2)*(delta[i]+gamma[i+1]+2.0*beta[i+1])+x*(delta[i]+delta[i+1])))*Gausssum1d(1,beta[i]+beta[i+1]+delta[i]+(x+1)*gamma[i+1]+x*delta[i+1])*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1]+1)*Kroneck(gamma[i+2]+delta[i+2]))
				  *(0.125*2.0*csqrt(-I)*cexp(M_PI*I/2.0*(2.0*beta[i+5]*yp+pow(xp+1,2)*(delta[i+3]+gamma[i+4]+2.0*beta[i+4])+xp*(delta[i+3]+delta[i+4])))*Gausssum1d(1,beta[i+3]+beta[i+4]+delta[i+3]+(xp+1)*gamma[i+4]+xp*delta[i+4])*Kroneck(gamma[i+3]+delta[i+3]-gamma[i+4]-delta[i+4]+1)*Kroneck(gamma[i+5]+delta[i+5])))
			*(2.0*(0.125*pow(2.0,(1-ypp*pow(gamma[j]-gamma[j+1],2)-pow(ypp-1,2)*pow(gamma[j]-delta[j+1],2))*(pow(yppp-1,2)*(pow(xppp,2)*(gamma[j+3]+delta[j+4])+pow(xppp-1,2)*(gamma[j+4]+delta[j+3]))))*cexp(M_PI*I/2.0*((delta[j+1]-gamma[j])*pow(ypp+1,2)+2.0*(beta[j]+beta[j+1]+gamma[j]+delta[j+1])*xpp*pow(ypp+1,2)+2.0*(delta[j]+delta[j+1]+beta[j]+beta[j+1])*xpp*ypp+(2.0*beta[j]+3.0*delta[j]+delta[j+1])*ypp))*Gausssum1d(0.0,beta[j+2])*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1])*Kroneck(gamma[j+2]+delta[j+2]) 
				      + 0.125*pow(2.0,(1-ypp*pow(gamma[j]-gamma[j+1],2)-pow(ypp-1,2)*pow(gamma[j]-delta[j+1],2))*(pow(yppp-1,2)*(pow(xppp,2)*(gamma[j+3]+delta[j+4])+pow(xppp-1,2)*(gamma[j+4]+delta[j+3]))))*cexp(M_PI*I/2.0*((delta[j+1]-gamma[j])*pow(ypp+1,2)+2.0*(beta[j]+beta[j+1]+gamma[j]+delta[j+1])*xpp*pow(ypp+1,2)+2.0*(delta[j]+delta[j+1]+beta[j]+beta[j+1])*xpp*ypp+(2.0*beta[j]+3.0*delta[j]+delta[j+1])*ypp))*csqrt(-I)*Gausssum1d(gamma[j+2]+delta[j+2],0)*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1])*Kroneck(alpha[j+2]+beta[j+2]))
			  *(0.125*(-I)*cexp(M_PI*I/2.0*(yppp*(delta[j+3]+delta[j+4])+pow(yppp+1,2)*(delta[j+3]+gamma[j+4]+2*beta[j+4])+pow(xppp,2)+2*(beta[j+3]+beta[j+4]+delta[j+3]+gamma[j+4]*(yppp+1)+delta[j+4]*yppp)*xppp))*Gausssum1d(0,xppp+beta[j+3]+beta[j+4]+delta[j+3]+gamma[j+4]*(yppp+1)+delta[j+4]*yppp+gamma[j+5]+delta[j+5])*Kroneck(gamma[j+3]+delta[j+3]-gamma[j+4]-delta[j+4]+1)*Kroneck(alpha[j+5]+beta[j+5])));
		    }
		  }
		}
	      }

	      for(ypp=0; ypp<=(1+alpha[j+2])%2; ypp++) {
		for(xpp=0; xpp<=(1+beta[j+2])%2; xpp++) {
		  for(yppp=0; yppp<=1; yppp++) {
		    //**for(xppp=0;xppp<=(yppp*(gamma[j+3]+gamma[j+4])+(yppp+1)*(gamma[j+3]+delta[j+4]))%2; xppp++) {
		    for(xppp=yppp*(beta[j+3]+alpha[j+4]+beta[j+4])%2;xppp<=(yppp*(beta[j+3]+alpha[j+4]+beta[j+4])+yppp*(gamma[j+3]+gamma[j+4])+(yppp+1)*(gamma[j+3]+delta[j+4]))%2; xppp++) {
		      summand += ((0.125*2.0*csqrt(-I)*cexp(M_PI*I/2.0*(2.0*beta[i+2]*y+pow(x+1,2)*(delta[i]+gamma[i+1]+2.0*beta[i+1])+x*(delta[i]+delta[i+1])))*Gausssum1d(1,beta[i]+beta[i+1]+delta[i]+(x+1)*gamma[i+1]+x*delta[i+1])*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1]+1)*Kroneck(gamma[i+2]+delta[i+2]))
				  *(0.125*2.0*csqrt(-I)*cexp(M_PI*I/2.0*(2.0*beta[i+5]*yp+pow(xp+1,2)*(delta[i+3]+gamma[i+4]+2.0*beta[i+4])+xp*(delta[i+3]+delta[i+4])))*Gausssum1d(1,beta[i+3]+beta[i+4]+delta[i+3]+(xp+1)*gamma[i+4]+xp*delta[i+4])*Kroneck(gamma[i+3]+delta[i+3]-gamma[i+4]-delta[i+4]+1)*Kroneck(gamma[i+5]+delta[i+5])))
			*((0.125*2.0*csqrt(-I)*cexp(M_PI*I/2.0*(2.0*beta[j+2]*ypp+pow(xpp+1,2)*(delta[j]+gamma[j+1]+2.0*beta[j+1])+xpp*(delta[j]+delta[j+1])))*Gausssum1d(1,beta[j]+beta[j+1]+delta[j]+(xpp+1)*gamma[j+1]+xpp*delta[j+1])*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1]+1)*Kroneck(gamma[j+2]+delta[j+2]))
			  *(0.125*pow(2.0,1-yppp*pow(gamma[j+3]-gamma[j+4],2)-pow(yppp-1,2)*pow(gamma[j+3]-delta[j+4],2))*cexp(M_PI*I/2.0*((delta[j+4]-gamma[j+3])*pow(yppp+1,2)+2.0*(beta[j+3]+beta[j+4]+gamma[j+3]+delta[j+4])*xppp*pow(yppp+1,2)+2.0*(delta[j+3]+delta[j+4]+beta[j+3]+beta[j+4])*xppp*yppp+(2.0*beta[j+3]+3.0*delta[j+3]+delta[j+4])*yppp))*Gausssum1d(0.0,beta[j+5])*Kroneck(gamma[j+3]+delta[j+3]-gamma[j+4]-delta[j+4])*Kroneck(gamma[j+5]+delta[j+5]) 
			    + 0.125*pow(2.0,1-yppp*pow(gamma[j+3]-gamma[j+4],2)-pow(yppp-1,2)*pow(gamma[j+3]-delta[j+4],2))*cexp(M_PI*I/2.0*((delta[j+4]-gamma[j+3])*pow(yppp+1,2)+2.0*(beta[j+3]+beta[j+4]+gamma[j+3]+delta[j+4])*xppp*pow(yppp+1,2)+2.0*(delta[j+3]+delta[j+4]+beta[j+3]+beta[j+4])*xppp*yppp+(2.0*beta[j+3]+3.0*delta[j+3]+delta[j+4])*yppp))*csqrt(-I)*Gausssum1d(gamma[j+5]+delta[j+5],0)*Kroneck(gamma[j+3]+delta[j+3]-gamma[j+4]-delta[j+4])*Kroneck(alpha[j+5]+beta[j+5])));
		    }
		  }
		  for(yppp=0; yppp<=(1+alpha[j+5])%2; yppp++) {
		    for(xppp=0;xppp<=(1+beta[j+5])%2; xppp++) {
		      summand += ((0.125*2.0*csqrt(-I)*cexp(M_PI*I/2.0*(2.0*beta[i+2]*y+pow(x+1,2)*(delta[i]+gamma[i+1]+2.0*beta[i+1])+x*(delta[i]+delta[i+1])))*Gausssum1d(1,beta[i]+beta[i+1]+delta[i]+(x+1)*gamma[i+1]+x*delta[i+1])*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1]+1)*Kroneck(gamma[i+2]+delta[i+2]))
				  *(0.125*2.0*csqrt(-I)*cexp(M_PI*I/2.0*(2.0*beta[i+5]*yp+pow(xp+1,2)*(delta[i+3]+gamma[i+4]+2.0*beta[i+4])+xp*(delta[i+3]+delta[i+4])))*Gausssum1d(1,beta[i+3]+beta[i+4]+delta[i+3]+(xp+1)*gamma[i+4]+xp*delta[i+4])*Kroneck(gamma[i+3]+delta[i+3]-gamma[i+4]-delta[i+4]+1)*Kroneck(gamma[i+5]+delta[i+5])))
			*((0.125*2.0*csqrt(-I)*cexp(M_PI*I/2.0*(2.0*beta[j+2]*ypp+pow(xpp+1,2)*(delta[j]+gamma[j+1]+2.0*beta[j+1])+xpp*(delta[j]+delta[j+1])))*Gausssum1d(1,beta[j]+beta[j+1]+delta[j]+(xpp+1)*gamma[j+1]+xpp*delta[j+1])*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1]+1)*Kroneck(gamma[j+2]+delta[j+2]))
			  *(0.125*2.0*csqrt(-I)*cexp(M_PI*I/2.0*(2.0*beta[j+5]*yppp+pow(xppp+1,2)*(delta[j+3]+gamma[j+4]+2.0*beta[j+4])+xppp*(delta[j+3]+delta[j+4])))*Gausssum1d(1,beta[j+3]+beta[j+4]+delta[j+3]+(xppp+1)*gamma[j+4]+xppp*delta[j+4])*Kroneck(gamma[j+3]+delta[j+3]-gamma[j+4]-delta[j+4]+1)*Kroneck(gamma[j+5]+delta[j+5])));
		    }
		  }
		  for(yppp=0; yppp<=1; yppp++) {
		    for(xppp=(yppp*(delta[j+3]+delta[j+4]))%2;xppp<=(1+yppp*(gamma[j+3]+gamma[j+4]))%2; xppp++) {
		      summand += ((0.125*2.0*csqrt(-I)*cexp(M_PI*I/2.0*(2.0*beta[i+2]*y+pow(x+1,2)*(delta[i]+gamma[i+1]+2.0*beta[i+1])+x*(delta[i]+delta[i+1])))*Gausssum1d(1,beta[i]+beta[i+1]+delta[i]+(x+1)*gamma[i+1]+x*delta[i+1])*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1]+1)*Kroneck(gamma[i+2]+delta[i+2]))
				  *(0.125*2.0*csqrt(-I)*cexp(M_PI*I/2.0*(2.0*beta[i+5]*yp+pow(xp+1,2)*(delta[i+3]+gamma[i+4]+2.0*beta[i+4])+xp*(delta[i+3]+delta[i+4])))*Gausssum1d(1,beta[i+3]+beta[i+4]+delta[i+3]+(xp+1)*gamma[i+4]+xp*delta[i+4])*Kroneck(gamma[i+3]+delta[i+3]-gamma[i+4]-delta[i+4]+1)*Kroneck(gamma[i+5]+delta[i+5])))
			*((0.125*2.0*csqrt(-I)*cexp(M_PI*I/2.0*(2.0*beta[j+2]*ypp+pow(xpp+1,2)*(delta[j]+gamma[j+1]+2.0*beta[j+1])+xpp*(delta[j]+delta[j+1])))*Gausssum1d(1,beta[j]+beta[j+1]+delta[j]+(xpp+1)*gamma[j+1]+xpp*delta[j+1])*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1]+1)*Kroneck(gamma[j+2]+delta[j+2]))
			  *(0.125*(-I)*pow(2.0,(pow(yppp-1,2)*(pow(xppp,2)*(gamma[j+3]+delta[j+4])+pow(xppp-1,2)*(gamma[j+4]+delta[j+3]))))*cexp(M_PI*I/2.0*(yppp*(delta[j+3]+delta[j+4])+pow(yppp+1,2)*(delta[j+3]+gamma[j+4]+2*beta[j+4])+pow(xppp,2)+2*(beta[j+3]+beta[j+4]+delta[j+3]+gamma[j+4]*(yppp+1)+delta[j+4]*yppp)*xppp))*Gausssum1d(0,xppp+beta[j+3]+beta[j+4]+delta[j+3]+gamma[j+4]*(yppp+1)+delta[j+4]*yppp+gamma[j+5]+delta[j+5])*Kroneck(gamma[j+3]+delta[j+3]-gamma[j+4]-delta[j+4]+1)*Kroneck(alpha[j+5]+beta[j+5])));
		    }
		  }
		}
	      }

	      for(ypp=0; ypp<=1; ypp++) {
		for(xpp=(ypp*(delta[j]+delta[j+1]))%2; xpp<=(1+ypp*(gamma[j]+gamma[j+1]))%2; xpp++) {
		  for(yppp=((gamma[j+3]+delta[j+4])*ypp)%2; yppp<=(1+(gamma[j+3]+gamma[j+4])*ypp)%2; yppp++) {
		    //**for(xppp=0;xppp<=(yppp*(gamma[j+3]+gamma[j+4])+(yppp+1)*(gamma[j+3]+delta[j+4]))%2; xppp++) {
		    for(xppp=yppp*(beta[j+3]+alpha[j+4]+beta[j+4])%2;xppp<=(yppp*(beta[j+3]+alpha[j+4]+beta[j+4])+yppp*(gamma[j+3]+gamma[j+4])+(yppp+1)*(gamma[j+3]+delta[j+4]))%2; xppp++) {
		      summand += ((0.125*2.0*csqrt(-I)*cexp(M_PI*I/2.0*(2.0*beta[i+2]*y+pow(x+1,2)*(delta[i]+gamma[i+1]+2.0*beta[i+1])+x*(delta[i]+delta[i+1])))*Gausssum1d(1,beta[i]+beta[i+1]+delta[i]+(x+1)*gamma[i+1]+x*delta[i+1])*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1]+1)*Kroneck(gamma[i+2]+delta[i+2]))
				  *(0.125*2.0*csqrt(-I)*cexp(M_PI*I/2.0*(2.0*beta[i+5]*yp+pow(xp+1,2)*(delta[i+3]+gamma[i+4]+2.0*beta[i+4])+xp*(delta[i+3]+delta[i+4])))*Gausssum1d(1,beta[i+3]+beta[i+4]+delta[i+3]+(xp+1)*gamma[i+4]+xp*delta[i+4])*Kroneck(gamma[i+3]+delta[i+3]-gamma[i+4]-delta[i+4]+1)*Kroneck(gamma[i+5]+delta[i+5])))
			*(2.0*(0.125*pow(2.0,(pow(ypp-1,2)*(pow(xpp,2)*(gamma[j]+delta[j+1])+pow(xpp-1,2)*(gamma[j+1]+delta[j])))*(1-yppp*pow(gamma[j+3]-gamma[j+4],2)-pow(yppp-1,2)*pow(gamma[j+3]-delta[j+4],2)))*(-I)*cexp(M_PI*I/2.0*(ypp*(delta[j]+delta[j+1])+pow(ypp+1,2)*(delta[j]+gamma[j+1]+2*beta[j+1])+pow(xpp,2)+2*(beta[j]+beta[j+1]+delta[j]+gamma[j+1]*(ypp+1)+delta[j+1]*ypp)*xpp))*Gausssum1d(0,xpp+beta[j]+beta[j+1]+delta[j]+gamma[j+1]*(ypp+1)+delta[j+1]*ypp+gamma[j+2]+delta[j+2])*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1]+1)*Kroneck(alpha[j+2]+beta[j+2]))
			  *(0.125*cexp(M_PI*I/2.0*((delta[j+4]-gamma[j+3])*pow(yppp+1,2)+2.0*(beta[j+3]+beta[j+4]+gamma[j+3]+delta[j+4])*xppp*pow(yppp+1,2)+2.0*(delta[j+3]+delta[j+4]+beta[j+3]+beta[j+4])*xppp*yppp+(2.0*beta[j+3]+3.0*delta[j+3]+delta[j+4])*yppp))*Gausssum1d(0.0,beta[j+5])*Kroneck(gamma[j+3]+delta[j+3]-gamma[j+4]-delta[j+4])*Kroneck(gamma[j+5]+delta[j+5]) 
			    + 0.125*cexp(M_PI*I/2.0*((delta[j+4]-gamma[j+3])*pow(yppp+1,2)+2.0*(beta[j+3]+beta[j+4]+gamma[j+3]+delta[j+4])*xppp*pow(yppp+1,2)+2.0*(delta[j+3]+delta[j+4]+beta[j+3]+beta[j+4])*xppp*yppp+(2.0*beta[j+3]+3.0*delta[j+3]+delta[j+4])*yppp))*csqrt(-I)*Gausssum1d(gamma[j+5]+delta[j+5],0)*Kroneck(gamma[j+3]+delta[j+3]-gamma[j+4]-delta[j+4])*Kroneck(alpha[j+5]+beta[j+5])));
		    }
		  }
		  for(yppp=0; yppp<=(1+alpha[j+5])%2; yppp++) {
		    for(xppp=0;xppp<=(1+beta[j+5])%2; xppp++) {
		      summand += ((0.125*2.0*csqrt(-I)*cexp(M_PI*I/2.0*(2.0*beta[i+2]*y+pow(x+1,2)*(delta[i]+gamma[i+1]+2.0*beta[i+1])+x*(delta[i]+delta[i+1])))*Gausssum1d(1,beta[i]+beta[i+1]+delta[i]+(x+1)*gamma[i+1]+x*delta[i+1])*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1]+1)*Kroneck(gamma[i+2]+delta[i+2]))
				  *(0.125*2.0*csqrt(-I)*cexp(M_PI*I/2.0*(2.0*beta[i+5]*yp+pow(xp+1,2)*(delta[i+3]+gamma[i+4]+2.0*beta[i+4])+xp*(delta[i+3]+delta[i+4])))*Gausssum1d(1,beta[i+3]+beta[i+4]+delta[i+3]+(xp+1)*gamma[i+4]+xp*delta[i+4])*Kroneck(gamma[i+3]+delta[i+3]-gamma[i+4]-delta[i+4]+1)*Kroneck(gamma[i+5]+delta[i+5])))
			*((0.125*pow(2.0,pow(ypp-1,2)*(pow(xpp,2)*(gamma[j]+delta[j+1])+pow(xpp-1,2)*(gamma[j+1]+delta[j])))*(-I)*cexp(M_PI*I/2.0*(ypp*(delta[j]+delta[j+1])+pow(ypp+1,2)*(delta[j]+gamma[j+1]+2*beta[j+1])+pow(xpp,2)+2*(beta[j]+beta[j+1]+delta[j]+gamma[j+1]*(ypp+1)+delta[j+1]*ypp)*xpp))*Gausssum1d(0,xpp+beta[j]+beta[j+1]+delta[j]+gamma[j+1]*(ypp+1)+delta[j+1]*ypp+gamma[j+2]+delta[j+2])*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1]+1)*Kroneck(alpha[j+2]+beta[j+2]))
			  *(0.125*2.0*csqrt(-I)*cexp(M_PI*I/2.0*(2.0*beta[j+5]*yppp+pow(xppp+1,2)*(delta[j+3]+gamma[j+4]+2.0*beta[j+4])+xppp*(delta[j+3]+delta[j+4])))*Gausssum1d(1,beta[j+3]+beta[j+4]+delta[j+3]+(xppp+1)*gamma[j+4]+xppp*delta[j+4])*Kroneck(gamma[j+3]+delta[j+3]-gamma[j+4]-delta[j+4]+1)*Kroneck(gamma[j+5]+delta[j+5])));
		    }
		  }
		  for(yppp=ypp; yppp<=1; yppp++) {
		    for(xppp=(yppp*(delta[j+3]+delta[j+4])+ypp)%2;xppp<=(1+yppp*(gamma[j+3]+gamma[j+4])+ypp)%2; xppp++) {
		      summand += ((0.125*2.0*csqrt(-I)*cexp(M_PI*I/2.0*(2.0*beta[i+2]*y+pow(x+1,2)*(delta[i]+gamma[i+1]+2.0*beta[i+1])+x*(delta[i]+delta[i+1])))*Gausssum1d(1,beta[i]+beta[i+1]+delta[i]+(x+1)*gamma[i+1]+x*delta[i+1])*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1]+1)*Kroneck(gamma[i+2]+delta[i+2]))
				  *(0.125*2.0*csqrt(-I)*cexp(M_PI*I/2.0*(2.0*beta[i+5]*yp+pow(xp+1,2)*(delta[i+3]+gamma[i+4]+2.0*beta[i+4])+xp*(delta[i+3]+delta[i+4])))*Gausssum1d(1,beta[i+3]+beta[i+4]+delta[i+3]+(xp+1)*gamma[i+4]+xp*delta[i+4])*Kroneck(gamma[i+3]+delta[i+3]-gamma[i+4]-delta[i+4]+1)*Kroneck(gamma[i+5]+delta[i+5])))
			*(2.0*(0.125*pow(2.0,(pow(ypp-1,2)*(pow(xpp,2)*(gamma[j]+delta[j+1])+pow(xpp-1,2)*(gamma[j+1]+delta[j])))*(pow(yppp-1,2)*(pow(xppp,2)*(gamma[j+3]+delta[j+4])+pow(xppp-1,2)*(gamma[j+4]+delta[j+3]))))*(-I)*cexp(M_PI*I/2.0*(ypp*(delta[j]+delta[j+1])+pow(ypp+1,2)*(delta[j]+gamma[j+1]+2*beta[j+1])+pow(xpp,2)+2*(beta[j]+beta[j+1]+delta[j]+gamma[j+1]*(ypp+1)+delta[j+1]*ypp)*xpp))*Gausssum1d(0,xpp+beta[j]+beta[j+1]+delta[j]+gamma[j+1]*(ypp+1)+delta[j+1]*ypp+gamma[j+2]+delta[j+2])*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1]+1)*Kroneck(alpha[j+2]+beta[j+2]))
			  *(0.125*(-I)*cexp(M_PI*I/2.0*(yppp*(delta[j+3]+delta[j+4])+pow(yppp+1,2)*(delta[j+3]+gamma[j+4]+2*beta[j+4])+pow(xppp,2)+2*(beta[j+3]+beta[j+4]+delta[j+3]+gamma[j+4]*(yppp+1)+delta[j+4]*yppp)*xppp))*Gausssum1d(0,xppp+beta[j+3]+beta[j+4]+delta[j+3]+gamma[j+4]*(yppp+1)+delta[j+4]*yppp+gamma[j+5]+delta[j+5])*Kroneck(gamma[j+3]+delta[j+3]-gamma[j+4]-delta[j+4]+1)*Kroneck(alpha[j+5]+beta[j+5])));
		    }
		  }
		}
	      }
	    }
	  }
	}
      }

      
      // sixth term
      for(y=0; y<=(1+alpha[i+2])%2; y++) {
	for(x=0; x<=(1+beta[i+2])%2; x++) {
	  for(yp=0; yp<=1; yp++) {
	    for(xp=(yp*(delta[i+3]+delta[i+4]))%2;xp<=(1+yp*(gamma[i+3]+gamma[i+4]))%2; xp++) {
	      for(ypp=0; ypp<=1; ypp++) {
		//**for(xpp=0;xpp<=(ypp*(gamma[j]+gamma[j+1])+(ypp+1)*(gamma[j]+delta[j+1]))%2; xpp++) {
		for(xpp=ypp*(beta[j]+alpha[j+1]+beta[j+1])%2;xpp<=(ypp*(beta[j]+alpha[j+1]+beta[j+1])+ypp*(gamma[j]+gamma[j+1])+(ypp+1)*(gamma[j]+delta[j+1]))%2; xpp++) {
		  for(yppp=((gamma[j+3]+delta[j+4])*xpp)%2; yppp<=(1+(gamma[j+3]+gamma[j+4])*xpp)%2; yppp++) {
		    //**for(xppp=0;xppp<=(yppp*(gamma[j+3]+gamma[j+4])+(yppp+1)*(gamma[j+3]+delta[j+4]))%2; xppp++) {
		    for(xppp=yppp*(beta[j+3]+alpha[j+4]+beta[j+4])%2;xppp<=(yppp*(beta[j+3]+alpha[j+4]+beta[j+4])+yppp*(gamma[j+3]+gamma[j+4])+(yppp+1)*(gamma[j+3]+delta[j+4]))%2; xppp++) {
		      summand += ((0.125*2.0*csqrt(-I)*cexp(M_PI*I/2.0*(2.0*beta[i+2]*y+pow(x+1,2)*(delta[i]+gamma[i+1]+2.0*beta[i+1])+x*(delta[i]+delta[i+1])))*Gausssum1d(1,beta[i]+beta[i+1]+delta[i]+(x+1)*gamma[i+1]+x*delta[i+1])*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1]+1)*Kroneck(gamma[i+2]+delta[i+2]))
				  *(0.125*(-I)*pow(2.0,(pow(yp-1,2)*(pow(xp,2)*(gamma[i+3]+delta[i+4])+pow(xp-1,2)*(gamma[i+4]+delta[i+3]))))*cexp(M_PI*I/2.0*(yp*(delta[i+3]+delta[i+4])+pow(yp+1,2)*(delta[i+3]+gamma[i+4]+2*beta[i+4])+pow(xp,2)+2*(beta[i+3]+beta[i+4]+delta[i+3]+gamma[i+4]*(yp+1)+delta[i+4]*yp)*xp))*Gausssum1d(0,xp+beta[i+3]+beta[i+4]+delta[i+3]+gamma[i+4]*(yp+1)+delta[i+4]*yp+gamma[i+5]+delta[i+5])*Kroneck(gamma[i+3]+delta[i+3]-gamma[i+4]-delta[i+4]+1)*Kroneck(alpha[i+5]+beta[i+5])))
			*(2.0*(0.125*pow(2.0,(1-ypp*pow(gamma[j]-gamma[j+1],2)-pow(ypp-1,2)*pow(gamma[j]-delta[j+1],2))*(1-yppp*pow(gamma[j+3]-gamma[j+4],2)-pow(yppp-1,2)*pow(gamma[j+3]-delta[j+4],2)))*cexp(M_PI*I/2.0*((delta[j+1]-gamma[j])*pow(ypp+1,2)+2.0*(beta[j]+beta[j+1]+gamma[j]+delta[j+1])*xpp*pow(ypp+1,2)+2.0*(delta[j]+delta[j+1]+beta[j]+beta[j+1])*xpp*ypp+(2.0*beta[j]+3.0*delta[j]+delta[j+1])*ypp))*Gausssum1d(0.0,beta[j+2])*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1])*Kroneck(gamma[j+2]+delta[j+2]) 
			      + 0.125*pow(2.0,(1-ypp*pow(gamma[j]-gamma[j+1],2)-pow(ypp-1,2)*pow(gamma[j]-delta[j+1],2))*(1-yppp*pow(gamma[j+3]-gamma[j+4],2)-pow(yppp-1,2)*pow(gamma[j+3]-delta[j+4],2)))*cexp(M_PI*I/2.0*((delta[j+1]-gamma[j])*pow(ypp+1,2)+2.0*(beta[j]+beta[j+1]+gamma[j]+delta[j+1])*xpp*pow(ypp+1,2)+2.0*(delta[j]+delta[j+1]+beta[j]+beta[j+1])*xpp*ypp+(2.0*beta[j]+3.0*delta[j]+delta[j+1])*ypp))*csqrt(-I)*Gausssum1d(gamma[j+2]+delta[j+2],0)*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1])*Kroneck(alpha[j+2]+beta[j+2]))
			*(0.125*cexp(M_PI*I/2.0*((delta[j+4]-gamma[j+3])*pow(yppp+1,2)+2.0*(beta[j+3]+beta[j+4]+gamma[j+3]+delta[j+4])*xppp*pow(yppp+1,2)+2.0*(delta[j+3]+delta[j+4]+beta[j+3]+beta[j+4])*xppp*yppp+(2.0*beta[j+3]+3.0*delta[j+3]+delta[j+4])*yppp))*Gausssum1d(0.0,beta[j+5])*Kroneck(gamma[j+3]+delta[j+3]-gamma[j+4]-delta[j+4])*Kroneck(gamma[j+5]+delta[j+5]) 
			  + 0.125*cexp(M_PI*I/2.0*((delta[j+4]-gamma[j+3])*pow(yppp+1,2)+2.0*(beta[j+3]+beta[j+4]+gamma[j+3]+delta[j+4])*xppp*pow(yppp+1,2)+2.0*(delta[j+3]+delta[j+4]+beta[j+3]+beta[j+4])*xppp*yppp+(2.0*beta[j+3]+3.0*delta[j+3]+delta[j+4])*yppp))*csqrt(-I)*Gausssum1d(gamma[j+5]+delta[j+5],0)*Kroneck(gamma[j+3]+delta[j+3]-gamma[j+4]-delta[j+4])*Kroneck(alpha[j+5]+beta[j+5])));
		    }
		  }
		  for(yppp=0; yppp<=(1+alpha[j+5])%2; yppp++) {
		    for(xppp=0;xppp<=(1+beta[j+5])%2; xppp++) {
		      summand += ((0.125*2.0*csqrt(-I)*cexp(M_PI*I/2.0*(2.0*beta[i+2]*y+pow(x+1,2)*(delta[i]+gamma[i+1]+2.0*beta[i+1])+x*(delta[i]+delta[i+1])))*Gausssum1d(1,beta[i]+beta[i+1]+delta[i]+(x+1)*gamma[i+1]+x*delta[i+1])*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1]+1)*Kroneck(gamma[i+2]+delta[i+2]))
				  *(0.125*(-I)*pow(2.0,(pow(yp-1,2)*(pow(xp,2)*(gamma[i+3]+delta[i+4])+pow(xp-1,2)*(gamma[i+4]+delta[i+3]))))*cexp(M_PI*I/2.0*(yp*(delta[i+3]+delta[i+4])+pow(yp+1,2)*(delta[i+3]+gamma[i+4]+2*beta[i+4])+pow(xp,2)+2*(beta[i+3]+beta[i+4]+delta[i+3]+gamma[i+4]*(yp+1)+delta[i+4]*yp)*xp))*Gausssum1d(0,xp+beta[i+3]+beta[i+4]+delta[i+3]+gamma[i+4]*(yp+1)+delta[i+4]*yp+gamma[i+5]+delta[i+5])*Kroneck(gamma[i+3]+delta[i+3]-gamma[i+4]-delta[i+4]+1)*Kroneck(alpha[i+5]+beta[i+5])))
			*((0.125*pow(2.0,1-ypp*pow(gamma[j]-gamma[j+1],2)-pow(ypp-1,2)*pow(gamma[j]-delta[j+1],2))*cexp(M_PI*I/2.0*((delta[j+1]-gamma[j])*pow(ypp+1,2)+2.0*(beta[j]+beta[j+1]+gamma[j]+delta[j+1])*xpp*pow(ypp+1,2)+2.0*(delta[j]+delta[j+1]+beta[j]+beta[j+1])*xpp*ypp+(2.0*beta[j]+3.0*delta[j]+delta[j+1])*ypp))*Gausssum1d(0.0,beta[j+2])*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1])*Kroneck(gamma[j+2]+delta[j+2]) 
				  + 0.125*pow(2.0,1-ypp*pow(gamma[j]-gamma[j+1],2)-pow(ypp-1,2)*pow(gamma[j]-delta[j+1],2))*cexp(M_PI*I/2.0*((delta[j+1]-gamma[j])*pow(ypp+1,2)+2.0*(beta[j]+beta[j+1]+gamma[j]+delta[j+1])*xpp*pow(ypp+1,2)+2.0*(delta[j]+delta[j+1]+beta[j]+beta[j+1])*xpp*ypp+(2.0*beta[j]+3.0*delta[j]+delta[j+1])*ypp))*csqrt(-I)*Gausssum1d(gamma[j+2]+delta[j+2],0)*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1])*Kroneck(alpha[j+2]+beta[j+2]))
			  *(0.125*2.0*csqrt(-I)*cexp(M_PI*I/2.0*(2.0*beta[j+5]*yppp+pow(xppp+1,2)*(delta[j+3]+gamma[j+4]+2.0*beta[j+4])+xppp*(delta[j+3]+delta[j+4])))*Gausssum1d(1,beta[j+3]+beta[j+4]+delta[j+3]+(xppp+1)*gamma[j+4]+xppp*delta[j+4])*Kroneck(gamma[j+3]+delta[j+3]-gamma[j+4]-delta[j+4]+1)*Kroneck(gamma[j+5]+delta[j+5])));
		    }
		  }
		  //**for(yppp=xpp; yppp<=1; yppp++) {
		  for(yppp=xpp*(1+alpha[j]+beta[j])%2; yppp<=1; yppp++) {
		    //**for(xppp=(yppp*(delta[j+3]+delta[j+4])+xpp)%2;xppp<=(1+yppp*(gamma[j+3]+gamma[j+4])+xpp)%2; xppp++) {
		    for(xppp=(yppp*(delta[j+3]+delta[j+4])+xpp*(1+alpha[j]+beta[j]))%2;xppp<=(1+yppp*(gamma[j+3]+gamma[j+4])+xpp*(1+alpha[j]+beta[j]))%2; xppp++) {
		      summand += ((0.125*2.0*csqrt(-I)*cexp(M_PI*I/2.0*(2.0*beta[i+2]*y+pow(x+1,2)*(delta[i]+gamma[i+1]+2.0*beta[i+1])+x*(delta[i]+delta[i+1])))*Gausssum1d(1,beta[i]+beta[i+1]+delta[i]+(x+1)*gamma[i+1]+x*delta[i+1])*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1]+1)*Kroneck(gamma[i+2]+delta[i+2]))
				  *(0.125*(-I)*pow(2.0,(pow(yp-1,2)*(pow(xp,2)*(gamma[i+3]+delta[i+4])+pow(xp-1,2)*(gamma[i+4]+delta[i+3]))))*cexp(M_PI*I/2.0*(yp*(delta[i+3]+delta[i+4])+pow(yp+1,2)*(delta[i+3]+gamma[i+4]+2*beta[i+4])+pow(xp,2)+2*(beta[i+3]+beta[i+4]+delta[i+3]+gamma[i+4]*(yp+1)+delta[i+4]*yp)*xp))*Gausssum1d(0,xp+beta[i+3]+beta[i+4]+delta[i+3]+gamma[i+4]*(yp+1)+delta[i+4]*yp+gamma[i+5]+delta[i+5])*Kroneck(gamma[i+3]+delta[i+3]-gamma[i+4]-delta[i+4]+1)*Kroneck(alpha[i+5]+beta[i+5])))
			*(2.0*(0.125*pow(2.0,(1-ypp*pow(gamma[j]-gamma[j+1],2)-pow(ypp-1,2)*pow(gamma[j]-delta[j+1],2))*(pow(yppp-1,2)*(pow(xppp,2)*(gamma[j+3]+delta[j+4])+pow(xppp-1,2)*(gamma[j+4]+delta[j+3]))))*cexp(M_PI*I/2.0*((delta[j+1]-gamma[j])*pow(ypp+1,2)+2.0*(beta[j]+beta[j+1]+gamma[j]+delta[j+1])*xpp*pow(ypp+1,2)+2.0*(delta[j]+delta[j+1]+beta[j]+beta[j+1])*xpp*ypp+(2.0*beta[j]+3.0*delta[j]+delta[j+1])*ypp))*Gausssum1d(0.0,beta[j+2])*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1])*Kroneck(gamma[j+2]+delta[j+2]) 
				      + 0.125*pow(2.0,(1-ypp*pow(gamma[j]-gamma[j+1],2)-pow(ypp-1,2)*pow(gamma[j]-delta[j+1],2))*(pow(yppp-1,2)*(pow(xppp,2)*(gamma[j+3]+delta[j+4])+pow(xppp-1,2)*(gamma[j+4]+delta[j+3]))))*cexp(M_PI*I/2.0*((delta[j+1]-gamma[j])*pow(ypp+1,2)+2.0*(beta[j]+beta[j+1]+gamma[j]+delta[j+1])*xpp*pow(ypp+1,2)+2.0*(delta[j]+delta[j+1]+beta[j]+beta[j+1])*xpp*ypp+(2.0*beta[j]+3.0*delta[j]+delta[j+1])*ypp))*csqrt(-I)*Gausssum1d(gamma[j+2]+delta[j+2],0)*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1])*Kroneck(alpha[j+2]+beta[j+2]))
			  *(0.125*(-I)*cexp(M_PI*I/2.0*(yppp*(delta[j+3]+delta[j+4])+pow(yppp+1,2)*(delta[j+3]+gamma[j+4]+2*beta[j+4])+pow(xppp,2)+2*(beta[j+3]+beta[j+4]+delta[j+3]+gamma[j+4]*(yppp+1)+delta[j+4]*yppp)*xppp))*Gausssum1d(0,xppp+beta[j+3]+beta[j+4]+delta[j+3]+gamma[j+4]*(yppp+1)+delta[j+4]*yppp+gamma[j+5]+delta[j+5])*Kroneck(gamma[j+3]+delta[j+3]-gamma[j+4]-delta[j+4]+1)*Kroneck(alpha[j+5]+beta[j+5])));
		    }
		  }
		}
	      }

	      for(ypp=0; ypp<=(1+alpha[j+2])%2; ypp++) {
		for(xpp=0; xpp<=(1+beta[j+2])%2; xpp++) {
		  for(yppp=0; yppp<=1; yppp++) {
		    //**for(xppp=0;xppp<=(yppp*(gamma[j+3]+gamma[j+4])+(yppp+1)*(gamma[j+3]+delta[j+4]))%2; xppp++) {
		    for(xppp=yppp*(beta[j+3]+alpha[j+4]+beta[j+4])%2;xppp<=(yppp*(beta[j+3]+alpha[j+4]+beta[j+4])+yppp*(gamma[j+3]+gamma[j+4])+(yppp+1)*(gamma[j+3]+delta[j+4]))%2; xppp++) {
		      summand += ((0.125*2.0*csqrt(-I)*cexp(M_PI*I/2.0*(2.0*beta[i+2]*y+pow(x+1,2)*(delta[i]+gamma[i+1]+2.0*beta[i+1])+x*(delta[i]+delta[i+1])))*Gausssum1d(1,beta[i]+beta[i+1]+delta[i]+(x+1)*gamma[i+1]+x*delta[i+1])*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1]+1)*Kroneck(gamma[i+2]+delta[i+2]))
				  *(0.125*(-I)*pow(2.0,(pow(yp-1,2)*(pow(xp,2)*(gamma[i+3]+delta[i+4])+pow(xp-1,2)*(gamma[i+4]+delta[i+3]))))*cexp(M_PI*I/2.0*(yp*(delta[i+3]+delta[i+4])+pow(yp+1,2)*(delta[i+3]+gamma[i+4]+2*beta[i+4])+pow(xp,2)+2*(beta[i+3]+beta[i+4]+delta[i+3]+gamma[i+4]*(yp+1)+delta[i+4]*yp)*xp))*Gausssum1d(0,xp+beta[i+3]+beta[i+4]+delta[i+3]+gamma[i+4]*(yp+1)+delta[i+4]*yp+gamma[i+5]+delta[i+5])*Kroneck(gamma[i+3]+delta[i+3]-gamma[i+4]-delta[i+4]+1)*Kroneck(alpha[i+5]+beta[i+5])))
			*((0.125*2.0*csqrt(-I)*cexp(M_PI*I/2.0*(2.0*beta[j+2]*ypp+pow(xpp+1,2)*(delta[j]+gamma[j+1]+2.0*beta[j+1])+xpp*(delta[j]+delta[j+1])))*Gausssum1d(1,beta[j]+beta[j+1]+delta[j]+(xpp+1)*gamma[j+1]+xpp*delta[j+1])*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1]+1)*Kroneck(gamma[j+2]+delta[j+2]))
			  *(0.125*pow(2.0,1-yppp*pow(gamma[j+3]-gamma[j+4],2)-pow(yppp-1,2)*pow(gamma[j+3]-delta[j+4],2))*cexp(M_PI*I/2.0*((delta[j+4]-gamma[j+3])*pow(yppp+1,2)+2.0*(beta[j+3]+beta[j+4]+gamma[j+3]+delta[j+4])*xppp*pow(yppp+1,2)+2.0*(delta[j+3]+delta[j+4]+beta[j+3]+beta[j+4])*xppp*yppp+(2.0*beta[j+3]+3.0*delta[j+3]+delta[j+4])*yppp))*Gausssum1d(0.0,beta[j+5])*Kroneck(gamma[j+3]+delta[j+3]-gamma[j+4]-delta[j+4])*Kroneck(gamma[j+5]+delta[j+5]) 
			    + 0.125*pow(2.0,1-yppp*pow(gamma[j+3]-gamma[j+4],2)-pow(yppp-1,2)*pow(gamma[j+3]-delta[j+4],2))*cexp(M_PI*I/2.0*((delta[j+4]-gamma[j+3])*pow(yppp+1,2)+2.0*(beta[j+3]+beta[j+4]+gamma[j+3]+delta[j+4])*xppp*pow(yppp+1,2)+2.0*(delta[j+3]+delta[j+4]+beta[j+3]+beta[j+4])*xppp*yppp+(2.0*beta[j+3]+3.0*delta[j+3]+delta[j+4])*yppp))*csqrt(-I)*Gausssum1d(gamma[j+5]+delta[j+5],0)*Kroneck(gamma[j+3]+delta[j+3]-gamma[j+4]-delta[j+4])*Kroneck(alpha[j+5]+beta[j+5])));
		    }
		  }
		  for(yppp=0; yppp<=(1+alpha[j+5])%2; yppp++) {
		    for(xppp=0;xppp<=(1+beta[j+5])%2; xppp++) {
		      summand += ((0.125*2.0*csqrt(-I)*cexp(M_PI*I/2.0*(2.0*beta[i+2]*y+pow(x+1,2)*(delta[i]+gamma[i+1]+2.0*beta[i+1])+x*(delta[i]+delta[i+1])))*Gausssum1d(1,beta[i]+beta[i+1]+delta[i]+(x+1)*gamma[i+1]+x*delta[i+1])*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1]+1)*Kroneck(gamma[i+2]+delta[i+2]))
				  *(0.125*(-I)*pow(2.0,(pow(yp-1,2)*(pow(xp,2)*(gamma[i+3]+delta[i+4])+pow(xp-1,2)*(gamma[i+4]+delta[i+3]))))*cexp(M_PI*I/2.0*(yp*(delta[i+3]+delta[i+4])+pow(yp+1,2)*(delta[i+3]+gamma[i+4]+2*beta[i+4])+pow(xp,2)+2*(beta[i+3]+beta[i+4]+delta[i+3]+gamma[i+4]*(yp+1)+delta[i+4]*yp)*xp))*Gausssum1d(0,xp+beta[i+3]+beta[i+4]+delta[i+3]+gamma[i+4]*(yp+1)+delta[i+4]*yp+gamma[i+5]+delta[i+5])*Kroneck(gamma[i+3]+delta[i+3]-gamma[i+4]-delta[i+4]+1)*Kroneck(alpha[i+5]+beta[i+5])))
			*((0.125*2.0*csqrt(-I)*cexp(M_PI*I/2.0*(2.0*beta[j+2]*ypp+pow(xpp+1,2)*(delta[j]+gamma[j+1]+2.0*beta[j+1])+xpp*(delta[j]+delta[j+1])))*Gausssum1d(1,beta[j]+beta[j+1]+delta[j]+(xpp+1)*gamma[j+1]+xpp*delta[j+1])*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1]+1)*Kroneck(gamma[j+2]+delta[j+2]))
			  *(0.125*2.0*csqrt(-I)*cexp(M_PI*I/2.0*(2.0*beta[j+5]*yppp+pow(xppp+1,2)*(delta[j+3]+gamma[j+4]+2.0*beta[j+4])+xppp*(delta[j+3]+delta[j+4])))*Gausssum1d(1,beta[j+3]+beta[j+4]+delta[j+3]+(xppp+1)*gamma[j+4]+xppp*delta[j+4])*Kroneck(gamma[j+3]+delta[j+3]-gamma[j+4]-delta[j+4]+1)*Kroneck(gamma[j+5]+delta[j+5])));
		    }
		  }
		  for(yppp=0; yppp<=1; yppp++) {
		    for(xppp=(yppp*(delta[j+3]+delta[j+4]))%2;xppp<=(1+yppp*(gamma[j+3]+gamma[j+4]))%2; xppp++) {
		      summand += ((0.125*2.0*csqrt(-I)*cexp(M_PI*I/2.0*(2.0*beta[i+2]*y+pow(x+1,2)*(delta[i]+gamma[i+1]+2.0*beta[i+1])+x*(delta[i]+delta[i+1])))*Gausssum1d(1,beta[i]+beta[i+1]+delta[i]+(x+1)*gamma[i+1]+x*delta[i+1])*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1]+1)*Kroneck(gamma[i+2]+delta[i+2]))
				  *(0.125*(-I)*pow(2.0,(pow(yp-1,2)*(pow(xp,2)*(gamma[i+3]+delta[i+4])+pow(xp-1,2)*(gamma[i+4]+delta[i+3]))))*cexp(M_PI*I/2.0*(yp*(delta[i+3]+delta[i+4])+pow(yp+1,2)*(delta[i+3]+gamma[i+4]+2*beta[i+4])+pow(xp,2)+2*(beta[i+3]+beta[i+4]+delta[i+3]+gamma[i+4]*(yp+1)+delta[i+4]*yp)*xp))*Gausssum1d(0,xp+beta[i+3]+beta[i+4]+delta[i+3]+gamma[i+4]*(yp+1)+delta[i+4]*yp+gamma[i+5]+delta[i+5])*Kroneck(gamma[i+3]+delta[i+3]-gamma[i+4]-delta[i+4]+1)*Kroneck(alpha[i+5]+beta[i+5])))
			*((0.125*2.0*csqrt(-I)*cexp(M_PI*I/2.0*(2.0*beta[j+2]*ypp+pow(xpp+1,2)*(delta[j]+gamma[j+1]+2.0*beta[j+1])+xpp*(delta[j]+delta[j+1])))*Gausssum1d(1,beta[j]+beta[j+1]+delta[j]+(xpp+1)*gamma[j+1]+xpp*delta[j+1])*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1]+1)*Kroneck(gamma[j+2]+delta[j+2]))
			  *(0.125*(-I)*pow(2.0,(pow(yppp-1,2)*(pow(xppp,2)*(gamma[j+3]+delta[j+4])+pow(xppp-1,2)*(gamma[j+4]+delta[j+3]))))*cexp(M_PI*I/2.0*(yppp*(delta[j+3]+delta[j+4])+pow(yppp+1,2)*(delta[j+3]+gamma[j+4]+2*beta[j+4])+pow(xppp,2)+2*(beta[j+3]+beta[j+4]+delta[j+3]+gamma[j+4]*(yppp+1)+delta[j+4]*yppp)*xppp))*Gausssum1d(0,xppp+beta[j+3]+beta[j+4]+delta[j+3]+gamma[j+4]*(yppp+1)+delta[j+4]*yppp+gamma[j+5]+delta[j+5])*Kroneck(gamma[j+3]+delta[j+3]-gamma[j+4]-delta[j+4]+1)*Kroneck(alpha[j+5]+beta[j+5])));
		    }
		  }
		}
	      }

	      for(ypp=0; ypp<=1; ypp++) {
		for(xpp=(ypp*(delta[j]+delta[j+1]))%2; xpp<=(1+ypp*(gamma[j]+gamma[j+1]))%2; xpp++) {
		  for(yppp=((gamma[j+3]+delta[j+4])*ypp)%2; yppp<=(1+(gamma[j+3]+gamma[j+4])*ypp)%2; yppp++) {
		    //**for(xppp=0;xppp<=(yppp*(gamma[j+3]+gamma[j+4])+(yppp+1)*(gamma[j+3]+delta[j+4]))%2; xppp++) {
		    for(xppp=yppp*(beta[j+3]+alpha[j+4]+beta[j+4])%2;xppp<=(yppp*(beta[j+3]+alpha[j+4]+beta[j+4])+yppp*(gamma[j+3]+gamma[j+4])+(yppp+1)*(gamma[j+3]+delta[j+4]))%2; xppp++) {
		      summand += ((0.125*2.0*csqrt(-I)*cexp(M_PI*I/2.0*(2.0*beta[i+2]*y+pow(x+1,2)*(delta[i]+gamma[i+1]+2.0*beta[i+1])+x*(delta[i]+delta[i+1])))*Gausssum1d(1,beta[i]+beta[i+1]+delta[i]+(x+1)*gamma[i+1]+x*delta[i+1])*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1]+1)*Kroneck(gamma[i+2]+delta[i+2]))
				  *(0.125*(-I)*pow(2.0,(pow(yp-1,2)*(pow(xp,2)*(gamma[i+3]+delta[i+4])+pow(xp-1,2)*(gamma[i+4]+delta[i+3]))))*cexp(M_PI*I/2.0*(yp*(delta[i+3]+delta[i+4])+pow(yp+1,2)*(delta[i+3]+gamma[i+4]+2*beta[i+4])+pow(xp,2)+2*(beta[i+3]+beta[i+4]+delta[i+3]+gamma[i+4]*(yp+1)+delta[i+4]*yp)*xp))*Gausssum1d(0,xp+beta[i+3]+beta[i+4]+delta[i+3]+gamma[i+4]*(yp+1)+delta[i+4]*yp+gamma[i+5]+delta[i+5])*Kroneck(gamma[i+3]+delta[i+3]-gamma[i+4]-delta[i+4]+1)*Kroneck(alpha[i+5]+beta[i+5])))
			*(2.0*(0.125*pow(2.0,(pow(ypp-1,2)*(pow(xpp,2)*(gamma[j]+delta[j+1])+pow(xpp-1,2)*(gamma[j+1]+delta[j])))*(1-yppp*pow(gamma[j+3]-gamma[j+4],2)-pow(yppp-1,2)*pow(gamma[j+3]-delta[j+4],2)))*(-I)*cexp(M_PI*I/2.0*(ypp*(delta[j]+delta[j+1])+pow(ypp+1,2)*(delta[j]+gamma[j+1]+2*beta[j+1])+pow(xpp,2)+2*(beta[j]+beta[j+1]+delta[j]+gamma[j+1]*(ypp+1)+delta[j+1]*ypp)*xpp))*Gausssum1d(0,xpp+beta[j]+beta[j+1]+delta[j]+gamma[j+1]*(ypp+1)+delta[j+1]*ypp+gamma[j+2]+delta[j+2])*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1]+1)*Kroneck(alpha[j+2]+beta[j+2]))
			  *(0.125*cexp(M_PI*I/2.0*((delta[j+4]-gamma[j+3])*pow(yppp+1,2)+2.0*(beta[j+3]+beta[j+4]+gamma[j+3]+delta[j+4])*xppp*pow(yppp+1,2)+2.0*(delta[j+3]+delta[j+4]+beta[j+3]+beta[j+4])*xppp*yppp+(2.0*beta[j+3]+3.0*delta[j+3]+delta[j+4])*yppp))*Gausssum1d(0.0,beta[j+5])*Kroneck(gamma[j+3]+delta[j+3]-gamma[j+4]-delta[j+4])*Kroneck(gamma[j+5]+delta[j+5]) 
			    + 0.125*cexp(M_PI*I/2.0*((delta[j+4]-gamma[j+3])*pow(yppp+1,2)+2.0*(beta[j+3]+beta[j+4]+gamma[j+3]+delta[j+4])*xppp*pow(yppp+1,2)+2.0*(delta[j+3]+delta[j+4]+beta[j+3]+beta[j+4])*xppp*yppp+(2.0*beta[j+3]+3.0*delta[j+3]+delta[j+4])*yppp))*csqrt(-I)*Gausssum1d(gamma[j+5]+delta[j+5],0)*Kroneck(gamma[j+3]+delta[j+3]-gamma[j+4]-delta[j+4])*Kroneck(alpha[j+5]+beta[j+5])));
		    }
		  }
		  for(yppp=0; yppp<=(1+alpha[j+5])%2; yppp++) {
		    for(xppp=0;xppp<=(1+beta[j+5])%2; xppp++) {
		      summand += ((0.125*2.0*csqrt(-I)*cexp(M_PI*I/2.0*(2.0*beta[i+2]*y+pow(x+1,2)*(delta[i]+gamma[i+1]+2.0*beta[i+1])+x*(delta[i]+delta[i+1])))*Gausssum1d(1,beta[i]+beta[i+1]+delta[i]+(x+1)*gamma[i+1]+x*delta[i+1])*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1]+1)*Kroneck(gamma[i+2]+delta[i+2]))
				  *(0.125*(-I)*pow(2.0,(pow(yp-1,2)*(pow(xp,2)*(gamma[i+3]+delta[i+4])+pow(xp-1,2)*(gamma[i+4]+delta[i+3]))))*cexp(M_PI*I/2.0*(yp*(delta[i+3]+delta[i+4])+pow(yp+1,2)*(delta[i+3]+gamma[i+4]+2*beta[i+4])+pow(xp,2)+2*(beta[i+3]+beta[i+4]+delta[i+3]+gamma[i+4]*(yp+1)+delta[i+4]*yp)*xp))*Gausssum1d(0,xp+beta[i+3]+beta[i+4]+delta[i+3]+gamma[i+4]*(yp+1)+delta[i+4]*yp+gamma[i+5]+delta[i+5])*Kroneck(gamma[i+3]+delta[i+3]-gamma[i+4]-delta[i+4]+1)*Kroneck(alpha[i+5]+beta[i+5])))
			*((0.125*pow(2.0,pow(ypp-1,2)*(pow(xpp,2)*(gamma[j]+delta[j+1])+pow(xpp-1,2)*(gamma[j+1]+delta[j])))*(-I)*cexp(M_PI*I/2.0*(ypp*(delta[j]+delta[j+1])+pow(ypp+1,2)*(delta[j]+gamma[j+1]+2*beta[j+1])+pow(xpp,2)+2*(beta[j]+beta[j+1]+delta[j]+gamma[j+1]*(ypp+1)+delta[j+1]*ypp)*xpp))*Gausssum1d(0,xpp+beta[j]+beta[j+1]+delta[j]+gamma[j+1]*(ypp+1)+delta[j+1]*ypp+gamma[j+2]+delta[j+2])*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1]+1)*Kroneck(alpha[j+2]+beta[j+2]))
			  *(0.125*2.0*csqrt(-I)*cexp(M_PI*I/2.0*(2.0*beta[j+5]*yppp+pow(xppp+1,2)*(delta[j+3]+gamma[j+4]+2.0*beta[j+4])+xppp*(delta[j+3]+delta[j+4])))*Gausssum1d(1,beta[j+3]+beta[j+4]+delta[j+3]+(xppp+1)*gamma[j+4]+xppp*delta[j+4])*Kroneck(gamma[j+3]+delta[j+3]-gamma[j+4]-delta[j+4]+1)*Kroneck(gamma[j+5]+delta[j+5])));
		    }
		  }
		  for(yppp=ypp; yppp<=1; yppp++) {
		    for(xppp=(yppp*(delta[j+3]+delta[j+4])+ypp)%2;xppp<=(1+yppp*(gamma[j+3]+gamma[j+4])+ypp)%2; xppp++) {
		      summand += ((0.125*2.0*csqrt(-I)*cexp(M_PI*I/2.0*(2.0*beta[i+2]*y+pow(x+1,2)*(delta[i]+gamma[i+1]+2.0*beta[i+1])+x*(delta[i]+delta[i+1])))*Gausssum1d(1,beta[i]+beta[i+1]+delta[i]+(x+1)*gamma[i+1]+x*delta[i+1])*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1]+1)*Kroneck(gamma[i+2]+delta[i+2]))
				  *(0.125*(-I)*pow(2.0,(pow(yp-1,2)*(pow(xp,2)*(gamma[i+3]+delta[i+4])+pow(xp-1,2)*(gamma[i+4]+delta[i+3]))))*cexp(M_PI*I/2.0*(yp*(delta[i+3]+delta[i+4])+pow(yp+1,2)*(delta[i+3]+gamma[i+4]+2*beta[i+4])+pow(xp,2)+2*(beta[i+3]+beta[i+4]+delta[i+3]+gamma[i+4]*(yp+1)+delta[i+4]*yp)*xp))*Gausssum1d(0,xp+beta[i+3]+beta[i+4]+delta[i+3]+gamma[i+4]*(yp+1)+delta[i+4]*yp+gamma[i+5]+delta[i+5])*Kroneck(gamma[i+3]+delta[i+3]-gamma[i+4]-delta[i+4]+1)*Kroneck(alpha[i+5]+beta[i+5])))
			*(2.0*(0.125*pow(2.0,(pow(ypp-1,2)*(pow(xpp,2)*(gamma[j]+delta[j+1])+pow(xpp-1,2)*(gamma[j+1]+delta[j])))*(pow(yppp-1,2)*(pow(xppp,2)*(gamma[j+3]+delta[j+4])+pow(xppp-1,2)*(gamma[j+4]+delta[j+3]))))*(-I)*cexp(M_PI*I/2.0*(ypp*(delta[j]+delta[j+1])+pow(ypp+1,2)*(delta[j]+gamma[j+1]+2*beta[j+1])+pow(xpp,2)+2*(beta[j]+beta[j+1]+delta[j]+gamma[j+1]*(ypp+1)+delta[j+1]*ypp)*xpp))*Gausssum1d(0,xpp+beta[j]+beta[j+1]+delta[j]+gamma[j+1]*(ypp+1)+delta[j+1]*ypp+gamma[j+2]+delta[j+2])*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1]+1)*Kroneck(alpha[j+2]+beta[j+2]))
			  *(0.125*(-I)*cexp(M_PI*I/2.0*(yppp*(delta[j+3]+delta[j+4])+pow(yppp+1,2)*(delta[j+3]+gamma[j+4]+2*beta[j+4])+pow(xppp,2)+2*(beta[j+3]+beta[j+4]+delta[j+3]+gamma[j+4]*(yppp+1)+delta[j+4]*yppp)*xppp))*Gausssum1d(0,xppp+beta[j+3]+beta[j+4]+delta[j+3]+gamma[j+4]*(yppp+1)+delta[j+4]*yppp+gamma[j+5]+delta[j+5])*Kroneck(gamma[j+3]+delta[j+3]-gamma[j+4]-delta[j+4]+1)*Kroneck(alpha[j+5]+beta[j+5])));
		    }
		  }
		}
	      }
	    }
	  }
	}
      }

      
      // seventh term
      for(y=0; y<=1; y++) {
	for(x=(y*(delta[i]+delta[i+1]))%2; x<=(1+y*(gamma[i]+gamma[i+1]))%2; x++) {
	  for(yp=((gamma[i+3]+delta[i+4])*y)%2; yp<=(1+(gamma[i+3]+gamma[i+4])*y)%2; yp++) {
	    //**for(xp=0;xp<=(yp*(gamma[i+3]+gamma[i+4])+(yp+1)*(gamma[i+3]+delta[i+4]))%2; xp++) {
	    for(xp=yp*(beta[i+3]+alpha[i+4]+beta[i+4])%2;xp<=(yp*(beta[i+3]+alpha[i+4]+beta[i+4])+yp*(gamma[i+3]+gamma[i+4])+(yp+1)*(gamma[i+3]+delta[i+4]))%2; xp++) {
	      
	      //for(ypp=0; ypp<=1; ypp++) {
	      for(ypp=((gamma[j]+delta[j+1])*(y+xp))%2;ypp<=(1+(gamma[j]+gamma[j+1])*(y+xp))%2;ypp++) {
		//****for(ypp=((gamma[j]+delta[j+1])*(y+xp*(1+alpha[i+3]+beta[i+3])))%2;ypp<=(1+(gamma[j]+gamma[j+1])*(y+xp*(1+alpha[i+3]+beta[i+3])))%2;ypp++) {
		//**for(xpp=0;xpp<=(ypp*(gamma[j]+gamma[j+1])+(ypp+1)*(gamma[j]+delta[j+1]))%2; xpp++) {
		for(xpp=ypp*(beta[j]+alpha[j+1]+beta[j+1])%2;xpp<=(ypp*(beta[j]+alpha[j+1]+beta[j+1])+ypp*(gamma[j]+gamma[j+1])+(ypp+1)*(gamma[j]+delta[j+1]))%2; xpp++) {
		  //for(yppp=((gamma[j+3]+delta[j+4])*xpp)%2; yppp<=(1+(gamma[j+3]+gamma[j+4])*xpp)%2; yppp++) {
		  for(yppp=((gamma[j+3]+delta[j+4])*(y+xp+xpp))%2; yppp<=(1+(gamma[j+3]+gamma[j+4])*(y+xp+xpp))%2; yppp++) {
		  //****for(yppp=((gamma[j+3]+delta[j+4])*(y+xp*(1+alpha[i+3]+beta[i+3])+xpp*(1+alpha[j]+beta[j])))%2; yppp<=(1+(gamma[j+3]+gamma[j+4])*(y+xp*(1+alpha[i+3]+beta[i+3])+xpp*(1+alpha[j]+beta[j])))%2; yppp++) {
		    //**for(xppp=0;xppp<=(yppp*(gamma[j+3]+gamma[j+4])+(yppp+1)*(gamma[j+3]+delta[j+4]))%2; xppp++) {
		    for(xppp=yppp*(beta[j+3]+alpha[j+4]+beta[j+4])%2;xppp<=(yppp*(beta[j+3]+alpha[j+4]+beta[j+4])+yppp*(gamma[j+3]+gamma[j+4])+(yppp+1)*(gamma[j+3]+delta[j+4]))%2; xppp++) {
		      //summand += (2.0*(0.125*pow(2.0,(pow(y-1,2)*(pow(x,2)*(gamma[i]+delta[i+1])+pow(x-1,2)*(gamma[i+1]+delta[i])))*(1-yp*pow(gamma[i+3]-gamma[i+4],2)-pow(yp-1,2)*pow(gamma[i+3]-delta[i+4],2)))*(-I)*cexp(M_PI*I/2.0*(y*(delta[i]+delta[i+1])+pow(y+1,2)*(delta[i]+gamma[i+1]+2*beta[i+1])+pow(x,2)+2*(beta[i]+beta[i+1]+delta[i]+gamma[i+1]*(y+1)+delta[i+1]*y)*x))*Gausssum1d(0,x+beta[i]+beta[i+1]+delta[i]+gamma[i+1]*(y+1)+delta[i+1]*y+gamma[i+2]+delta[i+2])*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1]+1)*Kroneck(alpha[i+2]+beta[i+2]))
		      summand += 2.0*(2.0*(0.125*pow(2.0,(pow(y-1,2)*(pow(x,2)*(gamma[i]+delta[i+1])+pow(x-1,2)*(gamma[i+1]+delta[i])))*(1-yp*pow(gamma[i+3]-gamma[i+4],2)-pow(yp-1,2)*pow(gamma[i+3]-delta[i+4],2))*(1-ypp*pow(gamma[j]-gamma[j+1],2)-pow(ypp-1,2)*pow(gamma[j]-delta[j+1],2))*(1-yppp*pow(gamma[j+3]-gamma[j+4],2)-pow(yppp-1,2)*pow(gamma[j+3]-delta[j+4],2)))*(-I)*cexp(M_PI*I/2.0*(y*(delta[i]+delta[i+1])+pow(y+1,2)*(delta[i]+gamma[i+1]+2*beta[i+1])+pow(x,2)+2*(beta[i]+beta[i+1]+delta[i]+gamma[i+1]*(y+1)+delta[i+1]*y)*x))*Gausssum1d(0,x+beta[i]+beta[i+1]+delta[i]+gamma[i+1]*(y+1)+delta[i+1]*y+gamma[i+2]+delta[i+2])*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1]+1)*Kroneck(alpha[i+2]+beta[i+2]))
		*(0.125*cexp(M_PI*I/2.0*((delta[i+4]-gamma[i+3])*pow(yp+1,2)+2.0*(beta[i+3]+beta[i+4]+gamma[i+3]+delta[i+4])*xp*pow(yp+1,2)+2.0*(delta[i+3]+delta[i+4]+beta[i+3]+beta[i+4])*xp*yp+(2.0*beta[i+3]+3.0*delta[i+3]+delta[i+4])*yp))*Gausssum1d(0.0,beta[i+5])*Kroneck(gamma[i+3]+delta[i+3]-gamma[i+4]-delta[i+4])*Kroneck(gamma[i+5]+delta[i+5]) 
		  + 0.125*cexp(M_PI*I/2.0*((delta[i+4]-gamma[i+3])*pow(yp+1,2)+2.0*(beta[i+3]+beta[i+4]+gamma[i+3]+delta[i+4])*xp*pow(yp+1,2)+2.0*(delta[i+3]+delta[i+4]+beta[i+3]+beta[i+4])*xp*yp+(2.0*beta[i+3]+3.0*delta[i+3]+delta[i+4])*yp))*csqrt(-I)*Gausssum1d(gamma[i+5]+delta[i+5],0)*Kroneck(gamma[i+3]+delta[i+3]-gamma[i+4]-delta[i+4])*Kroneck(alpha[i+5]+beta[i+5])))
			//*(2.0*(0.125*pow(2.0,(1-ypp*pow(gamma[j]-gamma[j+1],2)-pow(ypp-1,2)*pow(gamma[j]-delta[j+1],2))*(1-yppp*pow(gamma[j+3]-gamma[j+4],2)-pow(yppp-1,2)*pow(gamma[j+3]-delta[j+4],2)))*cexp(M_PI*I/2.0*((delta[j+1]-gamma[j])*pow(ypp+1,2)+2.0*(beta[j]+beta[j+1]+gamma[j]+delta[j+1])*xpp*pow(ypp+1,2)+2.0*(delta[j]+delta[j+1]+beta[j]+beta[j+1])*xpp*ypp+(2.0*beta[j]+3.0*delta[j]+delta[j+1])*ypp))*Gausssum1d(0.0,beta[j+2])*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1])*Kroneck(gamma[j+2]+delta[j+2]) 
			*(2.0*(0.125*cexp(M_PI*I/2.0*((delta[j+1]-gamma[j])*pow(ypp+1,2)+2.0*(beta[j]+beta[j+1]+gamma[j]+delta[j+1])*xpp*pow(ypp+1,2)+2.0*(delta[j]+delta[j+1]+beta[j]+beta[j+1])*xpp*ypp+(2.0*beta[j]+3.0*delta[j]+delta[j+1])*ypp))*Gausssum1d(0.0,beta[j+2])*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1])*Kroneck(gamma[j+2]+delta[j+2]) 
			       //+ 0.125*pow(2.0,(1-ypp*pow(gamma[j]-gamma[j+1],2)-pow(ypp-1,2)*pow(gamma[j]-delta[j+1],2))*(1-yppp*pow(gamma[j+3]-gamma[j+4],2)-pow(yppp-1,2)*pow(gamma[j+3]-delta[j+4],2)))*cexp(M_PI*I/2.0*((delta[j+1]-gamma[j])*pow(ypp+1,2)+2.0*(beta[j]+beta[j+1]+gamma[j]+delta[j+1])*xpp*pow(ypp+1,2)+2.0*(delta[j]+delta[j+1]+beta[j]+beta[j+1])*xpp*ypp+(2.0*beta[j]+3.0*delta[j]+delta[j+1])*ypp))*csqrt(-I)*Gausssum1d(gamma[j+2]+delta[j+2],0)*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1])*Kroneck(alpha[j+2]+beta[j+2]))
			      + 0.125*cexp(M_PI*I/2.0*((delta[j+1]-gamma[j])*pow(ypp+1,2)+2.0*(beta[j]+beta[j+1]+gamma[j]+delta[j+1])*xpp*pow(ypp+1,2)+2.0*(delta[j]+delta[j+1]+beta[j]+beta[j+1])*xpp*ypp+(2.0*beta[j]+3.0*delta[j]+delta[j+1])*ypp))*csqrt(-I)*Gausssum1d(gamma[j+2]+delta[j+2],0)*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1])*Kroneck(alpha[j+2]+beta[j+2]))
			*(0.125*cexp(M_PI*I/2.0*((delta[j+4]-gamma[j+3])*pow(yppp+1,2)+2.0*(beta[j+3]+beta[j+4]+gamma[j+3]+delta[j+4])*xppp*pow(yppp+1,2)+2.0*(delta[j+3]+delta[j+4]+beta[j+3]+beta[j+4])*xppp*yppp+(2.0*beta[j+3]+3.0*delta[j+3]+delta[j+4])*yppp))*Gausssum1d(0.0,beta[j+5])*Kroneck(gamma[j+3]+delta[j+3]-gamma[j+4]-delta[j+4])*Kroneck(gamma[j+5]+delta[j+5]) 
			  + 0.125*cexp(M_PI*I/2.0*((delta[j+4]-gamma[j+3])*pow(yppp+1,2)+2.0*(beta[j+3]+beta[j+4]+gamma[j+3]+delta[j+4])*xppp*pow(yppp+1,2)+2.0*(delta[j+3]+delta[j+4]+beta[j+3]+beta[j+4])*xppp*yppp+(2.0*beta[j+3]+3.0*delta[j+3]+delta[j+4])*yppp))*csqrt(-I)*Gausssum1d(gamma[j+5]+delta[j+5],0)*Kroneck(gamma[j+3]+delta[j+3]-gamma[j+4]-delta[j+4])*Kroneck(alpha[j+5]+beta[j+5])));
		    }
		  }
		}
	      }
	      for(ypp=0; ypp<=1; ypp++) {
		//**for(xpp=0;xpp<=(ypp*(gamma[j]+gamma[j+1])+(ypp+1)*(gamma[j]+delta[j+1]))%2; xpp++) {
		for(xpp=ypp*(beta[j]+alpha[j+1]+beta[j+1])%2;xpp<=(ypp*(beta[j]+alpha[j+1]+beta[j+1])+ypp*(gamma[j]+gamma[j+1])+(ypp+1)*(gamma[j]+delta[j+1]))%2; xpp++) {
		  for(yppp=0; yppp<=(1+alpha[j+5])%2; yppp++) {
		    for(xppp=0;xppp<=(1+beta[j+5])%2; xppp++) {
		      summand += (2.0*(0.125*pow(2.0,(pow(y-1,2)*(pow(x,2)*(gamma[i]+delta[i+1])+pow(x-1,2)*(gamma[i+1]+delta[i])))*(1-yp*pow(gamma[i+3]-gamma[i+4],2)-pow(yp-1,2)*pow(gamma[i+3]-delta[i+4],2)))*(-I)*cexp(M_PI*I/2.0*(y*(delta[i]+delta[i+1])+pow(y+1,2)*(delta[i]+gamma[i+1]+2*beta[i+1])+pow(x,2)+2*(beta[i]+beta[i+1]+delta[i]+gamma[i+1]*(y+1)+delta[i+1]*y)*x))*Gausssum1d(0,x+beta[i]+beta[i+1]+delta[i]+gamma[i+1]*(y+1)+delta[i+1]*y+gamma[i+2]+delta[i+2])*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1]+1)*Kroneck(alpha[i+2]+beta[i+2]))
		*(0.125*cexp(M_PI*I/2.0*((delta[i+4]-gamma[i+3])*pow(yp+1,2)+2.0*(beta[i+3]+beta[i+4]+gamma[i+3]+delta[i+4])*xp*pow(yp+1,2)+2.0*(delta[i+3]+delta[i+4]+beta[i+3]+beta[i+4])*xp*yp+(2.0*beta[i+3]+3.0*delta[i+3]+delta[i+4])*yp))*Gausssum1d(0.0,beta[i+5])*Kroneck(gamma[i+3]+delta[i+3]-gamma[i+4]-delta[i+4])*Kroneck(gamma[i+5]+delta[i+5]) 
		  + 0.125*cexp(M_PI*I/2.0*((delta[i+4]-gamma[i+3])*pow(yp+1,2)+2.0*(beta[i+3]+beta[i+4]+gamma[i+3]+delta[i+4])*xp*pow(yp+1,2)+2.0*(delta[i+3]+delta[i+4]+beta[i+3]+beta[i+4])*xp*yp+(2.0*beta[i+3]+3.0*delta[i+3]+delta[i+4])*yp))*csqrt(-I)*Gausssum1d(gamma[i+5]+delta[i+5],0)*Kroneck(gamma[i+3]+delta[i+3]-gamma[i+4]-delta[i+4])*Kroneck(alpha[i+5]+beta[i+5])))
			*((0.125*pow(2.0,1-ypp*pow(gamma[j]-gamma[j+1],2)-pow(ypp-1,2)*pow(gamma[j]-delta[j+1],2))*cexp(M_PI*I/2.0*((delta[j+1]-gamma[j])*pow(ypp+1,2)+2.0*(beta[j]+beta[j+1]+gamma[j]+delta[j+1])*xpp*pow(ypp+1,2)+2.0*(delta[j]+delta[j+1]+beta[j]+beta[j+1])*xpp*ypp+(2.0*beta[j]+3.0*delta[j]+delta[j+1])*ypp))*Gausssum1d(0.0,beta[j+2])*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1])*Kroneck(gamma[j+2]+delta[j+2]) 
				  + 0.125*pow(2.0,1-ypp*pow(gamma[j]-gamma[j+1],2)-pow(ypp-1,2)*pow(gamma[j]-delta[j+1],2))*cexp(M_PI*I/2.0*((delta[j+1]-gamma[j])*pow(ypp+1,2)+2.0*(beta[j]+beta[j+1]+gamma[j]+delta[j+1])*xpp*pow(ypp+1,2)+2.0*(delta[j]+delta[j+1]+beta[j]+beta[j+1])*xpp*ypp+(2.0*beta[j]+3.0*delta[j]+delta[j+1])*ypp))*csqrt(-I)*Gausssum1d(gamma[j+2]+delta[j+2],0)*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1])*Kroneck(alpha[j+2]+beta[j+2]))
			  *(0.125*2.0*csqrt(-I)*cexp(M_PI*I/2.0*(2.0*beta[j+5]*yppp+pow(xppp+1,2)*(delta[j+3]+gamma[j+4]+2.0*beta[j+4])+xppp*(delta[j+3]+delta[j+4])))*Gausssum1d(1,beta[j+3]+beta[j+4]+delta[j+3]+(xppp+1)*gamma[j+4]+xppp*delta[j+4])*Kroneck(gamma[j+3]+delta[j+3]-gamma[j+4]-delta[j+4]+1)*Kroneck(gamma[j+5]+delta[j+5])));
		    }
		  }
		}
	      }

	      //for(ypp=0; ypp<=1; ypp++) {
	      for(ypp=((gamma[j]+delta[j+1])*(y+xp))%2;ypp<=(1+(gamma[j]+gamma[j+1])*(y+xp))%2;ypp++) {
	      //****for(ypp=((gamma[j]+delta[j+1])*(y+xp*(1+alpha[i+3]+beta[i+3])))%2;ypp<=(1+(gamma[j]+gamma[j+1])*(y+xp*(1+alpha[i+3]+beta[i+3])))%2;ypp++) {
		//**for(xpp=0;xpp<=(ypp*(gamma[j]+gamma[j+1])+(ypp+1)*(gamma[j]+delta[j+1]))%2; xpp++) {
		for(xpp=ypp*(beta[j]+alpha[j+1]+beta[j+1])%2;xpp<=(ypp*(beta[j]+alpha[j+1]+beta[j+1])+ypp*(gamma[j]+gamma[j+1])+(ypp+1)*(gamma[j]+delta[j+1]))%2; xpp++) {
		  //for(yppp=xpp; yppp<=1; yppp++) {
		  //**for(yppp=(y+xp+xpp)%2; yppp<=1; yppp++) {
		  for(yppp=(y+xp*(1+alpha[i+3]+beta[i+3])+xpp*(1+alpha[j]+beta[j]))%2; yppp<=1; yppp++) {
		    //for(xppp=(yppp*(delta[j+3]+delta[j+4])+xpp)%2;xppp<=(1+yppp*(gamma[j+3]+gamma[j+4])+xpp)%2; xppp++) {
		    //**for(xppp=(yppp*(delta[j+3]+delta[j+4])+(y+xp+xpp))%2;xppp<=(1+yppp*(gamma[j+3]+gamma[j+4])+(y+xp+xpp))%2; xppp++) {
		    for(xppp=(yppp*(delta[j+3]+delta[j+4])+(y+xp*(1+alpha[i+3]+beta[i+3])+xpp*(1+alpha[j]+beta[j])))%2;xppp<=(1+yppp*(gamma[j+3]+gamma[j+4])+(y+xp*(1+alpha[i+3]+beta[i+3])+xpp*(1+alpha[j]+beta[j])))%2; xppp++) {
		      //summand += (2.0*(0.125*pow(2.0,(pow(y-1,2)*(pow(x,2)*(gamma[i]+delta[i+1])+pow(x-1,2)*(gamma[i+1]+delta[i])))*(1-yp*pow(gamma[i+3]-gamma[i+4],2)-pow(yp-1,2)*pow(gamma[i+3]-delta[i+4],2)))*(-I)*cexp(M_PI*I/2.0*(y*(delta[i]+delta[i+1])+pow(y+1,2)*(delta[i]+gamma[i+1]+2*beta[i+1])+pow(x,2)+2*(beta[i]+beta[i+1]+delta[i]+gamma[i+1]*(y+1)+delta[i+1]*y)*x))*Gausssum1d(0,x+beta[i]+beta[i+1]+delta[i]+gamma[i+1]*(y+1)+delta[i+1]*y+gamma[i+2]+delta[i+2])*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1]+1)*Kroneck(alpha[i+2]+beta[i+2]))
		      summand += 2.0*(2.0*(0.125*pow(2.0,(pow(y-1,2)*(pow(x,2)*(gamma[i]+delta[i+1])+pow(x-1,2)*(gamma[i+1]+delta[i])))*(1-yp*pow(gamma[i+3]-gamma[i+4],2)-pow(yp-1,2)*pow(gamma[i+3]-delta[i+4],2))*(1-ypp*pow(gamma[j]-gamma[j+1],2)-pow(ypp-1,2)*pow(gamma[j]-delta[j+1],2))*(pow(yppp-1,2)*(pow(xppp,2)*(gamma[j+3]+delta[j+4])+pow(xppp-1,2)*(gamma[j+4]+delta[j+3]))))*(-I)*cexp(M_PI*I/2.0*(y*(delta[i]+delta[i+1])+pow(y+1,2)*(delta[i]+gamma[i+1]+2*beta[i+1])+pow(x,2)+2*(beta[i]+beta[i+1]+delta[i]+gamma[i+1]*(y+1)+delta[i+1]*y)*x))*Gausssum1d(0,x+beta[i]+beta[i+1]+delta[i]+gamma[i+1]*(y+1)+delta[i+1]*y+gamma[i+2]+delta[i+2])*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1]+1)*Kroneck(alpha[i+2]+beta[i+2]))
		*(0.125*cexp(M_PI*I/2.0*((delta[i+4]-gamma[i+3])*pow(yp+1,2)+2.0*(beta[i+3]+beta[i+4]+gamma[i+3]+delta[i+4])*xp*pow(yp+1,2)+2.0*(delta[i+3]+delta[i+4]+beta[i+3]+beta[i+4])*xp*yp+(2.0*beta[i+3]+3.0*delta[i+3]+delta[i+4])*yp))*Gausssum1d(0.0,beta[i+5])*Kroneck(gamma[i+3]+delta[i+3]-gamma[i+4]-delta[i+4])*Kroneck(gamma[i+5]+delta[i+5]) 
		  + 0.125*cexp(M_PI*I/2.0*((delta[i+4]-gamma[i+3])*pow(yp+1,2)+2.0*(beta[i+3]+beta[i+4]+gamma[i+3]+delta[i+4])*xp*pow(yp+1,2)+2.0*(delta[i+3]+delta[i+4]+beta[i+3]+beta[i+4])*xp*yp+(2.0*beta[i+3]+3.0*delta[i+3]+delta[i+4])*yp))*csqrt(-I)*Gausssum1d(gamma[i+5]+delta[i+5],0)*Kroneck(gamma[i+3]+delta[i+3]-gamma[i+4]-delta[i+4])*Kroneck(alpha[i+5]+beta[i+5])))
			//*(2.0*(0.125*pow(2.0,(1-ypp*pow(gamma[j]-gamma[j+1],2)-pow(ypp-1,2)*pow(gamma[j]-delta[j+1],2))*(pow(yppp-1,2)*(pow(xppp,2)*(gamma[j+3]+delta[j+4])+pow(xppp-1,2)*(gamma[j+4]+delta[j+3]))))*cexp(M_PI*I/2.0*((delta[j+1]-gamma[j])*pow(ypp+1,2)+2.0*(beta[j]+beta[j+1]+gamma[j]+delta[j+1])*xpp*pow(ypp+1,2)+2.0*(delta[j]+delta[j+1]+beta[j]+beta[j+1])*xpp*ypp+(2.0*beta[j]+3.0*delta[j]+delta[j+1])*ypp))*Gausssum1d(0.0,beta[j+2])*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1])*Kroneck(gamma[j+2]+delta[j+2]) 
			*(2.0*(0.125*cexp(M_PI*I/2.0*((delta[j+1]-gamma[j])*pow(ypp+1,2)+2.0*(beta[j]+beta[j+1]+gamma[j]+delta[j+1])*xpp*pow(ypp+1,2)+2.0*(delta[j]+delta[j+1]+beta[j]+beta[j+1])*xpp*ypp+(2.0*beta[j]+3.0*delta[j]+delta[j+1])*ypp))*Gausssum1d(0.0,beta[j+2])*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1])*Kroneck(gamma[j+2]+delta[j+2]) 
			       //+ 0.125*pow(2.0,(1-ypp*pow(gamma[j]-gamma[j+1],2)-pow(ypp-1,2)*pow(gamma[j]-delta[j+1],2))*(pow(yppp-1,2)*(pow(xppp,2)*(gamma[j+3]+delta[j+4])+pow(xppp-1,2)*(gamma[j+4]+delta[j+3]))))*cexp(M_PI*I/2.0*((delta[j+1]-gamma[j])*pow(ypp+1,2)+2.0*(beta[j]+beta[j+1]+gamma[j]+delta[j+1])*xpp*pow(ypp+1,2)+2.0*(delta[j]+delta[j+1]+beta[j]+beta[j+1])*xpp*ypp+(2.0*beta[j]+3.0*delta[j]+delta[j+1])*ypp))*csqrt(-I)*Gausssum1d(gamma[j+2]+delta[j+2],0)*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1])*Kroneck(alpha[j+2]+beta[j+2]))
			       + 0.125*cexp(M_PI*I/2.0*((delta[j+1]-gamma[j])*pow(ypp+1,2)+2.0*(beta[j]+beta[j+1]+gamma[j]+delta[j+1])*xpp*pow(ypp+1,2)+2.0*(delta[j]+delta[j+1]+beta[j]+beta[j+1])*xpp*ypp+(2.0*beta[j]+3.0*delta[j]+delta[j+1])*ypp))*csqrt(-I)*Gausssum1d(gamma[j+2]+delta[j+2],0)*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1])*Kroneck(alpha[j+2]+beta[j+2]))
			  *(0.125*(-I)*cexp(M_PI*I/2.0*(yppp*(delta[j+3]+delta[j+4])+pow(yppp+1,2)*(delta[j+3]+gamma[j+4]+2*beta[j+4])+pow(xppp,2)+2*(beta[j+3]+beta[j+4]+delta[j+3]+gamma[j+4]*(yppp+1)+delta[j+4]*yppp)*xppp))*Gausssum1d(0,xppp+beta[j+3]+beta[j+4]+delta[j+3]+gamma[j+4]*(yppp+1)+delta[j+4]*yppp+gamma[j+5]+delta[j+5])*Kroneck(gamma[j+3]+delta[j+3]-gamma[j+4]-delta[j+4]+1)*Kroneck(alpha[j+5]+beta[j+5])));
		    }
		  }
		}
	      }

	      for(ypp=0; ypp<=(1+alpha[j+2])%2; ypp++) {
		for(xpp=0; xpp<=(1+beta[j+2])%2; xpp++) {
		  for(yppp=0; yppp<=1; yppp++) {
		    //**for(xppp=0;xppp<=(yppp*(gamma[j+3]+gamma[j+4])+(yppp+1)*(gamma[j+3]+delta[j+4]))%2; xppp++) {
		    for(xppp=yppp*(beta[j+3]+alpha[j+4]+beta[j+4])%2;xppp<=(yppp*(beta[j+3]+alpha[j+4]+beta[j+4])+yppp*(gamma[j+3]+gamma[j+4])+(yppp+1)*(gamma[j+3]+delta[j+4]))%2; xppp++) {
		      summand += (2.0*(0.125*pow(2.0,(pow(y-1,2)*(pow(x,2)*(gamma[i]+delta[i+1])+pow(x-1,2)*(gamma[i+1]+delta[i])))*(1-yp*pow(gamma[i+3]-gamma[i+4],2)-pow(yp-1,2)*pow(gamma[i+3]-delta[i+4],2)))*(-I)*cexp(M_PI*I/2.0*(y*(delta[i]+delta[i+1])+pow(y+1,2)*(delta[i]+gamma[i+1]+2*beta[i+1])+pow(x,2)+2*(beta[i]+beta[i+1]+delta[i]+gamma[i+1]*(y+1)+delta[i+1]*y)*x))*Gausssum1d(0,x+beta[i]+beta[i+1]+delta[i]+gamma[i+1]*(y+1)+delta[i+1]*y+gamma[i+2]+delta[i+2])*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1]+1)*Kroneck(alpha[i+2]+beta[i+2]))
		*(0.125*cexp(M_PI*I/2.0*((delta[i+4]-gamma[i+3])*pow(yp+1,2)+2.0*(beta[i+3]+beta[i+4]+gamma[i+3]+delta[i+4])*xp*pow(yp+1,2)+2.0*(delta[i+3]+delta[i+4]+beta[i+3]+beta[i+4])*xp*yp+(2.0*beta[i+3]+3.0*delta[i+3]+delta[i+4])*yp))*Gausssum1d(0.0,beta[i+5])*Kroneck(gamma[i+3]+delta[i+3]-gamma[i+4]-delta[i+4])*Kroneck(gamma[i+5]+delta[i+5]) 
		  + 0.125*cexp(M_PI*I/2.0*((delta[i+4]-gamma[i+3])*pow(yp+1,2)+2.0*(beta[i+3]+beta[i+4]+gamma[i+3]+delta[i+4])*xp*pow(yp+1,2)+2.0*(delta[i+3]+delta[i+4]+beta[i+3]+beta[i+4])*xp*yp+(2.0*beta[i+3]+3.0*delta[i+3]+delta[i+4])*yp))*csqrt(-I)*Gausssum1d(gamma[i+5]+delta[i+5],0)*Kroneck(gamma[i+3]+delta[i+3]-gamma[i+4]-delta[i+4])*Kroneck(alpha[i+5]+beta[i+5])))
			*((0.125*2.0*csqrt(-I)*cexp(M_PI*I/2.0*(2.0*beta[j+2]*ypp+pow(xpp+1,2)*(delta[j]+gamma[j+1]+2.0*beta[j+1])+xpp*(delta[j]+delta[j+1])))*Gausssum1d(1,beta[j]+beta[j+1]+delta[j]+(xpp+1)*gamma[j+1]+xpp*delta[j+1])*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1]+1)*Kroneck(gamma[j+2]+delta[j+2]))
			  *(0.125*pow(2.0,1-yppp*pow(gamma[j+3]-gamma[j+4],2)-pow(yppp-1,2)*pow(gamma[j+3]-delta[j+4],2))*cexp(M_PI*I/2.0*((delta[j+4]-gamma[j+3])*pow(yppp+1,2)+2.0*(beta[j+3]+beta[j+4]+gamma[j+3]+delta[j+4])*xppp*pow(yppp+1,2)+2.0*(delta[j+3]+delta[j+4]+beta[j+3]+beta[j+4])*xppp*yppp+(2.0*beta[j+3]+3.0*delta[j+3]+delta[j+4])*yppp))*Gausssum1d(0.0,beta[j+5])*Kroneck(gamma[j+3]+delta[j+3]-gamma[j+4]-delta[j+4])*Kroneck(gamma[j+5]+delta[j+5]) 
			    + 0.125*pow(2.0,1-yppp*pow(gamma[j+3]-gamma[j+4],2)-pow(yppp-1,2)*pow(gamma[j+3]-delta[j+4],2))*cexp(M_PI*I/2.0*((delta[j+4]-gamma[j+3])*pow(yppp+1,2)+2.0*(beta[j+3]+beta[j+4]+gamma[j+3]+delta[j+4])*xppp*pow(yppp+1,2)+2.0*(delta[j+3]+delta[j+4]+beta[j+3]+beta[j+4])*xppp*yppp+(2.0*beta[j+3]+3.0*delta[j+3]+delta[j+4])*yppp))*csqrt(-I)*Gausssum1d(gamma[j+5]+delta[j+5],0)*Kroneck(gamma[j+3]+delta[j+3]-gamma[j+4]-delta[j+4])*Kroneck(alpha[j+5]+beta[j+5])));
		    }
		  }
		  for(yppp=0; yppp<=(1+alpha[j+5])%2; yppp++) {
		    for(xppp=0;xppp<=(1+beta[j+5])%2; xppp++) {
		      summand += (2.0*(0.125*pow(2.0,(pow(y-1,2)*(pow(x,2)*(gamma[i]+delta[i+1])+pow(x-1,2)*(gamma[i+1]+delta[i])))*(1-yp*pow(gamma[i+3]-gamma[i+4],2)-pow(yp-1,2)*pow(gamma[i+3]-delta[i+4],2)))*(-I)*cexp(M_PI*I/2.0*(y*(delta[i]+delta[i+1])+pow(y+1,2)*(delta[i]+gamma[i+1]+2*beta[i+1])+pow(x,2)+2*(beta[i]+beta[i+1]+delta[i]+gamma[i+1]*(y+1)+delta[i+1]*y)*x))*Gausssum1d(0,x+beta[i]+beta[i+1]+delta[i]+gamma[i+1]*(y+1)+delta[i+1]*y+gamma[i+2]+delta[i+2])*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1]+1)*Kroneck(alpha[i+2]+beta[i+2]))
		*(0.125*cexp(M_PI*I/2.0*((delta[i+4]-gamma[i+3])*pow(yp+1,2)+2.0*(beta[i+3]+beta[i+4]+gamma[i+3]+delta[i+4])*xp*pow(yp+1,2)+2.0*(delta[i+3]+delta[i+4]+beta[i+3]+beta[i+4])*xp*yp+(2.0*beta[i+3]+3.0*delta[i+3]+delta[i+4])*yp))*Gausssum1d(0.0,beta[i+5])*Kroneck(gamma[i+3]+delta[i+3]-gamma[i+4]-delta[i+4])*Kroneck(gamma[i+5]+delta[i+5]) 
		  + 0.125*cexp(M_PI*I/2.0*((delta[i+4]-gamma[i+3])*pow(yp+1,2)+2.0*(beta[i+3]+beta[i+4]+gamma[i+3]+delta[i+4])*xp*pow(yp+1,2)+2.0*(delta[i+3]+delta[i+4]+beta[i+3]+beta[i+4])*xp*yp+(2.0*beta[i+3]+3.0*delta[i+3]+delta[i+4])*yp))*csqrt(-I)*Gausssum1d(gamma[i+5]+delta[i+5],0)*Kroneck(gamma[i+3]+delta[i+3]-gamma[i+4]-delta[i+4])*Kroneck(alpha[i+5]+beta[i+5])))
			*((0.125*2.0*csqrt(-I)*cexp(M_PI*I/2.0*(2.0*beta[j+2]*ypp+pow(xpp+1,2)*(delta[j]+gamma[j+1]+2.0*beta[j+1])+xpp*(delta[j]+delta[j+1])))*Gausssum1d(1,beta[j]+beta[j+1]+delta[j]+(xpp+1)*gamma[j+1]+xpp*delta[j+1])*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1]+1)*Kroneck(gamma[j+2]+delta[j+2]))
			  *(0.125*2.0*csqrt(-I)*cexp(M_PI*I/2.0*(2.0*beta[j+5]*yppp+pow(xppp+1,2)*(delta[j+3]+gamma[j+4]+2.0*beta[j+4])+xppp*(delta[j+3]+delta[j+4])))*Gausssum1d(1,beta[j+3]+beta[j+4]+delta[j+3]+(xppp+1)*gamma[j+4]+xppp*delta[j+4])*Kroneck(gamma[j+3]+delta[j+3]-gamma[j+4]-delta[j+4]+1)*Kroneck(gamma[j+5]+delta[j+5])));
		    }
		  }
		  for(yppp=0; yppp<=1; yppp++) {
		    for(xppp=(yppp*(delta[j+3]+delta[j+4]))%2;xppp<=(1+yppp*(gamma[j+3]+gamma[j+4]))%2; xppp++) {
		      summand += (2.0*(0.125*pow(2.0,(pow(y-1,2)*(pow(x,2)*(gamma[i]+delta[i+1])+pow(x-1,2)*(gamma[i+1]+delta[i])))*(1-yp*pow(gamma[i+3]-gamma[i+4],2)-pow(yp-1,2)*pow(gamma[i+3]-delta[i+4],2)))*(-I)*cexp(M_PI*I/2.0*(y*(delta[i]+delta[i+1])+pow(y+1,2)*(delta[i]+gamma[i+1]+2*beta[i+1])+pow(x,2)+2*(beta[i]+beta[i+1]+delta[i]+gamma[i+1]*(y+1)+delta[i+1]*y)*x))*Gausssum1d(0,x+beta[i]+beta[i+1]+delta[i]+gamma[i+1]*(y+1)+delta[i+1]*y+gamma[i+2]+delta[i+2])*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1]+1)*Kroneck(alpha[i+2]+beta[i+2]))
		*(0.125*cexp(M_PI*I/2.0*((delta[i+4]-gamma[i+3])*pow(yp+1,2)+2.0*(beta[i+3]+beta[i+4]+gamma[i+3]+delta[i+4])*xp*pow(yp+1,2)+2.0*(delta[i+3]+delta[i+4]+beta[i+3]+beta[i+4])*xp*yp+(2.0*beta[i+3]+3.0*delta[i+3]+delta[i+4])*yp))*Gausssum1d(0.0,beta[i+5])*Kroneck(gamma[i+3]+delta[i+3]-gamma[i+4]-delta[i+4])*Kroneck(gamma[i+5]+delta[i+5]) 
		  + 0.125*cexp(M_PI*I/2.0*((delta[i+4]-gamma[i+3])*pow(yp+1,2)+2.0*(beta[i+3]+beta[i+4]+gamma[i+3]+delta[i+4])*xp*pow(yp+1,2)+2.0*(delta[i+3]+delta[i+4]+beta[i+3]+beta[i+4])*xp*yp+(2.0*beta[i+3]+3.0*delta[i+3]+delta[i+4])*yp))*csqrt(-I)*Gausssum1d(gamma[i+5]+delta[i+5],0)*Kroneck(gamma[i+3]+delta[i+3]-gamma[i+4]-delta[i+4])*Kroneck(alpha[i+5]+beta[i+5])))
			*((0.125*2.0*csqrt(-I)*cexp(M_PI*I/2.0*(2.0*beta[j+2]*ypp+pow(xpp+1,2)*(delta[j]+gamma[j+1]+2.0*beta[j+1])+xpp*(delta[j]+delta[j+1])))*Gausssum1d(1,beta[j]+beta[j+1]+delta[j]+(xpp+1)*gamma[j+1]+xpp*delta[j+1])*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1]+1)*Kroneck(gamma[j+2]+delta[j+2]))
			  *(0.125*(-I)*pow(2.0,(pow(yppp-1,2)*(pow(xppp,2)*(gamma[j+3]+delta[j+4])+pow(xppp-1,2)*(gamma[j+4]+delta[j+3]))))*cexp(M_PI*I/2.0*(yppp*(delta[j+3]+delta[j+4])+pow(yppp+1,2)*(delta[j+3]+gamma[j+4]+2*beta[j+4])+pow(xppp,2)+2*(beta[j+3]+beta[j+4]+delta[j+3]+gamma[j+4]*(yppp+1)+delta[j+4]*yppp)*xppp))*Gausssum1d(0,xppp+beta[j+3]+beta[j+4]+delta[j+3]+gamma[j+4]*(yppp+1)+delta[j+4]*yppp+gamma[j+5]+delta[j+5])*Kroneck(gamma[j+3]+delta[j+3]-gamma[j+4]-delta[j+4]+1)*Kroneck(alpha[j+5]+beta[j+5])));
		    }
		  }
		}
	      }

	      //for(ypp=0; ypp<=1; ypp++) {
	      //**for(ypp=(y+xp)%2; ypp<=1; ypp++) {
	      for(ypp=(y+xp*(1+alpha[i+3]+beta[i+3]))%2; ypp<=1; ypp++) {
		//for(xpp=(ypp*(delta[j]+delta[j+1]))%2; xpp<=(1+ypp*(gamma[j]+gamma[j+1]))%2; xpp++) {
		//**for(xpp=(ypp*(delta[j]+delta[j+1])+y+xp)%2; xpp<=(1+ypp*(gamma[j]+gamma[j+1])+y+xp)%2; xpp++) {
		for(xpp=(ypp*(delta[j]+delta[j+1])+y+xp*(1+alpha[i+3]+beta[i+3]))%2; xpp<=(1+ypp*(gamma[j]+gamma[j+1])+y+xp*(1+alpha[i+3]+beta[i+3]))%2; xpp++) {
		  //for(yppp=((gamma[j+3]+delta[j+4])*ypp)%2; yppp<=(1+(gamma[j+3]+gamma[j+4])*ypp)%2; yppp++) {
		  for(yppp=((gamma[j+3]+delta[j+4])*(y+xp+ypp))%2; yppp<=(1+(gamma[j+3]+gamma[j+4])*(y+xp+ypp))%2; yppp++) {
		    //****for(yppp=((gamma[j+3]+delta[j+4])*(y+xp*(1+alpha[i+3]+beta[i+3])+ypp))%2; yppp<=(1+(gamma[j+3]+gamma[j+4])*(y+xp*(1+alpha[i+3]+beta[i+3])+ypp))%2; yppp++) {
		    //**for(xppp=0;xppp<=(yppp*(gamma[j+3]+gamma[j+4])+(yppp+1)*(gamma[j+3]+delta[j+4]))%2; xppp++) {
		    for(xppp=yppp*(beta[j+3]+alpha[j+4]+beta[j+4])%2;xppp<=(yppp*(beta[j+3]+alpha[j+4]+beta[j+4])+yppp*(gamma[j+3]+gamma[j+4])+(yppp+1)*(gamma[j+3]+delta[j+4]))%2; xppp++) {
		      //summand += (2.0*(0.125*pow(2.0,(pow(y-1,2)*(pow(x,2)*(gamma[i]+delta[i+1])+pow(x-1,2)*(gamma[i+1]+delta[i])))*(1-yp*pow(gamma[i+3]-gamma[i+4],2)-pow(yp-1,2)*pow(gamma[i+3]-delta[i+4],2)))*(-I)*cexp(M_PI*I/2.0*(y*(delta[i]+delta[i+1])+pow(y+1,2)*(delta[i]+gamma[i+1]+2*beta[i+1])+pow(x,2)+2*(beta[i]+beta[i+1]+delta[i]+gamma[i+1]*(y+1)+delta[i+1]*y)*x))*Gausssum1d(0,x+beta[i]+beta[i+1]+delta[i]+gamma[i+1]*(y+1)+delta[i+1]*y+gamma[i+2]+delta[i+2])*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1]+1)*Kroneck(alpha[i+2]+beta[i+2]))
		      summand += 2.0*(2.0*(0.125*pow(2.0,(pow(y-1,2)*(pow(x,2)*(gamma[i]+delta[i+1])+pow(x-1,2)*(gamma[i+1]+delta[i])))*(1-yp*pow(gamma[i+3]-gamma[i+4],2)-pow(yp-1,2)*pow(gamma[i+3]-delta[i+4],2))*(pow(ypp-1,2)*(pow(xpp,2)*(gamma[j]+delta[j+1])+pow(xpp-1,2)*(gamma[j+1]+delta[j])))*(1-yppp*pow(gamma[j+3]-gamma[j+4],2)-pow(yppp-1,2)*pow(gamma[j+3]-delta[j+4],2)))*(-I)*cexp(M_PI*I/2.0*(y*(delta[i]+delta[i+1])+pow(y+1,2)*(delta[i]+gamma[i+1]+2*beta[i+1])+pow(x,2)+2*(beta[i]+beta[i+1]+delta[i]+gamma[i+1]*(y+1)+delta[i+1]*y)*x))*Gausssum1d(0,x+beta[i]+beta[i+1]+delta[i]+gamma[i+1]*(y+1)+delta[i+1]*y+gamma[i+2]+delta[i+2])*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1]+1)*Kroneck(alpha[i+2]+beta[i+2]))
		*(0.125*cexp(M_PI*I/2.0*((delta[i+4]-gamma[i+3])*pow(yp+1,2)+2.0*(beta[i+3]+beta[i+4]+gamma[i+3]+delta[i+4])*xp*pow(yp+1,2)+2.0*(delta[i+3]+delta[i+4]+beta[i+3]+beta[i+4])*xp*yp+(2.0*beta[i+3]+3.0*delta[i+3]+delta[i+4])*yp))*Gausssum1d(0.0,beta[i+5])*Kroneck(gamma[i+3]+delta[i+3]-gamma[i+4]-delta[i+4])*Kroneck(gamma[i+5]+delta[i+5]) 
		  + 0.125*cexp(M_PI*I/2.0*((delta[i+4]-gamma[i+3])*pow(yp+1,2)+2.0*(beta[i+3]+beta[i+4]+gamma[i+3]+delta[i+4])*xp*pow(yp+1,2)+2.0*(delta[i+3]+delta[i+4]+beta[i+3]+beta[i+4])*xp*yp+(2.0*beta[i+3]+3.0*delta[i+3]+delta[i+4])*yp))*csqrt(-I)*Gausssum1d(gamma[i+5]+delta[i+5],0)*Kroneck(gamma[i+3]+delta[i+3]-gamma[i+4]-delta[i+4])*Kroneck(alpha[i+5]+beta[i+5])))
			//*(2.0*(0.125*pow(2.0,(pow(ypp-1,2)*(pow(xpp,2)*(gamma[j]+delta[j+1])+pow(xpp-1,2)*(gamma[j+1]+delta[j])))*(1-yppp*pow(gamma[j+3]-gamma[j+4],2)-pow(yppp-1,2)*pow(gamma[j+3]-delta[j+4],2)))*(-I)*cexp(M_PI*I/2.0*(ypp*(delta[j]+delta[j+1])+pow(ypp+1,2)*(delta[j]+gamma[j+1]+2*beta[j+1])+pow(xpp,2)+2*(beta[j]+beta[j+1]+delta[j]+gamma[j+1]*(ypp+1)+delta[j+1]*ypp)*xpp))*Gausssum1d(0,xpp+beta[j]+beta[j+1]+delta[j]+gamma[j+1]*(ypp+1)+delta[j+1]*ypp+gamma[j+2]+delta[j+2])*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1]+1)*Kroneck(alpha[j+2]+beta[j+2]))
			*(2.0*(0.125*(-I)*cexp(M_PI*I/2.0*(ypp*(delta[j]+delta[j+1])+pow(ypp+1,2)*(delta[j]+gamma[j+1]+2*beta[j+1])+pow(xpp,2)+2*(beta[j]+beta[j+1]+delta[j]+gamma[j+1]*(ypp+1)+delta[j+1]*ypp)*xpp))*Gausssum1d(0,xpp+beta[j]+beta[j+1]+delta[j]+gamma[j+1]*(ypp+1)+delta[j+1]*ypp+gamma[j+2]+delta[j+2])*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1]+1)*Kroneck(alpha[j+2]+beta[j+2]))
			  *(0.125*cexp(M_PI*I/2.0*((delta[j+4]-gamma[j+3])*pow(yppp+1,2)+2.0*(beta[j+3]+beta[j+4]+gamma[j+3]+delta[j+4])*xppp*pow(yppp+1,2)+2.0*(delta[j+3]+delta[j+4]+beta[j+3]+beta[j+4])*xppp*yppp+(2.0*beta[j+3]+3.0*delta[j+3]+delta[j+4])*yppp))*Gausssum1d(0.0,beta[j+5])*Kroneck(gamma[j+3]+delta[j+3]-gamma[j+4]-delta[j+4])*Kroneck(gamma[j+5]+delta[j+5]) 
			    + 0.125*cexp(M_PI*I/2.0*((delta[j+4]-gamma[j+3])*pow(yppp+1,2)+2.0*(beta[j+3]+beta[j+4]+gamma[j+3]+delta[j+4])*xppp*pow(yppp+1,2)+2.0*(delta[j+3]+delta[j+4]+beta[j+3]+beta[j+4])*xppp*yppp+(2.0*beta[j+3]+3.0*delta[j+3]+delta[j+4])*yppp))*csqrt(-I)*Gausssum1d(gamma[j+5]+delta[j+5],0)*Kroneck(gamma[j+3]+delta[j+3]-gamma[j+4]-delta[j+4])*Kroneck(alpha[j+5]+beta[j+5])));
		    }
		  }
		}
	      }
	      for(ypp=0; ypp<=1; ypp++) {
		for(xpp=(ypp*(delta[j]+delta[j+1]))%2; xpp<=(1+ypp*(gamma[j]+gamma[j+1]))%2; xpp++) {
		  for(yppp=0; yppp<=(1+alpha[j+5])%2; yppp++) {
		    for(xppp=0;xppp<=(1+beta[j+5])%2; xppp++) {
		      summand += (2.0*(0.125*pow(2.0,(pow(y-1,2)*(pow(x,2)*(gamma[i]+delta[i+1])+pow(x-1,2)*(gamma[i+1]+delta[i])))*(1-yp*pow(gamma[i+3]-gamma[i+4],2)-pow(yp-1,2)*pow(gamma[i+3]-delta[i+4],2)))*(-I)*cexp(M_PI*I/2.0*(y*(delta[i]+delta[i+1])+pow(y+1,2)*(delta[i]+gamma[i+1]+2*beta[i+1])+pow(x,2)+2*(beta[i]+beta[i+1]+delta[i]+gamma[i+1]*(y+1)+delta[i+1]*y)*x))*Gausssum1d(0,x+beta[i]+beta[i+1]+delta[i]+gamma[i+1]*(y+1)+delta[i+1]*y+gamma[i+2]+delta[i+2])*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1]+1)*Kroneck(alpha[i+2]+beta[i+2]))
		*(0.125*cexp(M_PI*I/2.0*((delta[i+4]-gamma[i+3])*pow(yp+1,2)+2.0*(beta[i+3]+beta[i+4]+gamma[i+3]+delta[i+4])*xp*pow(yp+1,2)+2.0*(delta[i+3]+delta[i+4]+beta[i+3]+beta[i+4])*xp*yp+(2.0*beta[i+3]+3.0*delta[i+3]+delta[i+4])*yp))*Gausssum1d(0.0,beta[i+5])*Kroneck(gamma[i+3]+delta[i+3]-gamma[i+4]-delta[i+4])*Kroneck(gamma[i+5]+delta[i+5]) 
		  + 0.125*cexp(M_PI*I/2.0*((delta[i+4]-gamma[i+3])*pow(yp+1,2)+2.0*(beta[i+3]+beta[i+4]+gamma[i+3]+delta[i+4])*xp*pow(yp+1,2)+2.0*(delta[i+3]+delta[i+4]+beta[i+3]+beta[i+4])*xp*yp+(2.0*beta[i+3]+3.0*delta[i+3]+delta[i+4])*yp))*csqrt(-I)*Gausssum1d(gamma[i+5]+delta[i+5],0)*Kroneck(gamma[i+3]+delta[i+3]-gamma[i+4]-delta[i+4])*Kroneck(alpha[i+5]+beta[i+5])))
			*((0.125*pow(2.0,pow(ypp-1,2)*(pow(xpp,2)*(gamma[j]+delta[j+1])+pow(xpp-1,2)*(gamma[j+1]+delta[j])))*(-I)*cexp(M_PI*I/2.0*(ypp*(delta[j]+delta[j+1])+pow(ypp+1,2)*(delta[j]+gamma[j+1]+2*beta[j+1])+pow(xpp,2)+2*(beta[j]+beta[j+1]+delta[j]+gamma[j+1]*(ypp+1)+delta[j+1]*ypp)*xpp))*Gausssum1d(0,xpp+beta[j]+beta[j+1]+delta[j]+gamma[j+1]*(ypp+1)+delta[j+1]*ypp+gamma[j+2]+delta[j+2])*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1]+1)*Kroneck(alpha[j+2]+beta[j+2]))
			  *(0.125*2.0*csqrt(-I)*cexp(M_PI*I/2.0*(2.0*beta[j+5]*yppp+pow(xppp+1,2)*(delta[j+3]+gamma[j+4]+2.0*beta[j+4])+xppp*(delta[j+3]+delta[j+4])))*Gausssum1d(1,beta[j+3]+beta[j+4]+delta[j+3]+(xppp+1)*gamma[j+4]+xppp*delta[j+4])*Kroneck(gamma[j+3]+delta[j+3]-gamma[j+4]-delta[j+4]+1)*Kroneck(gamma[j+5]+delta[j+5])));
		    }
		  }
		}
	      }
	      //for(ypp=0; ypp<=1; ypp++) {
	      //**for(ypp=(y+xp)%2; ypp<=1; ypp++) {
	      for(ypp=(y+xp*(1+alpha[i+3]+beta[i+3]))%2; ypp<=1; ypp++) {
		//for(xpp=(ypp*(delta[j]+delta[j+1]))%2; xpp<=(1+ypp*(gamma[j]+gamma[j+1]))%2; xpp++) {
		//**for(xpp=(ypp*(delta[j]+delta[j+1])+y+xp)%2; xpp<=(1+ypp*(gamma[j]+gamma[j+1])+y+xp)%2; xpp++) {
		for(xpp=(ypp*(delta[j]+delta[j+1])+y+xp*(1+alpha[i+3]+beta[i+3]))%2; xpp<=(1+ypp*(gamma[j]+gamma[j+1])+y+xp*(1+alpha[i+3]+beta[i+3]))%2; xpp++) {
		  //for(yppp=ypp; yppp<=1; yppp++) {
		  //**for(yppp=(y+xp+ypp)%2; yppp<=1; yppp++) {
		  for(yppp=(y+xp*(1+alpha[i+3]+beta[i+3])+ypp)%2; yppp<=1; yppp++) {
		    //for(xppp=(yppp*(delta[j+3]+delta[j+4])+ypp)%2;xppp<=(1+yppp*(gamma[j+3]+gamma[j+4])+ypp)%2; xppp++) {
		    //**for(xppp=(yppp*(delta[j+3]+delta[j+4])+y+xp+ypp)%2;xppp<=(1+yppp*(gamma[j+3]+gamma[j+4])+y+xp+ypp)%2; xppp++) {
		    for(xppp=(yppp*(delta[j+3]+delta[j+4])+y+xp*(1+alpha[i+3]+beta[i+3])+ypp)%2;xppp<=(1+yppp*(gamma[j+3]+gamma[j+4])+y+xp*(1+alpha[i+3]+beta[i+3])+ypp)%2; xppp++) {
		      //summand += (2.0*(0.125*pow(2.0,(pow(y-1,2)*(pow(x,2)*(gamma[i]+delta[i+1])+pow(x-1,2)*(gamma[i+1]+delta[i])))*(1-yp*pow(gamma[i+3]-gamma[i+4],2)-pow(yp-1,2)*pow(gamma[i+3]-delta[i+4],2)))*(-I)*cexp(M_PI*I/2.0*(y*(delta[i]+delta[i+1])+pow(y+1,2)*(delta[i]+gamma[i+1]+2*beta[i+1])+pow(x,2)+2*(beta[i]+beta[i+1]+delta[i]+gamma[i+1]*(y+1)+delta[i+1]*y)*x))*Gausssum1d(0,x+beta[i]+beta[i+1]+delta[i]+gamma[i+1]*(y+1)+delta[i+1]*y+gamma[i+2]+delta[i+2])*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1]+1)*Kroneck(alpha[i+2]+beta[i+2]))
		      summand += 2.0*(2.0*(0.125*pow(2.0,(pow(y-1,2)*(pow(x,2)*(gamma[i]+delta[i+1])+pow(x-1,2)*(gamma[i+1]+delta[i])))*(1-yp*pow(gamma[i+3]-gamma[i+4],2)-pow(yp-1,2)*pow(gamma[i+3]-delta[i+4],2))*(pow(ypp-1,2)*(pow(xpp,2)*(gamma[j]+delta[j+1])+pow(xpp-1,2)*(gamma[j+1]+delta[j])))*(pow(yppp-1,2)*(pow(xppp,2)*(gamma[j+3]+delta[j+4])+pow(xppp-1,2)*(gamma[j+4]+delta[j+3]))))*(-I)*cexp(M_PI*I/2.0*(y*(delta[i]+delta[i+1])+pow(y+1,2)*(delta[i]+gamma[i+1]+2*beta[i+1])+pow(x,2)+2*(beta[i]+beta[i+1]+delta[i]+gamma[i+1]*(y+1)+delta[i+1]*y)*x))*Gausssum1d(0,x+beta[i]+beta[i+1]+delta[i]+gamma[i+1]*(y+1)+delta[i+1]*y+gamma[i+2]+delta[i+2])*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1]+1)*Kroneck(alpha[i+2]+beta[i+2]))
		*(0.125*cexp(M_PI*I/2.0*((delta[i+4]-gamma[i+3])*pow(yp+1,2)+2.0*(beta[i+3]+beta[i+4]+gamma[i+3]+delta[i+4])*xp*pow(yp+1,2)+2.0*(delta[i+3]+delta[i+4]+beta[i+3]+beta[i+4])*xp*yp+(2.0*beta[i+3]+3.0*delta[i+3]+delta[i+4])*yp))*Gausssum1d(0.0,beta[i+5])*Kroneck(gamma[i+3]+delta[i+3]-gamma[i+4]-delta[i+4])*Kroneck(gamma[i+5]+delta[i+5]) 
		  + 0.125*cexp(M_PI*I/2.0*((delta[i+4]-gamma[i+3])*pow(yp+1,2)+2.0*(beta[i+3]+beta[i+4]+gamma[i+3]+delta[i+4])*xp*pow(yp+1,2)+2.0*(delta[i+3]+delta[i+4]+beta[i+3]+beta[i+4])*xp*yp+(2.0*beta[i+3]+3.0*delta[i+3]+delta[i+4])*yp))*csqrt(-I)*Gausssum1d(gamma[i+5]+delta[i+5],0)*Kroneck(gamma[i+3]+delta[i+3]-gamma[i+4]-delta[i+4])*Kroneck(alpha[i+5]+beta[i+5])))
			//*(2.0*(0.125*pow(2.0,(pow(ypp-1,2)*(pow(xpp,2)*(gamma[j]+delta[j+1])+pow(xpp-1,2)*(gamma[j+1]+delta[j])))*(pow(yppp-1,2)*(pow(xppp,2)*(gamma[j+3]+delta[j+4])+pow(xppp-1,2)*(gamma[j+4]+delta[j+3]))))*(-I)*cexp(M_PI*I/2.0*(ypp*(delta[j]+delta[j+1])+pow(ypp+1,2)*(delta[j]+gamma[j+1]+2*beta[j+1])+pow(xpp,2)+2*(beta[j]+beta[j+1]+delta[j]+gamma[j+1]*(ypp+1)+delta[j+1]*ypp)*xpp))*Gausssum1d(0,xpp+beta[j]+beta[j+1]+delta[j]+gamma[j+1]*(ypp+1)+delta[j+1]*ypp+gamma[j+2]+delta[j+2])*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1]+1)*Kroneck(alpha[j+2]+beta[j+2]))
			*(2.0*(0.125*(-I)*cexp(M_PI*I/2.0*(ypp*(delta[j]+delta[j+1])+pow(ypp+1,2)*(delta[j]+gamma[j+1]+2*beta[j+1])+pow(xpp,2)+2*(beta[j]+beta[j+1]+delta[j]+gamma[j+1]*(ypp+1)+delta[j+1]*ypp)*xpp))*Gausssum1d(0,xpp+beta[j]+beta[j+1]+delta[j]+gamma[j+1]*(ypp+1)+delta[j+1]*ypp+gamma[j+2]+delta[j+2])*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1]+1)*Kroneck(alpha[j+2]+beta[j+2]))
			  *(0.125*(-I)*cexp(M_PI*I/2.0*(yppp*(delta[j+3]+delta[j+4])+pow(yppp+1,2)*(delta[j+3]+gamma[j+4]+2*beta[j+4])+pow(xppp,2)+2*(beta[j+3]+beta[j+4]+delta[j+3]+gamma[j+4]*(yppp+1)+delta[j+4]*yppp)*xppp))*Gausssum1d(0,xppp+beta[j+3]+beta[j+4]+delta[j+3]+gamma[j+4]*(yppp+1)+delta[j+4]*yppp+gamma[j+5]+delta[j+5])*Kroneck(gamma[j+3]+delta[j+3]-gamma[j+4]-delta[j+4]+1)*Kroneck(alpha[j+5]+beta[j+5])));
		    }
		  }
		}
	      }
	    }
	  }
	}
      }

      
      // eighth term
      for(y=0; y<=1; y++) {
	for(x=(y*(delta[i]+delta[i+1]))%2; x<=(1+y*(gamma[i]+gamma[i+1]))%2; x++) {
	  for(yp=0; yp<=(1+alpha[i+5])%2; yp++) {
	    for(xp=0;xp<=(1+beta[i+5])%2; xp++) {
	      for(ypp=0; ypp<=1; ypp++) {
		//**for(xpp=0;xpp<=(ypp*(gamma[j]+gamma[j+1])+(ypp+1)*(gamma[j]+delta[j+1]))%2; xpp++) {
		for(xpp=ypp*(beta[j]+alpha[j+1]+beta[j+1])%2;xpp<=(ypp*(beta[j]+alpha[j+1]+beta[j+1])+ypp*(gamma[j]+gamma[j+1])+(ypp+1)*(gamma[j]+delta[j+1]))%2; xpp++) {
		  for(yppp=((gamma[j+3]+delta[j+4])*xpp)%2; yppp<=(1+(gamma[j+3]+gamma[j+4])*xpp)%2; yppp++) {
		    //**for(xppp=0;xppp<=(yppp*(gamma[j+3]+gamma[j+4])+(yppp+1)*(gamma[j+3]+delta[j+4]))%2; xppp++) {
		    for(xppp=yppp*(beta[j+3]+alpha[j+4]+beta[j+4])%2;xppp<=(yppp*(beta[j+3]+alpha[j+4]+beta[j+4])+yppp*(gamma[j+3]+gamma[j+4])+(yppp+1)*(gamma[j+3]+delta[j+4]))%2; xppp++) {
		      summand += ((0.125*pow(2.0,pow(y-1,2)*(pow(x,2)*(gamma[i]+delta[i+1])+pow(x-1,2)*(gamma[i+1]+delta[i])))*(-I)*cexp(M_PI*I/2.0*(y*(delta[i]+delta[i+1])+pow(y+1,2)*(delta[i]+gamma[i+1]+2*beta[i+1])+pow(x,2)+2*(beta[i]+beta[i+1]+delta[i]+gamma[i+1]*(y+1)+delta[i+1]*y)*x))*Gausssum1d(0,x+beta[i]+beta[i+1]+delta[i]+gamma[i+1]*(y+1)+delta[i+1]*y+gamma[i+2]+delta[i+2])*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1]+1)*Kroneck(alpha[i+2]+beta[i+2]))
				  *(0.125*2.0*csqrt(-I)*cexp(M_PI*I/2.0*(2.0*beta[i+5]*yp+pow(xp+1,2)*(delta[i+3]+gamma[i+4]+2.0*beta[i+4])+xp*(delta[i+3]+delta[i+4])))*Gausssum1d(1,beta[i+3]+beta[i+4]+delta[i+3]+(xp+1)*gamma[i+4]+xp*delta[i+4])*Kroneck(gamma[i+3]+delta[i+3]-gamma[i+4]-delta[i+4]+1)*Kroneck(gamma[i+5]+delta[i+5])))
			*(2.0*(0.125*pow(2.0,(1-ypp*pow(gamma[j]-gamma[j+1],2)-pow(ypp-1,2)*pow(gamma[j]-delta[j+1],2))*(1-yppp*pow(gamma[j+3]-gamma[j+4],2)-pow(yppp-1,2)*pow(gamma[j+3]-delta[j+4],2)))*cexp(M_PI*I/2.0*((delta[j+1]-gamma[j])*pow(ypp+1,2)+2.0*(beta[j]+beta[j+1]+gamma[j]+delta[j+1])*xpp*pow(ypp+1,2)+2.0*(delta[j]+delta[j+1]+beta[j]+beta[j+1])*xpp*ypp+(2.0*beta[j]+3.0*delta[j]+delta[j+1])*ypp))*Gausssum1d(0.0,beta[j+2])*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1])*Kroneck(gamma[j+2]+delta[j+2]) 
			      + 0.125*pow(2.0,(1-ypp*pow(gamma[j]-gamma[j+1],2)-pow(ypp-1,2)*pow(gamma[j]-delta[j+1],2))*(1-yppp*pow(gamma[j+3]-gamma[j+4],2)-pow(yppp-1,2)*pow(gamma[j+3]-delta[j+4],2)))*cexp(M_PI*I/2.0*((delta[j+1]-gamma[j])*pow(ypp+1,2)+2.0*(beta[j]+beta[j+1]+gamma[j]+delta[j+1])*xpp*pow(ypp+1,2)+2.0*(delta[j]+delta[j+1]+beta[j]+beta[j+1])*xpp*ypp+(2.0*beta[j]+3.0*delta[j]+delta[j+1])*ypp))*csqrt(-I)*Gausssum1d(gamma[j+2]+delta[j+2],0)*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1])*Kroneck(alpha[j+2]+beta[j+2]))
			*(0.125*cexp(M_PI*I/2.0*((delta[j+4]-gamma[j+3])*pow(yppp+1,2)+2.0*(beta[j+3]+beta[j+4]+gamma[j+3]+delta[j+4])*xppp*pow(yppp+1,2)+2.0*(delta[j+3]+delta[j+4]+beta[j+3]+beta[j+4])*xppp*yppp+(2.0*beta[j+3]+3.0*delta[j+3]+delta[j+4])*yppp))*Gausssum1d(0.0,beta[j+5])*Kroneck(gamma[j+3]+delta[j+3]-gamma[j+4]-delta[j+4])*Kroneck(gamma[j+5]+delta[j+5]) 
			  + 0.125*cexp(M_PI*I/2.0*((delta[j+4]-gamma[j+3])*pow(yppp+1,2)+2.0*(beta[j+3]+beta[j+4]+gamma[j+3]+delta[j+4])*xppp*pow(yppp+1,2)+2.0*(delta[j+3]+delta[j+4]+beta[j+3]+beta[j+4])*xppp*yppp+(2.0*beta[j+3]+3.0*delta[j+3]+delta[j+4])*yppp))*csqrt(-I)*Gausssum1d(gamma[j+5]+delta[j+5],0)*Kroneck(gamma[j+3]+delta[j+3]-gamma[j+4]-delta[j+4])*Kroneck(alpha[j+5]+beta[j+5])));
		    }
		  }
		  for(yppp=0; yppp<=(1+alpha[j+5])%2; yppp++) {
		    for(xppp=0;xppp<=(1+beta[j+5])%2; xppp++) {
		      summand += ((0.125*pow(2.0,pow(y-1,2)*(pow(x,2)*(gamma[i]+delta[i+1])+pow(x-1,2)*(gamma[i+1]+delta[i])))*(-I)*cexp(M_PI*I/2.0*(y*(delta[i]+delta[i+1])+pow(y+1,2)*(delta[i]+gamma[i+1]+2*beta[i+1])+pow(x,2)+2*(beta[i]+beta[i+1]+delta[i]+gamma[i+1]*(y+1)+delta[i+1]*y)*x))*Gausssum1d(0,x+beta[i]+beta[i+1]+delta[i]+gamma[i+1]*(y+1)+delta[i+1]*y+gamma[i+2]+delta[i+2])*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1]+1)*Kroneck(alpha[i+2]+beta[i+2]))
				  *(0.125*2.0*csqrt(-I)*cexp(M_PI*I/2.0*(2.0*beta[i+5]*yp+pow(xp+1,2)*(delta[i+3]+gamma[i+4]+2.0*beta[i+4])+xp*(delta[i+3]+delta[i+4])))*Gausssum1d(1,beta[i+3]+beta[i+4]+delta[i+3]+(xp+1)*gamma[i+4]+xp*delta[i+4])*Kroneck(gamma[i+3]+delta[i+3]-gamma[i+4]-delta[i+4]+1)*Kroneck(gamma[i+5]+delta[i+5])))
			*((0.125*pow(2.0,1-ypp*pow(gamma[j]-gamma[j+1],2)-pow(ypp-1,2)*pow(gamma[j]-delta[j+1],2))*cexp(M_PI*I/2.0*((delta[j+1]-gamma[j])*pow(ypp+1,2)+2.0*(beta[j]+beta[j+1]+gamma[j]+delta[j+1])*xpp*pow(ypp+1,2)+2.0*(delta[j]+delta[j+1]+beta[j]+beta[j+1])*xpp*ypp+(2.0*beta[j]+3.0*delta[j]+delta[j+1])*ypp))*Gausssum1d(0.0,beta[j+2])*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1])*Kroneck(gamma[j+2]+delta[j+2]) 
				  + 0.125*pow(2.0,1-ypp*pow(gamma[j]-gamma[j+1],2)-pow(ypp-1,2)*pow(gamma[j]-delta[j+1],2))*cexp(M_PI*I/2.0*((delta[j+1]-gamma[j])*pow(ypp+1,2)+2.0*(beta[j]+beta[j+1]+gamma[j]+delta[j+1])*xpp*pow(ypp+1,2)+2.0*(delta[j]+delta[j+1]+beta[j]+beta[j+1])*xpp*ypp+(2.0*beta[j]+3.0*delta[j]+delta[j+1])*ypp))*csqrt(-I)*Gausssum1d(gamma[j+2]+delta[j+2],0)*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1])*Kroneck(alpha[j+2]+beta[j+2]))
			  *(0.125*2.0*csqrt(-I)*cexp(M_PI*I/2.0*(2.0*beta[j+5]*yppp+pow(xppp+1,2)*(delta[j+3]+gamma[j+4]+2.0*beta[j+4])+xppp*(delta[j+3]+delta[j+4])))*Gausssum1d(1,beta[j+3]+beta[j+4]+delta[j+3]+(xppp+1)*gamma[j+4]+xppp*delta[j+4])*Kroneck(gamma[j+3]+delta[j+3]-gamma[j+4]-delta[j+4]+1)*Kroneck(gamma[j+5]+delta[j+5])));
		    }
		  }
		  //**for(yppp=xpp; yppp<=1; yppp++) {
		  for(yppp=xpp*(1+alpha[j]+beta[j])%2; yppp<=1; yppp++) {
		    //**for(xppp=(yppp*(delta[j+3]+delta[j+4])+xpp)%2;xppp<=(1+yppp*(gamma[j+3]+gamma[j+4])+xpp)%2; xppp++) {
		    for(xppp=(yppp*(delta[j+3]+delta[j+4])+xpp*(1+alpha[j]+beta[j]))%2;xppp<=(1+yppp*(gamma[j+3]+gamma[j+4])+xpp*(1+alpha[j]+beta[j]))%2; xppp++) {
		      summand += ((0.125*pow(2.0,pow(y-1,2)*(pow(x,2)*(gamma[i]+delta[i+1])+pow(x-1,2)*(gamma[i+1]+delta[i])))*(-I)*cexp(M_PI*I/2.0*(y*(delta[i]+delta[i+1])+pow(y+1,2)*(delta[i]+gamma[i+1]+2*beta[i+1])+pow(x,2)+2*(beta[i]+beta[i+1]+delta[i]+gamma[i+1]*(y+1)+delta[i+1]*y)*x))*Gausssum1d(0,x+beta[i]+beta[i+1]+delta[i]+gamma[i+1]*(y+1)+delta[i+1]*y+gamma[i+2]+delta[i+2])*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1]+1)*Kroneck(alpha[i+2]+beta[i+2]))
				  *(0.125*2.0*csqrt(-I)*cexp(M_PI*I/2.0*(2.0*beta[i+5]*yp+pow(xp+1,2)*(delta[i+3]+gamma[i+4]+2.0*beta[i+4])+xp*(delta[i+3]+delta[i+4])))*Gausssum1d(1,beta[i+3]+beta[i+4]+delta[i+3]+(xp+1)*gamma[i+4]+xp*delta[i+4])*Kroneck(gamma[i+3]+delta[i+3]-gamma[i+4]-delta[i+4]+1)*Kroneck(gamma[i+5]+delta[i+5])))
			*(2.0*(0.125*pow(2.0,(1-ypp*pow(gamma[j]-gamma[j+1],2)-pow(ypp-1,2)*pow(gamma[j]-delta[j+1],2))*(pow(yppp-1,2)*(pow(xppp,2)*(gamma[j+3]+delta[j+4])+pow(xppp-1,2)*(gamma[j+4]+delta[j+3]))))*cexp(M_PI*I/2.0*((delta[j+1]-gamma[j])*pow(ypp+1,2)+2.0*(beta[j]+beta[j+1]+gamma[j]+delta[j+1])*xpp*pow(ypp+1,2)+2.0*(delta[j]+delta[j+1]+beta[j]+beta[j+1])*xpp*ypp+(2.0*beta[j]+3.0*delta[j]+delta[j+1])*ypp))*Gausssum1d(0.0,beta[j+2])*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1])*Kroneck(gamma[j+2]+delta[j+2]) 
				      + 0.125*pow(2.0,(1-ypp*pow(gamma[j]-gamma[j+1],2)-pow(ypp-1,2)*pow(gamma[j]-delta[j+1],2))*(pow(yppp-1,2)*(pow(xppp,2)*(gamma[j+3]+delta[j+4])+pow(xppp-1,2)*(gamma[j+4]+delta[j+3]))))*cexp(M_PI*I/2.0*((delta[j+1]-gamma[j])*pow(ypp+1,2)+2.0*(beta[j]+beta[j+1]+gamma[j]+delta[j+1])*xpp*pow(ypp+1,2)+2.0*(delta[j]+delta[j+1]+beta[j]+beta[j+1])*xpp*ypp+(2.0*beta[j]+3.0*delta[j]+delta[j+1])*ypp))*csqrt(-I)*Gausssum1d(gamma[j+2]+delta[j+2],0)*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1])*Kroneck(alpha[j+2]+beta[j+2]))
			  *(0.125*(-I)*cexp(M_PI*I/2.0*(yppp*(delta[j+3]+delta[j+4])+pow(yppp+1,2)*(delta[j+3]+gamma[j+4]+2*beta[j+4])+pow(xppp,2)+2*(beta[j+3]+beta[j+4]+delta[j+3]+gamma[j+4]*(yppp+1)+delta[j+4]*yppp)*xppp))*Gausssum1d(0,xppp+beta[j+3]+beta[j+4]+delta[j+3]+gamma[j+4]*(yppp+1)+delta[j+4]*yppp+gamma[j+5]+delta[j+5])*Kroneck(gamma[j+3]+delta[j+3]-gamma[j+4]-delta[j+4]+1)*Kroneck(alpha[j+5]+beta[j+5])));
		    }
		  }
		}
	      }

	      for(ypp=0; ypp<=(1+alpha[j+2])%2; ypp++) {
		for(xpp=0; xpp<=(1+beta[j+2])%2; xpp++) {
		  for(yppp=0; yppp<=1; yppp++) {
		    //**for(xppp=0;xppp<=(yppp*(gamma[j+3]+gamma[j+4])+(yppp+1)*(gamma[j+3]+delta[j+4]))%2; xppp++) {
		    for(xppp=yppp*(beta[j+3]+alpha[j+4]+beta[j+4])%2;xppp<=(yppp*(beta[j+3]+alpha[j+4]+beta[j+4])+yppp*(gamma[j+3]+gamma[j+4])+(yppp+1)*(gamma[j+3]+delta[j+4]))%2; xppp++) {
		      summand += ((0.125*pow(2.0,pow(y-1,2)*(pow(x,2)*(gamma[i]+delta[i+1])+pow(x-1,2)*(gamma[i+1]+delta[i])))*(-I)*cexp(M_PI*I/2.0*(y*(delta[i]+delta[i+1])+pow(y+1,2)*(delta[i]+gamma[i+1]+2*beta[i+1])+pow(x,2)+2*(beta[i]+beta[i+1]+delta[i]+gamma[i+1]*(y+1)+delta[i+1]*y)*x))*Gausssum1d(0,x+beta[i]+beta[i+1]+delta[i]+gamma[i+1]*(y+1)+delta[i+1]*y+gamma[i+2]+delta[i+2])*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1]+1)*Kroneck(alpha[i+2]+beta[i+2]))
				  *(0.125*2.0*csqrt(-I)*cexp(M_PI*I/2.0*(2.0*beta[i+5]*yp+pow(xp+1,2)*(delta[i+3]+gamma[i+4]+2.0*beta[i+4])+xp*(delta[i+3]+delta[i+4])))*Gausssum1d(1,beta[i+3]+beta[i+4]+delta[i+3]+(xp+1)*gamma[i+4]+xp*delta[i+4])*Kroneck(gamma[i+3]+delta[i+3]-gamma[i+4]-delta[i+4]+1)*Kroneck(gamma[i+5]+delta[i+5])))
			*((0.125*2.0*csqrt(-I)*cexp(M_PI*I/2.0*(2.0*beta[j+2]*ypp+pow(xpp+1,2)*(delta[j]+gamma[j+1]+2.0*beta[j+1])+xpp*(delta[j]+delta[j+1])))*Gausssum1d(1,beta[j]+beta[j+1]+delta[j]+(xpp+1)*gamma[j+1]+xpp*delta[j+1])*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1]+1)*Kroneck(gamma[j+2]+delta[j+2]))
			  *(0.125*pow(2.0,1-yppp*pow(gamma[j+3]-gamma[j+4],2)-pow(yppp-1,2)*pow(gamma[j+3]-delta[j+4],2))*cexp(M_PI*I/2.0*((delta[j+4]-gamma[j+3])*pow(yppp+1,2)+2.0*(beta[j+3]+beta[j+4]+gamma[j+3]+delta[j+4])*xppp*pow(yppp+1,2)+2.0*(delta[j+3]+delta[j+4]+beta[j+3]+beta[j+4])*xppp*yppp+(2.0*beta[j+3]+3.0*delta[j+3]+delta[j+4])*yppp))*Gausssum1d(0.0,beta[j+5])*Kroneck(gamma[j+3]+delta[j+3]-gamma[j+4]-delta[j+4])*Kroneck(gamma[j+5]+delta[j+5]) 
			    + 0.125*pow(2.0,1-yppp*pow(gamma[j+3]-gamma[j+4],2)-pow(yppp-1,2)*pow(gamma[j+3]-delta[j+4],2))*cexp(M_PI*I/2.0*((delta[j+4]-gamma[j+3])*pow(yppp+1,2)+2.0*(beta[j+3]+beta[j+4]+gamma[j+3]+delta[j+4])*xppp*pow(yppp+1,2)+2.0*(delta[j+3]+delta[j+4]+beta[j+3]+beta[j+4])*xppp*yppp+(2.0*beta[j+3]+3.0*delta[j+3]+delta[j+4])*yppp))*csqrt(-I)*Gausssum1d(gamma[j+5]+delta[j+5],0)*Kroneck(gamma[j+3]+delta[j+3]-gamma[j+4]-delta[j+4])*Kroneck(alpha[j+5]+beta[j+5])));
		    }
		  }
		  for(yppp=0; yppp<=(1+alpha[j+5])%2; yppp++) {
		    for(xppp=0;xppp<=(1+beta[j+5])%2; xppp++) {
		      summand += ((0.125*pow(2.0,pow(y-1,2)*(pow(x,2)*(gamma[i]+delta[i+1])+pow(x-1,2)*(gamma[i+1]+delta[i])))*(-I)*cexp(M_PI*I/2.0*(y*(delta[i]+delta[i+1])+pow(y+1,2)*(delta[i]+gamma[i+1]+2*beta[i+1])+pow(x,2)+2*(beta[i]+beta[i+1]+delta[i]+gamma[i+1]*(y+1)+delta[i+1]*y)*x))*Gausssum1d(0,x+beta[i]+beta[i+1]+delta[i]+gamma[i+1]*(y+1)+delta[i+1]*y+gamma[i+2]+delta[i+2])*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1]+1)*Kroneck(alpha[i+2]+beta[i+2]))
				  *(0.125*2.0*csqrt(-I)*cexp(M_PI*I/2.0*(2.0*beta[i+5]*yp+pow(xp+1,2)*(delta[i+3]+gamma[i+4]+2.0*beta[i+4])+xp*(delta[i+3]+delta[i+4])))*Gausssum1d(1,beta[i+3]+beta[i+4]+delta[i+3]+(xp+1)*gamma[i+4]+xp*delta[i+4])*Kroneck(gamma[i+3]+delta[i+3]-gamma[i+4]-delta[i+4]+1)*Kroneck(gamma[i+5]+delta[i+5])))
			*((0.125*2.0*csqrt(-I)*cexp(M_PI*I/2.0*(2.0*beta[j+2]*ypp+pow(xpp+1,2)*(delta[j]+gamma[j+1]+2.0*beta[j+1])+xpp*(delta[j]+delta[j+1])))*Gausssum1d(1,beta[j]+beta[j+1]+delta[j]+(xpp+1)*gamma[j+1]+xpp*delta[j+1])*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1]+1)*Kroneck(gamma[j+2]+delta[j+2]))
			  *(0.125*2.0*csqrt(-I)*cexp(M_PI*I/2.0*(2.0*beta[j+5]*yppp+pow(xppp+1,2)*(delta[j+3]+gamma[j+4]+2.0*beta[j+4])+xppp*(delta[j+3]+delta[j+4])))*Gausssum1d(1,beta[j+3]+beta[j+4]+delta[j+3]+(xppp+1)*gamma[j+4]+xppp*delta[j+4])*Kroneck(gamma[j+3]+delta[j+3]-gamma[j+4]-delta[j+4]+1)*Kroneck(gamma[j+5]+delta[j+5])));
		    }
		  }
		  for(yppp=0; yppp<=1; yppp++) {
		    for(xppp=(yppp*(delta[j+3]+delta[j+4]))%2;xppp<=(1+yppp*(gamma[j+3]+gamma[j+4]))%2; xppp++) {
		      summand += ((0.125*pow(2.0,pow(y-1,2)*(pow(x,2)*(gamma[i]+delta[i+1])+pow(x-1,2)*(gamma[i+1]+delta[i])))*(-I)*cexp(M_PI*I/2.0*(y*(delta[i]+delta[i+1])+pow(y+1,2)*(delta[i]+gamma[i+1]+2*beta[i+1])+pow(x,2)+2*(beta[i]+beta[i+1]+delta[i]+gamma[i+1]*(y+1)+delta[i+1]*y)*x))*Gausssum1d(0,x+beta[i]+beta[i+1]+delta[i]+gamma[i+1]*(y+1)+delta[i+1]*y+gamma[i+2]+delta[i+2])*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1]+1)*Kroneck(alpha[i+2]+beta[i+2]))
				  *(0.125*2.0*csqrt(-I)*cexp(M_PI*I/2.0*(2.0*beta[i+5]*yp+pow(xp+1,2)*(delta[i+3]+gamma[i+4]+2.0*beta[i+4])+xp*(delta[i+3]+delta[i+4])))*Gausssum1d(1,beta[i+3]+beta[i+4]+delta[i+3]+(xp+1)*gamma[i+4]+xp*delta[i+4])*Kroneck(gamma[i+3]+delta[i+3]-gamma[i+4]-delta[i+4]+1)*Kroneck(gamma[i+5]+delta[i+5])))
			*((0.125*2.0*csqrt(-I)*cexp(M_PI*I/2.0*(2.0*beta[j+2]*ypp+pow(xpp+1,2)*(delta[j]+gamma[j+1]+2.0*beta[j+1])+xpp*(delta[j]+delta[j+1])))*Gausssum1d(1,beta[j]+beta[j+1]+delta[j]+(xpp+1)*gamma[j+1]+xpp*delta[j+1])*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1]+1)*Kroneck(gamma[j+2]+delta[j+2]))
			  *(0.125*(-I)*pow(2.0,(pow(yppp-1,2)*(pow(xppp,2)*(gamma[j+3]+delta[j+4])+pow(xppp-1,2)*(gamma[j+4]+delta[j+3]))))*cexp(M_PI*I/2.0*(yppp*(delta[j+3]+delta[j+4])+pow(yppp+1,2)*(delta[j+3]+gamma[j+4]+2*beta[j+4])+pow(xppp,2)+2*(beta[j+3]+beta[j+4]+delta[j+3]+gamma[j+4]*(yppp+1)+delta[j+4]*yppp)*xppp))*Gausssum1d(0,xppp+beta[j+3]+beta[j+4]+delta[j+3]+gamma[j+4]*(yppp+1)+delta[j+4]*yppp+gamma[j+5]+delta[j+5])*Kroneck(gamma[j+3]+delta[j+3]-gamma[j+4]-delta[j+4]+1)*Kroneck(alpha[j+5]+beta[j+5])));
		    }
		  }
		}
	      }

	      for(ypp=0; ypp<=1; ypp++) {
		for(xpp=(ypp*(delta[j]+delta[j+1]))%2; xpp<=(1+ypp*(gamma[j]+gamma[j+1]))%2; xpp++) {
		  for(yppp=((gamma[j+3]+delta[j+4])*ypp)%2; yppp<=(1+(gamma[j+3]+gamma[j+4])*ypp)%2; yppp++) {
		    //**for(xppp=0;xppp<=(yppp*(gamma[j+3]+gamma[j+4])+(yppp+1)*(gamma[j+3]+delta[j+4]))%2; xppp++) {
		    for(xppp=yppp*(beta[j+3]+alpha[j+4]+beta[j+4])%2;xppp<=(yppp*(beta[j+3]+alpha[j+4]+beta[j+4])+yppp*(gamma[j+3]+gamma[j+4])+(yppp+1)*(gamma[j+3]+delta[j+4]))%2; xppp++) {
		      summand += ((0.125*pow(2.0,pow(y-1,2)*(pow(x,2)*(gamma[i]+delta[i+1])+pow(x-1,2)*(gamma[i+1]+delta[i])))*(-I)*cexp(M_PI*I/2.0*(y*(delta[i]+delta[i+1])+pow(y+1,2)*(delta[i]+gamma[i+1]+2*beta[i+1])+pow(x,2)+2*(beta[i]+beta[i+1]+delta[i]+gamma[i+1]*(y+1)+delta[i+1]*y)*x))*Gausssum1d(0,x+beta[i]+beta[i+1]+delta[i]+gamma[i+1]*(y+1)+delta[i+1]*y+gamma[i+2]+delta[i+2])*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1]+1)*Kroneck(alpha[i+2]+beta[i+2]))
				  *(0.125*2.0*csqrt(-I)*cexp(M_PI*I/2.0*(2.0*beta[i+5]*yp+pow(xp+1,2)*(delta[i+3]+gamma[i+4]+2.0*beta[i+4])+xp*(delta[i+3]+delta[i+4])))*Gausssum1d(1,beta[i+3]+beta[i+4]+delta[i+3]+(xp+1)*gamma[i+4]+xp*delta[i+4])*Kroneck(gamma[i+3]+delta[i+3]-gamma[i+4]-delta[i+4]+1)*Kroneck(gamma[i+5]+delta[i+5])))
			*(2.0*(0.125*pow(2.0,(pow(ypp-1,2)*(pow(xpp,2)*(gamma[j]+delta[j+1])+pow(xpp-1,2)*(gamma[j+1]+delta[j])))*(1-yppp*pow(gamma[j+3]-gamma[j+4],2)-pow(yppp-1,2)*pow(gamma[j+3]-delta[j+4],2)))*(-I)*cexp(M_PI*I/2.0*(ypp*(delta[j]+delta[j+1])+pow(ypp+1,2)*(delta[j]+gamma[j+1]+2*beta[j+1])+pow(xpp,2)+2*(beta[j]+beta[j+1]+delta[j]+gamma[j+1]*(ypp+1)+delta[j+1]*ypp)*xpp))*Gausssum1d(0,xpp+beta[j]+beta[j+1]+delta[j]+gamma[j+1]*(ypp+1)+delta[j+1]*ypp+gamma[j+2]+delta[j+2])*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1]+1)*Kroneck(alpha[j+2]+beta[j+2]))
			  *(0.125*cexp(M_PI*I/2.0*((delta[j+4]-gamma[j+3])*pow(yppp+1,2)+2.0*(beta[j+3]+beta[j+4]+gamma[j+3]+delta[j+4])*xppp*pow(yppp+1,2)+2.0*(delta[j+3]+delta[j+4]+beta[j+3]+beta[j+4])*xppp*yppp+(2.0*beta[j+3]+3.0*delta[j+3]+delta[j+4])*yppp))*Gausssum1d(0.0,beta[j+5])*Kroneck(gamma[j+3]+delta[j+3]-gamma[j+4]-delta[j+4])*Kroneck(gamma[j+5]+delta[j+5]) 
			    + 0.125*cexp(M_PI*I/2.0*((delta[j+4]-gamma[j+3])*pow(yppp+1,2)+2.0*(beta[j+3]+beta[j+4]+gamma[j+3]+delta[j+4])*xppp*pow(yppp+1,2)+2.0*(delta[j+3]+delta[j+4]+beta[j+3]+beta[j+4])*xppp*yppp+(2.0*beta[j+3]+3.0*delta[j+3]+delta[j+4])*yppp))*csqrt(-I)*Gausssum1d(gamma[j+5]+delta[j+5],0)*Kroneck(gamma[j+3]+delta[j+3]-gamma[j+4]-delta[j+4])*Kroneck(alpha[j+5]+beta[j+5])));
		    }
		  }
		  for(yppp=0; yppp<=(1+alpha[j+5])%2; yppp++) {
		    for(xppp=0;xppp<=(1+beta[j+5])%2; xppp++) {
		      summand += ((0.125*pow(2.0,pow(y-1,2)*(pow(x,2)*(gamma[i]+delta[i+1])+pow(x-1,2)*(gamma[i+1]+delta[i])))*(-I)*cexp(M_PI*I/2.0*(y*(delta[i]+delta[i+1])+pow(y+1,2)*(delta[i]+gamma[i+1]+2*beta[i+1])+pow(x,2)+2*(beta[i]+beta[i+1]+delta[i]+gamma[i+1]*(y+1)+delta[i+1]*y)*x))*Gausssum1d(0,x+beta[i]+beta[i+1]+delta[i]+gamma[i+1]*(y+1)+delta[i+1]*y+gamma[i+2]+delta[i+2])*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1]+1)*Kroneck(alpha[i+2]+beta[i+2]))
				  *(0.125*2.0*csqrt(-I)*cexp(M_PI*I/2.0*(2.0*beta[i+5]*yp+pow(xp+1,2)*(delta[i+3]+gamma[i+4]+2.0*beta[i+4])+xp*(delta[i+3]+delta[i+4])))*Gausssum1d(1,beta[i+3]+beta[i+4]+delta[i+3]+(xp+1)*gamma[i+4]+xp*delta[i+4])*Kroneck(gamma[i+3]+delta[i+3]-gamma[i+4]-delta[i+4]+1)*Kroneck(gamma[i+5]+delta[i+5])))
			*((0.125*pow(2.0,pow(ypp-1,2)*(pow(xpp,2)*(gamma[j]+delta[j+1])+pow(xpp-1,2)*(gamma[j+1]+delta[j])))*(-I)*cexp(M_PI*I/2.0*(ypp*(delta[j]+delta[j+1])+pow(ypp+1,2)*(delta[j]+gamma[j+1]+2*beta[j+1])+pow(xpp,2)+2*(beta[j]+beta[j+1]+delta[j]+gamma[j+1]*(ypp+1)+delta[j+1]*ypp)*xpp))*Gausssum1d(0,xpp+beta[j]+beta[j+1]+delta[j]+gamma[j+1]*(ypp+1)+delta[j+1]*ypp+gamma[j+2]+delta[j+2])*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1]+1)*Kroneck(alpha[j+2]+beta[j+2]))
			  *(0.125*2.0*csqrt(-I)*cexp(M_PI*I/2.0*(2.0*beta[j+5]*yppp+pow(xppp+1,2)*(delta[j+3]+gamma[j+4]+2.0*beta[j+4])+xppp*(delta[j+3]+delta[j+4])))*Gausssum1d(1,beta[j+3]+beta[j+4]+delta[j+3]+(xppp+1)*gamma[j+4]+xppp*delta[j+4])*Kroneck(gamma[j+3]+delta[j+3]-gamma[j+4]-delta[j+4]+1)*Kroneck(gamma[j+5]+delta[j+5])));
		    }
		  }
		  for(yppp=ypp; yppp<=1; yppp++) {
		    for(xppp=(yppp*(delta[j+3]+delta[j+4])+ypp)%2;xppp<=(1+yppp*(gamma[j+3]+gamma[j+4])+ypp)%2; xppp++) {
		      summand += ((0.125*pow(2.0,pow(y-1,2)*(pow(x,2)*(gamma[i]+delta[i+1])+pow(x-1,2)*(gamma[i+1]+delta[i])))*(-I)*cexp(M_PI*I/2.0*(y*(delta[i]+delta[i+1])+pow(y+1,2)*(delta[i]+gamma[i+1]+2*beta[i+1])+pow(x,2)+2*(beta[i]+beta[i+1]+delta[i]+gamma[i+1]*(y+1)+delta[i+1]*y)*x))*Gausssum1d(0,x+beta[i]+beta[i+1]+delta[i]+gamma[i+1]*(y+1)+delta[i+1]*y+gamma[i+2]+delta[i+2])*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1]+1)*Kroneck(alpha[i+2]+beta[i+2]))
				  *(0.125*2.0*csqrt(-I)*cexp(M_PI*I/2.0*(2.0*beta[i+5]*yp+pow(xp+1,2)*(delta[i+3]+gamma[i+4]+2.0*beta[i+4])+xp*(delta[i+3]+delta[i+4])))*Gausssum1d(1,beta[i+3]+beta[i+4]+delta[i+3]+(xp+1)*gamma[i+4]+xp*delta[i+4])*Kroneck(gamma[i+3]+delta[i+3]-gamma[i+4]-delta[i+4]+1)*Kroneck(gamma[i+5]+delta[i+5])))
			*(2.0*(0.125*pow(2.0,(pow(ypp-1,2)*(pow(xpp,2)*(gamma[j]+delta[j+1])+pow(xpp-1,2)*(gamma[j+1]+delta[j])))*(pow(yppp-1,2)*(pow(xppp,2)*(gamma[j+3]+delta[j+4])+pow(xppp-1,2)*(gamma[j+4]+delta[j+3]))))*(-I)*cexp(M_PI*I/2.0*(ypp*(delta[j]+delta[j+1])+pow(ypp+1,2)*(delta[j]+gamma[j+1]+2*beta[j+1])+pow(xpp,2)+2*(beta[j]+beta[j+1]+delta[j]+gamma[j+1]*(ypp+1)+delta[j+1]*ypp)*xpp))*Gausssum1d(0,xpp+beta[j]+beta[j+1]+delta[j]+gamma[j+1]*(ypp+1)+delta[j+1]*ypp+gamma[j+2]+delta[j+2])*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1]+1)*Kroneck(alpha[j+2]+beta[j+2]))
			  *(0.125*(-I)*cexp(M_PI*I/2.0*(yppp*(delta[j+3]+delta[j+4])+pow(yppp+1,2)*(delta[j+3]+gamma[j+4]+2*beta[j+4])+pow(xppp,2)+2*(beta[j+3]+beta[j+4]+delta[j+3]+gamma[j+4]*(yppp+1)+delta[j+4]*yppp)*xppp))*Gausssum1d(0,xppp+beta[j+3]+beta[j+4]+delta[j+3]+gamma[j+4]*(yppp+1)+delta[j+4]*yppp+gamma[j+5]+delta[j+5])*Kroneck(gamma[j+3]+delta[j+3]-gamma[j+4]-delta[j+4]+1)*Kroneck(alpha[j+5]+beta[j+5])));
		    }
		  }
		}
	      }
	    }
	  }
	}
      }


      // ninth term
      for(y=0; y<=1; y++) {
	for(x=(y*(delta[i]+delta[i+1]))%2; x<=(1+y*(gamma[i]+gamma[i+1]))%2; x++) {
	  for(yp=y; yp<=1; yp++) {
	    for(xp=(yp*(delta[i+3]+delta[i+4])+y)%2;xp<=(1+yp*(gamma[i+3]+gamma[i+4])+y)%2; xp++) {
	      //for(ypp=0; ypp<=1; ypp++) {
	      for(ypp=((gamma[j]+delta[j+1])*(y+yp))%2;ypp<=(1+(gamma[j]+gamma[j+1])*(y+yp))%2;ypp++) {
		//**for(xpp=0;xpp<=(ypp*(gamma[j]+gamma[j+1])+(ypp+1)*(gamma[j]+delta[j+1]))%2; xpp++) {
		for(xpp=ypp*(beta[j]+alpha[j+1]+beta[j+1])%2;xpp<=(ypp*(beta[j]+alpha[j+1]+beta[j+1])+ypp*(gamma[j]+gamma[j+1])+(ypp+1)*(gamma[j]+delta[j+1]))%2; xpp++) {
		  //for(yppp=((gamma[j+3]+delta[j+4])*xpp)%2; yppp<=(1+(gamma[j+3]+gamma[j+4])*xpp)%2; yppp++) {
		  for(yppp=((gamma[j+3]+delta[j+4])*(y+yp+xpp))%2; yppp<=(1+(gamma[j+3]+gamma[j+4])*(y+yp+xpp))%2; yppp++) {
		    //**for(xppp=0;xppp<=(yppp*(gamma[j+3]+gamma[j+4])+(yppp+1)*(gamma[j+3]+delta[j+4]))%2; xppp++) {
		    for(xppp=yppp*(beta[j+3]+alpha[j+4]+beta[j+4])%2;xppp<=(yppp*(beta[j+3]+alpha[j+4]+beta[j+4])+yppp*(gamma[j+3]+gamma[j+4])+(yppp+1)*(gamma[j+3]+delta[j+4]))%2; xppp++) {
		      //summand += (2.0*(0.125*pow(2.0,(pow(y-1,2)*(pow(x,2)*(gamma[i]+delta[i+1])+pow(x-1,2)*(gamma[i+1]+delta[i])))*(pow(yp-1,2)*(pow(xp,2)*(gamma[i+3]+delta[i+4])+pow(xp-1,2)*(gamma[i+4]+delta[i+3]))))*(-I)*cexp(M_PI*I/2.0*(y*(delta[i]+delta[i+1])+pow(y+1,2)*(delta[i]+gamma[i+1]+2*beta[i+1])+pow(x,2)+2*(beta[i]+beta[i+1]+delta[i]+gamma[i+1]*(y+1)+delta[i+1]*y)*x))*Gausssum1d(0,x+beta[i]+beta[i+1]+delta[i]+gamma[i+1]*(y+1)+delta[i+1]*y+gamma[i+2]+delta[i+2])*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1]+1)*Kroneck(alpha[i+2]+beta[i+2]))
		      summand += 2.0*(2.0*(0.125*pow(2.0,(pow(y-1,2)*(pow(x,2)*(gamma[i]+delta[i+1])+pow(x-1,2)*(gamma[i+1]+delta[i])))*(pow(yp-1,2)*(pow(xp,2)*(gamma[i+3]+delta[i+4])+pow(xp-1,2)*(gamma[i+4]+delta[i+3])))*(1-ypp*pow(gamma[j]-gamma[j+1],2)-pow(ypp-1,2)*pow(gamma[j]-delta[j+1],2))*(1-yppp*pow(gamma[j+3]-gamma[j+4],2)-pow(yppp-1,2)*pow(gamma[j+3]-delta[j+4],2)))*(-I)*cexp(M_PI*I/2.0*(y*(delta[i]+delta[i+1])+pow(y+1,2)*(delta[i]+gamma[i+1]+2*beta[i+1])+pow(x,2)+2*(beta[i]+beta[i+1]+delta[i]+gamma[i+1]*(y+1)+delta[i+1]*y)*x))*Gausssum1d(0,x+beta[i]+beta[i+1]+delta[i]+gamma[i+1]*(y+1)+delta[i+1]*y+gamma[i+2]+delta[i+2])*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1]+1)*Kroneck(alpha[i+2]+beta[i+2]))
				  *(0.125*(-I)*cexp(M_PI*I/2.0*(yp*(delta[i+3]+delta[i+4])+pow(yp+1,2)*(delta[i+3]+gamma[i+4]+2*beta[i+4])+pow(xp,2)+2*(beta[i+3]+beta[i+4]+delta[i+3]+gamma[i+4]*(yp+1)+delta[i+4]*yp)*xp))*Gausssum1d(0,xp+beta[i+3]+beta[i+4]+delta[i+3]+gamma[i+4]*(yp+1)+delta[i+4]*yp+gamma[i+5]+delta[i+5])*Kroneck(gamma[i+3]+delta[i+3]-gamma[i+4]-delta[i+4]+1)*Kroneck(alpha[i+5]+beta[i+5])))
			//*(2.0*(0.125*pow(2.0,(1-ypp*pow(gamma[j]-gamma[j+1],2)-pow(ypp-1,2)*pow(gamma[j]-delta[j+1],2))*(1-yppp*pow(gamma[j+3]-gamma[j+4],2)-pow(yppp-1,2)*pow(gamma[j+3]-delta[j+4],2)))*cexp(M_PI*I/2.0*((delta[j+1]-gamma[j])*pow(ypp+1,2)+2.0*(beta[j]+beta[j+1]+gamma[j]+delta[j+1])*xpp*pow(ypp+1,2)+2.0*(delta[j]+delta[j+1]+beta[j]+beta[j+1])*xpp*ypp+(2.0*beta[j]+3.0*delta[j]+delta[j+1])*ypp))*Gausssum1d(0.0,beta[j+2])*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1])*Kroneck(gamma[j+2]+delta[j+2]) 
			*(2.0*(0.125*cexp(M_PI*I/2.0*((delta[j+1]-gamma[j])*pow(ypp+1,2)+2.0*(beta[j]+beta[j+1]+gamma[j]+delta[j+1])*xpp*pow(ypp+1,2)+2.0*(delta[j]+delta[j+1]+beta[j]+beta[j+1])*xpp*ypp+(2.0*beta[j]+3.0*delta[j]+delta[j+1])*ypp))*Gausssum1d(0.0,beta[j+2])*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1])*Kroneck(gamma[j+2]+delta[j+2]) 
			       //+ 0.125*pow(2.0,(1-ypp*pow(gamma[j]-gamma[j+1],2)-pow(ypp-1,2)*pow(gamma[j]-delta[j+1],2))*(1-yppp*pow(gamma[j+3]-gamma[j+4],2)-pow(yppp-1,2)*pow(gamma[j+3]-delta[j+4],2)))*cexp(M_PI*I/2.0*((delta[j+1]-gamma[j])*pow(ypp+1,2)+2.0*(beta[j]+beta[j+1]+gamma[j]+delta[j+1])*xpp*pow(ypp+1,2)+2.0*(delta[j]+delta[j+1]+beta[j]+beta[j+1])*xpp*ypp+(2.0*beta[j]+3.0*delta[j]+delta[j+1])*ypp))*csqrt(-I)*Gausssum1d(gamma[j+2]+delta[j+2],0)*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1])*Kroneck(alpha[j+2]+beta[j+2]))
			       + 0.125*cexp(M_PI*I/2.0*((delta[j+1]-gamma[j])*pow(ypp+1,2)+2.0*(beta[j]+beta[j+1]+gamma[j]+delta[j+1])*xpp*pow(ypp+1,2)+2.0*(delta[j]+delta[j+1]+beta[j]+beta[j+1])*xpp*ypp+(2.0*beta[j]+3.0*delta[j]+delta[j+1])*ypp))*csqrt(-I)*Gausssum1d(gamma[j+2]+delta[j+2],0)*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1])*Kroneck(alpha[j+2]+beta[j+2]))
			*(0.125*cexp(M_PI*I/2.0*((delta[j+4]-gamma[j+3])*pow(yppp+1,2)+2.0*(beta[j+3]+beta[j+4]+gamma[j+3]+delta[j+4])*xppp*pow(yppp+1,2)+2.0*(delta[j+3]+delta[j+4]+beta[j+3]+beta[j+4])*xppp*yppp+(2.0*beta[j+3]+3.0*delta[j+3]+delta[j+4])*yppp))*Gausssum1d(0.0,beta[j+5])*Kroneck(gamma[j+3]+delta[j+3]-gamma[j+4]-delta[j+4])*Kroneck(gamma[j+5]+delta[j+5]) 
			  + 0.125*cexp(M_PI*I/2.0*((delta[j+4]-gamma[j+3])*pow(yppp+1,2)+2.0*(beta[j+3]+beta[j+4]+gamma[j+3]+delta[j+4])*xppp*pow(yppp+1,2)+2.0*(delta[j+3]+delta[j+4]+beta[j+3]+beta[j+4])*xppp*yppp+(2.0*beta[j+3]+3.0*delta[j+3]+delta[j+4])*yppp))*csqrt(-I)*Gausssum1d(gamma[j+5]+delta[j+5],0)*Kroneck(gamma[j+3]+delta[j+3]-gamma[j+4]-delta[j+4])*Kroneck(alpha[j+5]+beta[j+5])));
		    }
		  }
		}
	      }
	      for(ypp=0; ypp<=1; ypp++) {
		//**for(xpp=0;xpp<=(ypp*(gamma[j]+gamma[j+1])+(ypp+1)*(gamma[j]+delta[j+1]))%2; xpp++) {
		for(xpp=ypp*(beta[j]+alpha[j+1]+beta[j+1])%2;xpp<=(ypp*(beta[j]+alpha[j+1]+beta[j+1])+ypp*(gamma[j]+gamma[j+1])+(ypp+1)*(gamma[j]+delta[j+1]))%2; xpp++) {
		  for(yppp=0; yppp<=(1+alpha[j+5])%2; yppp++) {
		    for(xppp=0;xppp<=(1+beta[j+5])%2; xppp++) {
		      summand += (2.0*(0.125*pow(2.0,(pow(y-1,2)*(pow(x,2)*(gamma[i]+delta[i+1])+pow(x-1,2)*(gamma[i+1]+delta[i])))*(pow(yp-1,2)*(pow(xp,2)*(gamma[i+3]+delta[i+4])+pow(xp-1,2)*(gamma[i+4]+delta[i+3]))))*(-I)*cexp(M_PI*I/2.0*(y*(delta[i]+delta[i+1])+pow(y+1,2)*(delta[i]+gamma[i+1]+2*beta[i+1])+pow(x,2)+2*(beta[i]+beta[i+1]+delta[i]+gamma[i+1]*(y+1)+delta[i+1]*y)*x))*Gausssum1d(0,x+beta[i]+beta[i+1]+delta[i]+gamma[i+1]*(y+1)+delta[i+1]*y+gamma[i+2]+delta[i+2])*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1]+1)*Kroneck(alpha[i+2]+beta[i+2]))
				  *(0.125*(-I)*cexp(M_PI*I/2.0*(yp*(delta[i+3]+delta[i+4])+pow(yp+1,2)*(delta[i+3]+gamma[i+4]+2*beta[i+4])+pow(xp,2)+2*(beta[i+3]+beta[i+4]+delta[i+3]+gamma[i+4]*(yp+1)+delta[i+4]*yp)*xp))*Gausssum1d(0,xp+beta[i+3]+beta[i+4]+delta[i+3]+gamma[i+4]*(yp+1)+delta[i+4]*yp+gamma[i+5]+delta[i+5])*Kroneck(gamma[i+3]+delta[i+3]-gamma[i+4]-delta[i+4]+1)*Kroneck(alpha[i+5]+beta[i+5])))
			*((0.125*pow(2.0,1-ypp*pow(gamma[j]-gamma[j+1],2)-pow(ypp-1,2)*pow(gamma[j]-delta[j+1],2))*cexp(M_PI*I/2.0*((delta[j+1]-gamma[j])*pow(ypp+1,2)+2.0*(beta[j]+beta[j+1]+gamma[j]+delta[j+1])*xpp*pow(ypp+1,2)+2.0*(delta[j]+delta[j+1]+beta[j]+beta[j+1])*xpp*ypp+(2.0*beta[j]+3.0*delta[j]+delta[j+1])*ypp))*Gausssum1d(0.0,beta[j+2])*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1])*Kroneck(gamma[j+2]+delta[j+2]) 
				  + 0.125*pow(2.0,1-ypp*pow(gamma[j]-gamma[j+1],2)-pow(ypp-1,2)*pow(gamma[j]-delta[j+1],2))*cexp(M_PI*I/2.0*((delta[j+1]-gamma[j])*pow(ypp+1,2)+2.0*(beta[j]+beta[j+1]+gamma[j]+delta[j+1])*xpp*pow(ypp+1,2)+2.0*(delta[j]+delta[j+1]+beta[j]+beta[j+1])*xpp*ypp+(2.0*beta[j]+3.0*delta[j]+delta[j+1])*ypp))*csqrt(-I)*Gausssum1d(gamma[j+2]+delta[j+2],0)*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1])*Kroneck(alpha[j+2]+beta[j+2]))
			  *(0.125*2.0*csqrt(-I)*cexp(M_PI*I/2.0*(2.0*beta[j+5]*yppp+pow(xppp+1,2)*(delta[j+3]+gamma[j+4]+2.0*beta[j+4])+xppp*(delta[j+3]+delta[j+4])))*Gausssum1d(1,beta[j+3]+beta[j+4]+delta[j+3]+(xppp+1)*gamma[j+4]+xppp*delta[j+4])*Kroneck(gamma[j+3]+delta[j+3]-gamma[j+4]-delta[j+4]+1)*Kroneck(gamma[j+5]+delta[j+5])));
		    }
		  }
		}
	      }
	      //for(ypp=0; ypp<=1; ypp++) {
	      for(ypp=((gamma[j]+delta[j+1])*(y+yp))%2;ypp<=(1+(gamma[j]+gamma[j+1])*(y+yp))%2;ypp++) {
		//**for(xpp=0;xpp<=(ypp*(gamma[j]+gamma[j+1])+(ypp+1)*(gamma[j]+delta[j+1]))%2; xpp++) {
		for(xpp=ypp*(beta[j]+alpha[j+1]+beta[j+1])%2;xpp<=(ypp*(beta[j]+alpha[j+1]+beta[j+1])+ypp*(gamma[j]+gamma[j+1])+(ypp+1)*(gamma[j]+delta[j+1]))%2; xpp++) {
		  //for(yppp=xpp; yppp<=1; yppp++) {
		  //**for(yppp=(y+yp+xpp)%2; yppp<=1; yppp++) {
		  for(yppp=(y+yp+xpp*(1+alpha[j]+beta[j]))%2; yppp<=1; yppp++) {
		    //for(xppp=(yppp*(delta[j+3]+delta[j+4])+xpp)%2;xppp<=(1+yppp*(gamma[j+3]+gamma[j+4])+xpp)%2; xppp++) {
		    //**for(xppp=(yppp*(delta[j+3]+delta[j+4])+(y+yp+xpp))%2;xppp<=(1+yppp*(gamma[j+3]+gamma[j+4])+(y+yp+xpp))%2; xppp++) {
		    for(xppp=(yppp*(delta[j+3]+delta[j+4])+(y+yp+xpp*(1+alpha[j]+beta[j])))%2;xppp<=(1+yppp*(gamma[j+3]+gamma[j+4])+(y+yp+xpp*(1+alpha[j]+beta[j])))%2; xppp++) {
		      //summand += (2.0*(0.125*pow(2.0,(pow(y-1,2)*(pow(x,2)*(gamma[i]+delta[i+1])+pow(x-1,2)*(gamma[i+1]+delta[i])))*(pow(yp-1,2)*(pow(xp,2)*(gamma[i+3]+delta[i+4])+pow(xp-1,2)*(gamma[i+4]+delta[i+3]))))*(-I)*cexp(M_PI*I/2.0*(y*(delta[i]+delta[i+1])+pow(y+1,2)*(delta[i]+gamma[i+1]+2*beta[i+1])+pow(x,2)+2*(beta[i]+beta[i+1]+delta[i]+gamma[i+1]*(y+1)+delta[i+1]*y)*x))*Gausssum1d(0,x+beta[i]+beta[i+1]+delta[i]+gamma[i+1]*(y+1)+delta[i+1]*y+gamma[i+2]+delta[i+2])*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1]+1)*Kroneck(alpha[i+2]+beta[i+2]))
		      summand += 2.0*(2.0*(0.125*pow(2.0,(pow(y-1,2)*(pow(x,2)*(gamma[i]+delta[i+1])+pow(x-1,2)*(gamma[i+1]+delta[i])))*(pow(yp-1,2)*(pow(xp,2)*(gamma[i+3]+delta[i+4])+pow(xp-1,2)*(gamma[i+4]+delta[i+3])))*(1-ypp*pow(gamma[j]-gamma[j+1],2)-pow(ypp-1,2)*pow(gamma[j]-delta[j+1],2))*(pow(yppp-1,2)*(pow(xppp,2)*(gamma[j+3]+delta[j+4])+pow(xppp-1,2)*(gamma[j+4]+delta[j+3]))))*(-I)*cexp(M_PI*I/2.0*(y*(delta[i]+delta[i+1])+pow(y+1,2)*(delta[i]+gamma[i+1]+2*beta[i+1])+pow(x,2)+2*(beta[i]+beta[i+1]+delta[i]+gamma[i+1]*(y+1)+delta[i+1]*y)*x))*Gausssum1d(0,x+beta[i]+beta[i+1]+delta[i]+gamma[i+1]*(y+1)+delta[i+1]*y+gamma[i+2]+delta[i+2])*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1]+1)*Kroneck(alpha[i+2]+beta[i+2]))
				  *(0.125*(-I)*cexp(M_PI*I/2.0*(yp*(delta[i+3]+delta[i+4])+pow(yp+1,2)*(delta[i+3]+gamma[i+4]+2*beta[i+4])+pow(xp,2)+2*(beta[i+3]+beta[i+4]+delta[i+3]+gamma[i+4]*(yp+1)+delta[i+4]*yp)*xp))*Gausssum1d(0,xp+beta[i+3]+beta[i+4]+delta[i+3]+gamma[i+4]*(yp+1)+delta[i+4]*yp+gamma[i+5]+delta[i+5])*Kroneck(gamma[i+3]+delta[i+3]-gamma[i+4]-delta[i+4]+1)*Kroneck(alpha[i+5]+beta[i+5])))
			//*(2.0*(0.125*pow(2.0,(1-ypp*pow(gamma[j]-gamma[j+1],2)-pow(ypp-1,2)*pow(gamma[j]-delta[j+1],2))*(pow(yppp-1,2)*(pow(xppp,2)*(gamma[j+3]+delta[j+4])+pow(xppp-1,2)*(gamma[j+4]+delta[j+3]))))*cexp(M_PI*I/2.0*((delta[j+1]-gamma[j])*pow(ypp+1,2)+2.0*(beta[j]+beta[j+1]+gamma[j]+delta[j+1])*xpp*pow(ypp+1,2)+2.0*(delta[j]+delta[j+1]+beta[j]+beta[j+1])*xpp*ypp+(2.0*beta[j]+3.0*delta[j]+delta[j+1])*ypp))*Gausssum1d(0.0,beta[j+2])*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1])*Kroneck(gamma[j+2]+delta[j+2]) 
			*(2.0*(0.125*cexp(M_PI*I/2.0*((delta[j+1]-gamma[j])*pow(ypp+1,2)+2.0*(beta[j]+beta[j+1]+gamma[j]+delta[j+1])*xpp*pow(ypp+1,2)+2.0*(delta[j]+delta[j+1]+beta[j]+beta[j+1])*xpp*ypp+(2.0*beta[j]+3.0*delta[j]+delta[j+1])*ypp))*Gausssum1d(0.0,beta[j+2])*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1])*Kroneck(gamma[j+2]+delta[j+2]) 
			       //+ 0.125*pow(2.0,(1-ypp*pow(gamma[j]-gamma[j+1],2)-pow(ypp-1,2)*pow(gamma[j]-delta[j+1],2))*(pow(yppp-1,2)*(pow(xppp,2)*(gamma[j+3]+delta[j+4])+pow(xppp-1,2)*(gamma[j+4]+delta[j+3]))))*cexp(M_PI*I/2.0*((delta[j+1]-gamma[j])*pow(ypp+1,2)+2.0*(beta[j]+beta[j+1]+gamma[j]+delta[j+1])*xpp*pow(ypp+1,2)+2.0*(delta[j]+delta[j+1]+beta[j]+beta[j+1])*xpp*ypp+(2.0*beta[j]+3.0*delta[j]+delta[j+1])*ypp))*csqrt(-I)*Gausssum1d(gamma[j+2]+delta[j+2],0)*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1])*Kroneck(alpha[j+2]+beta[j+2]))
			       + 0.125*cexp(M_PI*I/2.0*((delta[j+1]-gamma[j])*pow(ypp+1,2)+2.0*(beta[j]+beta[j+1]+gamma[j]+delta[j+1])*xpp*pow(ypp+1,2)+2.0*(delta[j]+delta[j+1]+beta[j]+beta[j+1])*xpp*ypp+(2.0*beta[j]+3.0*delta[j]+delta[j+1])*ypp))*csqrt(-I)*Gausssum1d(gamma[j+2]+delta[j+2],0)*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1])*Kroneck(alpha[j+2]+beta[j+2]))
			  *(0.125*(-I)*cexp(M_PI*I/2.0*(yppp*(delta[j+3]+delta[j+4])+pow(yppp+1,2)*(delta[j+3]+gamma[j+4]+2*beta[j+4])+pow(xppp,2)+2*(beta[j+3]+beta[j+4]+delta[j+3]+gamma[j+4]*(yppp+1)+delta[j+4]*yppp)*xppp))*Gausssum1d(0,xppp+beta[j+3]+beta[j+4]+delta[j+3]+gamma[j+4]*(yppp+1)+delta[j+4]*yppp+gamma[j+5]+delta[j+5])*Kroneck(gamma[j+3]+delta[j+3]-gamma[j+4]-delta[j+4]+1)*Kroneck(alpha[j+5]+beta[j+5])));
		    }
		  }
		}
	      }

	      for(ypp=0; ypp<=(1+alpha[j+2])%2; ypp++) {
		for(xpp=0; xpp<=(1+beta[j+2])%2; xpp++) {
		  for(yppp=0; yppp<=1; yppp++) {
		    //**for(xppp=0;xppp<=(yppp*(gamma[j+3]+gamma[j+4])+(yppp+1)*(gamma[j+3]+delta[j+4]))%2; xppp++) {
		    for(xppp=yppp*(beta[j+3]+alpha[j+4]+beta[j+4])%2;xppp<=(yppp*(beta[j+3]+alpha[j+4]+beta[j+4])+yppp*(gamma[j+3]+gamma[j+4])+(yppp+1)*(gamma[j+3]+delta[j+4]))%2; xppp++) {
		      summand += (2.0*(0.125*pow(2.0,(pow(y-1,2)*(pow(x,2)*(gamma[i]+delta[i+1])+pow(x-1,2)*(gamma[i+1]+delta[i])))*(pow(yp-1,2)*(pow(xp,2)*(gamma[i+3]+delta[i+4])+pow(xp-1,2)*(gamma[i+4]+delta[i+3]))))*(-I)*cexp(M_PI*I/2.0*(y*(delta[i]+delta[i+1])+pow(y+1,2)*(delta[i]+gamma[i+1]+2*beta[i+1])+pow(x,2)+2*(beta[i]+beta[i+1]+delta[i]+gamma[i+1]*(y+1)+delta[i+1]*y)*x))*Gausssum1d(0,x+beta[i]+beta[i+1]+delta[i]+gamma[i+1]*(y+1)+delta[i+1]*y+gamma[i+2]+delta[i+2])*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1]+1)*Kroneck(alpha[i+2]+beta[i+2]))
				  *(0.125*(-I)*cexp(M_PI*I/2.0*(yp*(delta[i+3]+delta[i+4])+pow(yp+1,2)*(delta[i+3]+gamma[i+4]+2*beta[i+4])+pow(xp,2)+2*(beta[i+3]+beta[i+4]+delta[i+3]+gamma[i+4]*(yp+1)+delta[i+4]*yp)*xp))*Gausssum1d(0,xp+beta[i+3]+beta[i+4]+delta[i+3]+gamma[i+4]*(yp+1)+delta[i+4]*yp+gamma[i+5]+delta[i+5])*Kroneck(gamma[i+3]+delta[i+3]-gamma[i+4]-delta[i+4]+1)*Kroneck(alpha[i+5]+beta[i+5])))
			*((0.125*2.0*csqrt(-I)*cexp(M_PI*I/2.0*(2.0*beta[j+2]*ypp+pow(xpp+1,2)*(delta[j]+gamma[j+1]+2.0*beta[j+1])+xpp*(delta[j]+delta[j+1])))*Gausssum1d(1,beta[j]+beta[j+1]+delta[j]+(xpp+1)*gamma[j+1]+xpp*delta[j+1])*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1]+1)*Kroneck(gamma[j+2]+delta[j+2]))
			  *(0.125*pow(2.0,1-yppp*pow(gamma[j+3]-gamma[j+4],2)-pow(yppp-1,2)*pow(gamma[j+3]-delta[j+4],2))*cexp(M_PI*I/2.0*((delta[j+4]-gamma[j+3])*pow(yppp+1,2)+2.0*(beta[j+3]+beta[j+4]+gamma[j+3]+delta[j+4])*xppp*pow(yppp+1,2)+2.0*(delta[j+3]+delta[j+4]+beta[j+3]+beta[j+4])*xppp*yppp+(2.0*beta[j+3]+3.0*delta[j+3]+delta[j+4])*yppp))*Gausssum1d(0.0,beta[j+5])*Kroneck(gamma[j+3]+delta[j+3]-gamma[j+4]-delta[j+4])*Kroneck(gamma[j+5]+delta[j+5]) 
			    + 0.125*pow(2.0,1-yppp*pow(gamma[j+3]-gamma[j+4],2)-pow(yppp-1,2)*pow(gamma[j+3]-delta[j+4],2))*cexp(M_PI*I/2.0*((delta[j+4]-gamma[j+3])*pow(yppp+1,2)+2.0*(beta[j+3]+beta[j+4]+gamma[j+3]+delta[j+4])*xppp*pow(yppp+1,2)+2.0*(delta[j+3]+delta[j+4]+beta[j+3]+beta[j+4])*xppp*yppp+(2.0*beta[j+3]+3.0*delta[j+3]+delta[j+4])*yppp))*csqrt(-I)*Gausssum1d(gamma[j+5]+delta[j+5],0)*Kroneck(gamma[j+3]+delta[j+3]-gamma[j+4]-delta[j+4])*Kroneck(alpha[j+5]+beta[j+5])));
		    }
		  }
		  for(yppp=0; yppp<=(1+alpha[j+5])%2; yppp++) {
		    for(xppp=0;xppp<=(1+beta[j+5])%2; xppp++) {
		      summand += (2.0*(0.125*pow(2.0,(pow(y-1,2)*(pow(x,2)*(gamma[i]+delta[i+1])+pow(x-1,2)*(gamma[i+1]+delta[i])))*(pow(yp-1,2)*(pow(xp,2)*(gamma[i+3]+delta[i+4])+pow(xp-1,2)*(gamma[i+4]+delta[i+3]))))*(-I)*cexp(M_PI*I/2.0*(y*(delta[i]+delta[i+1])+pow(y+1,2)*(delta[i]+gamma[i+1]+2*beta[i+1])+pow(x,2)+2*(beta[i]+beta[i+1]+delta[i]+gamma[i+1]*(y+1)+delta[i+1]*y)*x))*Gausssum1d(0,x+beta[i]+beta[i+1]+delta[i]+gamma[i+1]*(y+1)+delta[i+1]*y+gamma[i+2]+delta[i+2])*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1]+1)*Kroneck(alpha[i+2]+beta[i+2]))
				  *(0.125*(-I)*cexp(M_PI*I/2.0*(yp*(delta[i+3]+delta[i+4])+pow(yp+1,2)*(delta[i+3]+gamma[i+4]+2*beta[i+4])+pow(xp,2)+2*(beta[i+3]+beta[i+4]+delta[i+3]+gamma[i+4]*(yp+1)+delta[i+4]*yp)*xp))*Gausssum1d(0,xp+beta[i+3]+beta[i+4]+delta[i+3]+gamma[i+4]*(yp+1)+delta[i+4]*yp+gamma[i+5]+delta[i+5])*Kroneck(gamma[i+3]+delta[i+3]-gamma[i+4]-delta[i+4]+1)*Kroneck(alpha[i+5]+beta[i+5])))
			*((0.125*2.0*csqrt(-I)*cexp(M_PI*I/2.0*(2.0*beta[j+2]*ypp+pow(xpp+1,2)*(delta[j]+gamma[j+1]+2.0*beta[j+1])+xpp*(delta[j]+delta[j+1])))*Gausssum1d(1,beta[j]+beta[j+1]+delta[j]+(xpp+1)*gamma[j+1]+xpp*delta[j+1])*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1]+1)*Kroneck(gamma[j+2]+delta[j+2]))
			  *(0.125*2.0*csqrt(-I)*cexp(M_PI*I/2.0*(2.0*beta[j+5]*yppp+pow(xppp+1,2)*(delta[j+3]+gamma[j+4]+2.0*beta[j+4])+xppp*(delta[j+3]+delta[j+4])))*Gausssum1d(1,beta[j+3]+beta[j+4]+delta[j+3]+(xppp+1)*gamma[j+4]+xppp*delta[j+4])*Kroneck(gamma[j+3]+delta[j+3]-gamma[j+4]-delta[j+4]+1)*Kroneck(gamma[j+5]+delta[j+5])));
		    }
		  }
		  for(yppp=0; yppp<=1; yppp++) {
		    for(xppp=(yppp*(delta[j+3]+delta[j+4]))%2;xppp<=(1+yppp*(gamma[j+3]+gamma[j+4]))%2; xppp++) {
		      summand += (2.0*(0.125*pow(2.0,(pow(y-1,2)*(pow(x,2)*(gamma[i]+delta[i+1])+pow(x-1,2)*(gamma[i+1]+delta[i])))*(pow(yp-1,2)*(pow(xp,2)*(gamma[i+3]+delta[i+4])+pow(xp-1,2)*(gamma[i+4]+delta[i+3]))))*(-I)*cexp(M_PI*I/2.0*(y*(delta[i]+delta[i+1])+pow(y+1,2)*(delta[i]+gamma[i+1]+2*beta[i+1])+pow(x,2)+2*(beta[i]+beta[i+1]+delta[i]+gamma[i+1]*(y+1)+delta[i+1]*y)*x))*Gausssum1d(0,x+beta[i]+beta[i+1]+delta[i]+gamma[i+1]*(y+1)+delta[i+1]*y+gamma[i+2]+delta[i+2])*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1]+1)*Kroneck(alpha[i+2]+beta[i+2]))
				  *(0.125*(-I)*cexp(M_PI*I/2.0*(yp*(delta[i+3]+delta[i+4])+pow(yp+1,2)*(delta[i+3]+gamma[i+4]+2*beta[i+4])+pow(xp,2)+2*(beta[i+3]+beta[i+4]+delta[i+3]+gamma[i+4]*(yp+1)+delta[i+4]*yp)*xp))*Gausssum1d(0,xp+beta[i+3]+beta[i+4]+delta[i+3]+gamma[i+4]*(yp+1)+delta[i+4]*yp+gamma[i+5]+delta[i+5])*Kroneck(gamma[i+3]+delta[i+3]-gamma[i+4]-delta[i+4]+1)*Kroneck(alpha[i+5]+beta[i+5])))
			*((0.125*2.0*csqrt(-I)*cexp(M_PI*I/2.0*(2.0*beta[j+2]*ypp+pow(xpp+1,2)*(delta[j]+gamma[j+1]+2.0*beta[j+1])+xpp*(delta[j]+delta[j+1])))*Gausssum1d(1,beta[j]+beta[j+1]+delta[j]+(xpp+1)*gamma[j+1]+xpp*delta[j+1])*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1]+1)*Kroneck(gamma[j+2]+delta[j+2]))
			  *(0.125*(-I)*pow(2.0,(pow(yppp-1,2)*(pow(xppp,2)*(gamma[j+3]+delta[j+4])+pow(xppp-1,2)*(gamma[j+4]+delta[j+3]))))*cexp(M_PI*I/2.0*(yppp*(delta[j+3]+delta[j+4])+pow(yppp+1,2)*(delta[j+3]+gamma[j+4]+2*beta[j+4])+pow(xppp,2)+2*(beta[j+3]+beta[j+4]+delta[j+3]+gamma[j+4]*(yppp+1)+delta[j+4]*yppp)*xppp))*Gausssum1d(0,xppp+beta[j+3]+beta[j+4]+delta[j+3]+gamma[j+4]*(yppp+1)+delta[j+4]*yppp+gamma[j+5]+delta[j+5])*Kroneck(gamma[j+3]+delta[j+3]-gamma[j+4]-delta[j+4]+1)*Kroneck(alpha[j+5]+beta[j+5])));
		    }
		  }
		}
	      }

	      //for(ypp=0; ypp<=1; ypp++) {
	      for(ypp=(y+yp)%2; ypp<=1; ypp++) {
		//for(xpp=(ypp*(delta[j]+delta[j+1]))%2; xpp<=(1+ypp*(gamma[j]+gamma[j+1]))%2; xpp++) {
		for(xpp=(ypp*(delta[j]+delta[j+1])+y+yp)%2; xpp<=(1+ypp*(gamma[j]+gamma[j+1])+y+yp)%2; xpp++) {
		  //for(yppp=((gamma[j+3]+delta[j+4])*ypp)%2; yppp<=(1+(gamma[j+3]+gamma[j+4])*ypp)%2; yppp++) {
		  for(yppp=((gamma[j+3]+delta[j+4])*(y+yp+ypp))%2; yppp<=(1+(gamma[j+3]+gamma[j+4])*(y+yp+ypp))%2; yppp++) {
		    //**for(xppp=0;xppp<=(yppp*(gamma[j+3]+gamma[j+4])+(yppp+1)*(gamma[j+3]+delta[j+4]))%2; xppp++) {
		    for(xppp=yppp*(beta[j+3]+alpha[j+4]+beta[j+4])%2;xppp<=(yppp*(beta[j+3]+alpha[j+4]+beta[j+4])+yppp*(gamma[j+3]+gamma[j+4])+(yppp+1)*(gamma[j+3]+delta[j+4]))%2; xppp++) {
		      //summand += (2.0*(0.125*pow(2.0,(pow(y-1,2)*(pow(x,2)*(gamma[i]+delta[i+1])+pow(x-1,2)*(gamma[i+1]+delta[i])))*(pow(yp-1,2)*(pow(xp,2)*(gamma[i+3]+delta[i+4])+pow(xp-1,2)*(gamma[i+4]+delta[i+3]))))*(-I)*cexp(M_PI*I/2.0*(y*(delta[i]+delta[i+1])+pow(y+1,2)*(delta[i]+gamma[i+1]+2*beta[i+1])+pow(x,2)+2*(beta[i]+beta[i+1]+delta[i]+gamma[i+1]*(y+1)+delta[i+1]*y)*x))*Gausssum1d(0,x+beta[i]+beta[i+1]+delta[i]+gamma[i+1]*(y+1)+delta[i+1]*y+gamma[i+2]+delta[i+2])*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1]+1)*Kroneck(alpha[i+2]+beta[i+2]))
		      summand += 2.0*(2.0*(0.125*pow(2.0,(pow(y-1,2)*(pow(x,2)*(gamma[i]+delta[i+1])+pow(x-1,2)*(gamma[i+1]+delta[i])))*(pow(yp-1,2)*(pow(xp,2)*(gamma[i+3]+delta[i+4])+pow(xp-1,2)*(gamma[i+4]+delta[i+3])))*(pow(ypp-1,2)*(pow(xpp,2)*(gamma[j]+delta[j+1])+pow(xpp-1,2)*(gamma[j+1]+delta[j])))*(1-yppp*pow(gamma[j+3]-gamma[j+4],2)-pow(yppp-1,2)*pow(gamma[j+3]-delta[j+4],2)))*(-I)*cexp(M_PI*I/2.0*(y*(delta[i]+delta[i+1])+pow(y+1,2)*(delta[i]+gamma[i+1]+2*beta[i+1])+pow(x,2)+2*(beta[i]+beta[i+1]+delta[i]+gamma[i+1]*(y+1)+delta[i+1]*y)*x))*Gausssum1d(0,x+beta[i]+beta[i+1]+delta[i]+gamma[i+1]*(y+1)+delta[i+1]*y+gamma[i+2]+delta[i+2])*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1]+1)*Kroneck(alpha[i+2]+beta[i+2]))
				  *(0.125*(-I)*cexp(M_PI*I/2.0*(yp*(delta[i+3]+delta[i+4])+pow(yp+1,2)*(delta[i+3]+gamma[i+4]+2*beta[i+4])+pow(xp,2)+2*(beta[i+3]+beta[i+4]+delta[i+3]+gamma[i+4]*(yp+1)+delta[i+4]*yp)*xp))*Gausssum1d(0,xp+beta[i+3]+beta[i+4]+delta[i+3]+gamma[i+4]*(yp+1)+delta[i+4]*yp+gamma[i+5]+delta[i+5])*Kroneck(gamma[i+3]+delta[i+3]-gamma[i+4]-delta[i+4]+1)*Kroneck(alpha[i+5]+beta[i+5])))
			//*(2.0*(0.125*pow(2.0,(pow(ypp-1,2)*(pow(xpp,2)*(gamma[j]+delta[j+1])+pow(xpp-1,2)*(gamma[j+1]+delta[j])))*(1-yppp*pow(gamma[j+3]-gamma[j+4],2)-pow(yppp-1,2)*pow(gamma[j+3]-delta[j+4],2)))*(-I)*cexp(M_PI*I/2.0*(ypp*(delta[j]+delta[j+1])+pow(ypp+1,2)*(delta[j]+gamma[j+1]+2*beta[j+1])+pow(xpp,2)+2*(beta[j]+beta[j+1]+delta[j]+gamma[j+1]*(ypp+1)+delta[j+1]*ypp)*xpp))*Gausssum1d(0,xpp+beta[j]+beta[j+1]+delta[j]+gamma[j+1]*(ypp+1)+delta[j+1]*ypp+gamma[j+2]+delta[j+2])*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1]+1)*Kroneck(alpha[j+2]+beta[j+2]))
			*(2.0*(0.125*(-I)*cexp(M_PI*I/2.0*(ypp*(delta[j]+delta[j+1])+pow(ypp+1,2)*(delta[j]+gamma[j+1]+2*beta[j+1])+pow(xpp,2)+2*(beta[j]+beta[j+1]+delta[j]+gamma[j+1]*(ypp+1)+delta[j+1]*ypp)*xpp))*Gausssum1d(0,xpp+beta[j]+beta[j+1]+delta[j]+gamma[j+1]*(ypp+1)+delta[j+1]*ypp+gamma[j+2]+delta[j+2])*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1]+1)*Kroneck(alpha[j+2]+beta[j+2]))
			  *(0.125*cexp(M_PI*I/2.0*((delta[j+4]-gamma[j+3])*pow(yppp+1,2)+2.0*(beta[j+3]+beta[j+4]+gamma[j+3]+delta[j+4])*xppp*pow(yppp+1,2)+2.0*(delta[j+3]+delta[j+4]+beta[j+3]+beta[j+4])*xppp*yppp+(2.0*beta[j+3]+3.0*delta[j+3]+delta[j+4])*yppp))*Gausssum1d(0.0,beta[j+5])*Kroneck(gamma[j+3]+delta[j+3]-gamma[j+4]-delta[j+4])*Kroneck(gamma[j+5]+delta[j+5]) 
			    + 0.125*cexp(M_PI*I/2.0*((delta[j+4]-gamma[j+3])*pow(yppp+1,2)+2.0*(beta[j+3]+beta[j+4]+gamma[j+3]+delta[j+4])*xppp*pow(yppp+1,2)+2.0*(delta[j+3]+delta[j+4]+beta[j+3]+beta[j+4])*xppp*yppp+(2.0*beta[j+3]+3.0*delta[j+3]+delta[j+4])*yppp))*csqrt(-I)*Gausssum1d(gamma[j+5]+delta[j+5],0)*Kroneck(gamma[j+3]+delta[j+3]-gamma[j+4]-delta[j+4])*Kroneck(alpha[j+5]+beta[j+5])));
		    }
		  }
		}
	      }
	      for(ypp=0; ypp<=1; ypp++) {
		for(xpp=(ypp*(delta[j]+delta[j+1]))%2; xpp<=(1+ypp*(gamma[j]+gamma[j+1]))%2; xpp++) {
		  for(yppp=0; yppp<=(1+alpha[j+5])%2; yppp++) {
		    for(xppp=0;xppp<=(1+beta[j+5])%2; xppp++) {
		      summand += (2.0*(0.125*pow(2.0,(pow(y-1,2)*(pow(x,2)*(gamma[i]+delta[i+1])+pow(x-1,2)*(gamma[i+1]+delta[i])))*(pow(yp-1,2)*(pow(xp,2)*(gamma[i+3]+delta[i+4])+pow(xp-1,2)*(gamma[i+4]+delta[i+3]))))*(-I)*cexp(M_PI*I/2.0*(y*(delta[i]+delta[i+1])+pow(y+1,2)*(delta[i]+gamma[i+1]+2*beta[i+1])+pow(x,2)+2*(beta[i]+beta[i+1]+delta[i]+gamma[i+1]*(y+1)+delta[i+1]*y)*x))*Gausssum1d(0,x+beta[i]+beta[i+1]+delta[i]+gamma[i+1]*(y+1)+delta[i+1]*y+gamma[i+2]+delta[i+2])*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1]+1)*Kroneck(alpha[i+2]+beta[i+2]))
				  *(0.125*(-I)*cexp(M_PI*I/2.0*(yp*(delta[i+3]+delta[i+4])+pow(yp+1,2)*(delta[i+3]+gamma[i+4]+2*beta[i+4])+pow(xp,2)+2*(beta[i+3]+beta[i+4]+delta[i+3]+gamma[i+4]*(yp+1)+delta[i+4]*yp)*xp))*Gausssum1d(0,xp+beta[i+3]+beta[i+4]+delta[i+3]+gamma[i+4]*(yp+1)+delta[i+4]*yp+gamma[i+5]+delta[i+5])*Kroneck(gamma[i+3]+delta[i+3]-gamma[i+4]-delta[i+4]+1)*Kroneck(alpha[i+5]+beta[i+5])))
			*((0.125*pow(2.0,pow(ypp-1,2)*(pow(xpp,2)*(gamma[j]+delta[j+1])+pow(xpp-1,2)*(gamma[j+1]+delta[j])))*(-I)*cexp(M_PI*I/2.0*(ypp*(delta[j]+delta[j+1])+pow(ypp+1,2)*(delta[j]+gamma[j+1]+2*beta[j+1])+pow(xpp,2)+2*(beta[j]+beta[j+1]+delta[j]+gamma[j+1]*(ypp+1)+delta[j+1]*ypp)*xpp))*Gausssum1d(0,xpp+beta[j]+beta[j+1]+delta[j]+gamma[j+1]*(ypp+1)+delta[j+1]*ypp+gamma[j+2]+delta[j+2])*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1]+1)*Kroneck(alpha[j+2]+beta[j+2]))
			  *(0.125*2.0*csqrt(-I)*cexp(M_PI*I/2.0*(2.0*beta[j+5]*yppp+pow(xppp+1,2)*(delta[j+3]+gamma[j+4]+2.0*beta[j+4])+xppp*(delta[j+3]+delta[j+4])))*Gausssum1d(1,beta[j+3]+beta[j+4]+delta[j+3]+(xppp+1)*gamma[j+4]+xppp*delta[j+4])*Kroneck(gamma[j+3]+delta[j+3]-gamma[j+4]-delta[j+4]+1)*Kroneck(gamma[j+5]+delta[j+5])));
		    }
		  }
		}
	      }
	      //for(ypp=0; ypp<=1; ypp++) {
	      for(ypp=(y+yp)%2; ypp<=1; ypp++) {
		//for(xpp=(ypp*(delta[j]+delta[j+1]))%2; xpp<=(1+ypp*(gamma[j]+gamma[j+1]))%2; xpp++) {
		for(xpp=(ypp*(delta[j]+delta[j+1])+y+yp)%2; xpp<=(1+ypp*(gamma[j]+gamma[j+1])+y+yp)%2; xpp++) {
		  //for(yppp=ypp; yppp<=1; yppp++) {
		  for(yppp=(y+yp+ypp)%2; yppp<=1; yppp++) {
		    //for(xppp=(yppp*(delta[j+3]+delta[j+4])+ypp)%2;xppp<=(1+yppp*(gamma[j+3]+gamma[j+4])+ypp)%2; xppp++) {
		    for(xppp=(yppp*(delta[j+3]+delta[j+4])+y+yp+ypp)%2;xppp<=(1+yppp*(gamma[j+3]+gamma[j+4])+y+yp+ypp)%2; xppp++) {
		      //summand += (2.0*(0.125*pow(2.0,(pow(y-1,2)*(pow(x,2)*(gamma[i]+delta[i+1])+pow(x-1,2)*(gamma[i+1]+delta[i])))*(pow(yp-1,2)*(pow(xp,2)*(gamma[i+3]+delta[i+4])+pow(xp-1,2)*(gamma[i+4]+delta[i+3]))))*(-I)*cexp(M_PI*I/2.0*(y*(delta[i]+delta[i+1])+pow(y+1,2)*(delta[i]+gamma[i+1]+2*beta[i+1])+pow(x,2)+2*(beta[i]+beta[i+1]+delta[i]+gamma[i+1]*(y+1)+delta[i+1]*y)*x))*Gausssum1d(0,x+beta[i]+beta[i+1]+delta[i]+gamma[i+1]*(y+1)+delta[i+1]*y+gamma[i+2]+delta[i+2])*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1]+1)*Kroneck(alpha[i+2]+beta[i+2]))
		      summand += 2.0*(2.0*(0.125*pow(2.0,(pow(y-1,2)*(pow(x,2)*(gamma[i]+delta[i+1])+pow(x-1,2)*(gamma[i+1]+delta[i])))*(pow(yp-1,2)*(pow(xp,2)*(gamma[i+3]+delta[i+4])+pow(xp-1,2)*(gamma[i+4]+delta[i+3])))*(pow(ypp-1,2)*(pow(xpp,2)*(gamma[j]+delta[j+1])+pow(xpp-1,2)*(gamma[j+1]+delta[j])))*(pow(yppp-1,2)*(pow(xppp,2)*(gamma[j+3]+delta[j+4])+pow(xppp-1,2)*(gamma[j+4]+delta[j+3]))))*(-I)*cexp(M_PI*I/2.0*(y*(delta[i]+delta[i+1])+pow(y+1,2)*(delta[i]+gamma[i+1]+2*beta[i+1])+pow(x,2)+2*(beta[i]+beta[i+1]+delta[i]+gamma[i+1]*(y+1)+delta[i+1]*y)*x))*Gausssum1d(0,x+beta[i]+beta[i+1]+delta[i]+gamma[i+1]*(y+1)+delta[i+1]*y+gamma[i+2]+delta[i+2])*Kroneck(gamma[i]+delta[i]-gamma[i+1]-delta[i+1]+1)*Kroneck(alpha[i+2]+beta[i+2]))
				  *(0.125*(-I)*cexp(M_PI*I/2.0*(yp*(delta[i+3]+delta[i+4])+pow(yp+1,2)*(delta[i+3]+gamma[i+4]+2*beta[i+4])+pow(xp,2)+2*(beta[i+3]+beta[i+4]+delta[i+3]+gamma[i+4]*(yp+1)+delta[i+4]*yp)*xp))*Gausssum1d(0,xp+beta[i+3]+beta[i+4]+delta[i+3]+gamma[i+4]*(yp+1)+delta[i+4]*yp+gamma[i+5]+delta[i+5])*Kroneck(gamma[i+3]+delta[i+3]-gamma[i+4]-delta[i+4]+1)*Kroneck(alpha[i+5]+beta[i+5])))
			//*(2.0*(0.125*pow(2.0,(pow(ypp-1,2)*(pow(xpp,2)*(gamma[j]+delta[j+1])+pow(xpp-1,2)*(gamma[j+1]+delta[j])))*(pow(yppp-1,2)*(pow(xppp,2)*(gamma[j+3]+delta[j+4])+pow(xppp-1,2)*(gamma[j+4]+delta[j+3]))))*(-I)*cexp(M_PI*I/2.0*(ypp*(delta[j]+delta[j+1])+pow(ypp+1,2)*(delta[j]+gamma[j+1]+2*beta[j+1])+pow(xpp,2)+2*(beta[j]+beta[j+1]+delta[j]+gamma[j+1]*(ypp+1)+delta[j+1]*ypp)*xpp))*Gausssum1d(0,xpp+beta[j]+beta[j+1]+delta[j]+gamma[j+1]*(ypp+1)+delta[j+1]*ypp+gamma[j+2]+delta[j+2])*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1]+1)*Kroneck(alpha[j+2]+beta[j+2]))
			*(2.0*(0.125*(-I)*cexp(M_PI*I/2.0*(ypp*(delta[j]+delta[j+1])+pow(ypp+1,2)*(delta[j]+gamma[j+1]+2*beta[j+1])+pow(xpp,2)+2*(beta[j]+beta[j+1]+delta[j]+gamma[j+1]*(ypp+1)+delta[j+1]*ypp)*xpp))*Gausssum1d(0,xpp+beta[j]+beta[j+1]+delta[j]+gamma[j+1]*(ypp+1)+delta[j+1]*ypp+gamma[j+2]+delta[j+2])*Kroneck(gamma[j]+delta[j]-gamma[j+1]-delta[j+1]+1)*Kroneck(alpha[j+2]+beta[j+2]))
			  *(0.125*(-I)*cexp(M_PI*I/2.0*(yppp*(delta[j+3]+delta[j+4])+pow(yppp+1,2)*(delta[j+3]+gamma[j+4]+2*beta[j+4])+pow(xppp,2)+2*(beta[j+3]+beta[j+4]+delta[j+3]+gamma[j+4]*(yppp+1)+delta[j+4]*yppp)*xppp))*Gausssum1d(0,xppp+beta[j+3]+beta[j+4]+delta[j+3]+gamma[j+4]*(yppp+1)+delta[j+4]*yppp+gamma[j+5]+delta[j+5])*Kroneck(gamma[j+3]+delta[j+3]-gamma[j+4]-delta[j+4]+1)*Kroneck(alpha[j+5]+beta[j+5])));
		    }
		  }
		}
	      }
	    }
	  }
	}
      }
      
      
      sum *= summand;
    }
    //printf("%lf+%lfI\n", creal(sum), cimag(sum));
    printf("%lf\n", cabs(creal(sum))); 


  }

  return 0;
}

complex double Kroneck(int arg)
{
  arg = (arg+1)%2; // output 1 if argument is 0 mod 2 and 0 otherwise
  return ((complex double)arg);
}

complex double Gausssum1d(int quadraticcoeff, int linearcoeff)
{
  /*****************************************
  /* NOTE! we assume coeffs are either 0 or 1
  /* (So you cannot pass off a linear coeff as a quadratic coeff by multiplying it by a factor of 2 (and considering it as mod 4)!)
  *****************************************/
  
  quadraticcoeff %= 2;
  linearcoeff %= 2;
    
  if(quadraticcoeff == 0)
    if(linearcoeff == 0)
      return 2.0+0.0*I;
    else
      return 0.0*I;
  else
    if(linearcoeff == 0)
      return 1.0+1.0*I;
    else
      return 1.0-1.0*I;

}

int readPaulicoeffs(int *alpha, int *beta, int *gamma, int *delta, int numqubits)
{

  int i;

  if(scanf("%d %d %d %d", &alpha[0], &beta[0], &gamma[0], &delta[0]) != EOF) {
    for(i=1; i<numqubits; i++) {
      scanf("%d %d %d %d", &alpha[i], &beta[i], &gamma[i], &delta[i]);
    }
    return 1;
  } else
    return 0;

}



