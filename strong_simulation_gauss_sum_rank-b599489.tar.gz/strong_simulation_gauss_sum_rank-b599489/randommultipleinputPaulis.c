#include <stdio.h>
#include <stdlib.h>
#include <time.h>

// order of matrix elements is [row][column]!!!

int main( int argc, char *argv[])
{

  if(argc != 4) {
    printf("randommultipleinputPaulis arguments: \"number of qubits\" \"number of T gates\" \"number of Paulis\"\n");
    exit(0);
  }
  
  int N = atoi(argv[1]);              // number of qubits
  int T = atoi(argv[2]);              // number of T gate magic states (set to the first 'K' of the 'N' qubits -- the rest are set to the '0' computational basis state)
  int numPaulis = atoi(argv[3]);

  printf("%d\n", N);
  //printf("%d\n", T);

  int r;
  srand((unsigned)time(NULL));


  int i, j;
  
  for(i=0; i<numPaulis; i++) {
    
    //r = rand()%4; printf("%d\n",r); // omega
    
    for(j=0; j<N; j++) {
      r = rand()%4;
      printf("%d %d %d %d\n", r==0, r==1, r==2, r==3);
    }
  }

}
