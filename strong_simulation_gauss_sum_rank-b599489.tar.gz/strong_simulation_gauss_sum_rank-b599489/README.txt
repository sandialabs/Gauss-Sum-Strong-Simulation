Strong simulation of single-Pauli measurements using Gauss sums
---------------------------------------------------------------

See the draft at [https://arxiv.org/abs/2012.11739] for an introduction and description of this code.

BUILD:

1. Build code for Gauss sum tensor multiple you'd like to use. Here we choose k=6.
$ make gausssums_multipleof6

2. Build code for generating random Pauli inputs.
$ make randommultipleinputPaulis

3. Build Hilbert vector space code to check our results.
$ make hilbertspace_vector


TEST CODE:
1. Run test diagonositic
$ bash ./test.bash



Info on source code:
gausssums_multipleof*c need Pauli inputs which can be generated with randommultipleinputPaulis.c.

NOTE: current gausssums_multipleof*c only support the same number of T gates as number of qubits!

Output from gausssums_multipleof*c can be verified with hilbertspace_vector.c.
